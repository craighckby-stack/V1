import express from 'express';
import http from 'http';
import path from 'path';
import { apiRoutes } from './src/api-routes';
import { NextRequest } from './src/lib/next-mock';

interface RouteHandlerModule {
  [method: string]: (req: NextRequest) => Promise<Response | unknown> | Response | unknown;
}

interface HttpError extends Error {
  status?: number;
}

async function createNextMockRequest(req: express.Request): Promise<NextRequest> {
  const host = req.headers.host ?? 'localhost';
  const url = new URL(req.url, `http://${host}`);
  const reqHeaders = new Headers();
  
  for (const [key, value] of Object.entries(req.headers)) {
    if (Array.isArray(value)) {
      for (const v of value) {
        if (v !== undefined) {
          reqHeaders.append(key, v);
        }
      }
    } else if (typeof value === 'string') {
      reqHeaders.append(key, value);
    }
  }

  let body: unknown = undefined;
  const method = req.method.toUpperCase();
  if (method !== 'GET' && method !== 'HEAD') {
    body = req.body;
  }
  
  const serializedBody = body !== undefined && body !== null ? JSON.stringify(body) : undefined;
  
  const nextReq = new NextRequest(url.toString(), {
    method,
    headers: reqHeaders,
    body: serializedBody,
  });
  
  if (body !== undefined) {
    Object.defineProperty(nextReq, 'json', {
      value: async () => body,
      writable: true,
      configurable: true,
    });
  }
  
  return nextReq;
}

async function startServer(): Promise<void> {
  const app = express();
  const PORT = 3000;
  const server = http.createServer(app);

  app.use(express.json({ limit: '50mb' }));
  app.use(express.urlencoded({ extended: true, limit: '50mb' }));
  app.use(express.text({ limit: '50mb', type: ['text/*', 'application/xml', 'application/javascript'] }));
  app.use(express.raw({ limit: '50mb', type: ['application/octet-stream'] }));

  for (const [routeUrl, routeModule] of Object.entries(apiRoutes)) {
    app.all(routeUrl, async (req: express.Request, res: express.Response) => {
      try {
        const method = req.method.toUpperCase();
        const typedModule = routeModule as RouteHandlerModule;
        const handler = typedModule[method];

        if (typeof handler === 'function') {
          const nextReq = await createNextMockRequest(req);
          const nextRes = await handler(nextReq);
          
          if (nextRes instanceof Response) {
            nextRes.headers.forEach((val: string, key: string) => {
              res.setHeader(key, val);
            });
            const status = nextRes.status;
            const text = await nextRes.text();
            res.status(status).send(text);
          } else {
             res.status(500).send('Endpoint did not return a Response object');
          }
        } else {
          res.status(405).send('Method Not Allowed');
        }
      } catch (err: unknown) {
        const errorMessage = err instanceof Error ? err.message : String(err);
        console.error(`Error executing ${routeUrl}:`, err);
        if (!res.headersSent) {
          res.status(500).json({ error: errorMessage });
        }
      }
    });
  }

  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: {
        middlewareMode: true,
        hmr: false,
        ws: false,
      },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*all', (_req: express.Request, res: express.Response) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.use((err: HttpError, _req: express.Request, res: express.Response, _next: express.NextFunction) => {
    console.error('Unhandled server error:', err);
    if (!res.headersSent) {
      const status = err.status ?? 500;
      const message = err.message || 'Internal Server Error';
      res.status(status).json({
        error: message,
        success: false,
      });
    }
  });

  server.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
