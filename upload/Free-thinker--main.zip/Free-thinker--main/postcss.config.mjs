/**
 * PostCSS configuration module.
 * @type {import('postcss-load-config').Config}
 */
export default {
  plugins: {
    '@tailwindcss/postcss': {},
    autoprefixer: {},
  },
};
