export interface CommitRecord {
  hash: string;
  shortHash: string;
  pairId?: string;
  author: string;
  date: string;
  subject: string;
  body: string;
  files: string[];
  diff: string;
  verdict: 'CORRECT' | 'WRONG' | 'NEUTRAL' | 'DOCS' | 'OK';
  fixedBy?: string;
  reason?: string;
  isRevert?: boolean;
}

export interface CommitStats {
  total: number;
  totalCorrect: number;
  totalWrong: number;
  totalPairs?: number;
  totalNeutral?: number;
  totalDocs?: number;
  fileCounts: Record<string, number>;
  wrongCorrectCycles: Record<string, number>;
  themeCounts: Record<string, number>;
  dateCounts: Record<string, number>;
}

