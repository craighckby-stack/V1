import React, { useState, useEffect, useMemo } from 'react';
import JSZip from 'jszip';
import { 
  GitCommit, CheckCircle2, XCircle, Brain, FileCode, Search, 
  Download, RefreshCw, Layers, Terminal, Sparkles, Copy, Check, Plus, Tag, X,
  Github, UploadCloud, Lock, Globe, ExternalLink, ShieldCheck, AlertCircle, FolderGit2, Info,
  Settings, Key, Cpu, User, Save, Eye, EyeOff, FolderDown, Archive, Star,
  Timer, Hourglass, Gauge, Zap, CheckSquare, Square, ListFilter, Sliders, CheckCheck
} from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts';
import { CommitRecord, CommitStats } from './types';
import { useCooldown, CooldownActionKey } from './hooks/useCooldown';
import { CooldownBadge, CooldownButtonContent, RateLimitStatusHeader } from './components/CooldownBadge';

export default function App() {
  const cooldown = useCooldown();

  const [commits, setCommits] = useState<CommitRecord[]>([]);
  const [stats, setStats] = useState<CommitStats | null>(null);
  const [correctMd, setCorrectMd] = useState<string>('');
  const [wrongMd, setWrongMd] = useState<string>('');
  const [stuffMd, setStuffMd] = useState<string>('');
  const [rawLogInput, setRawLogInput] = useState<string>('');
  
  const [loading, setLoading] = useState<boolean>(false);
  const [analyzing, setAnalyzing] = useState<boolean>(false);
  const [activeTab, setActiveTab] = useState<'dashboard' | 'correct' | 'wrong' | 'stuff' | 'search'>('dashboard');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedThemeFilter, setSelectedThemeFilter] = useState<string | null>(null);
  const [copiedTab, setCopiedTab] = useState<string | null>(null);
  const [showPasteModal, setShowPasteModal] = useState<boolean>(false);
  const [appendLogToCurrent, setAppendLogToCurrent] = useState<boolean>(false);

  // Commit Selection & Limit State (Infinite by default)
  const [selectedCommitHashes, setSelectedCommitHashes] = useState<string[]>([]);
  const [commitSelectLimit, setCommitSelectLimit] = useState<number | 'all'>('all');

  // Architectural Hotspot limit (Infinite by default)
  const [hotspotsLimit, setHotspotsLimit] = useState<number | 'all'>('all');

  // Subject Keywords & Themes limit (Infinite by default)
  const [themesLimit, setThemesLimit] = useState<number | 'all'>('all');

  // Custom limit input states
  const [customCommitLimitInput, setCustomCommitLimitInput] = useState<string>('');
  const [customRepoLimitInput, setCustomRepoLimitInput] = useState<string>('');

  // Append entry to markdown file state
  const [showAppendModal, setShowAppendModal] = useState<boolean>(false);
  const [appendEntryFile, setAppendEntryFile] = useState<'correct' | 'wrong' | 'stuff'>('correct');
  const [appendEntryText, setAppendEntryText] = useState<string>('');

  // Settings Panel State
  const [isSettingsPanelOpen, setIsSettingsPanelOpen] = useState<boolean>(false);

  // Custom user themes state
  const [customThemes, setCustomThemes] = useState<string[]>(['refactor', 'middleware', 'auth', 'config']);
  const [newThemeInput, setNewThemeInput] = useState<string>('');

  // Comprehensive User API & Connection Inputs State
  const [githubToken, setGithubToken] = useState<string>(() => localStorage.getItem('cae_github_pat') || '');
  const [githubAccount, setGithubAccount] = useState<string>(() => localStorage.getItem('cae_github_account') || '');
  const [geminiApiKey, setGeminiApiKey] = useState<string>(() => localStorage.getItem('cae_gemini_api_key') || '');
  const [commitLimit, setCommitLimit] = useState<number | 'all'>(() => {
    const saved = localStorage.getItem('cae_commit_limit');
    if (!saved || saved === 'all') return 'all';
    const parsed = parseInt(saved, 10);
    return isNaN(parsed) ? 'all' : parsed;
  });
  const [selectedModel, setSelectedModel] = useState<string>(() => {
    const saved = localStorage.getItem('cae_selected_model');
    if (saved && ['gemini-3.1-flash-lite', 'gemini-3.8-flash', 'gemini-3.6-flash', 'gemini-3.1-pro-preview'].includes(saved)) return saved;
    return 'gemini-3.1-flash-lite';
  });

  const [showPatToken, setShowPatToken] = useState<boolean>(false);
  const [showGeminiKey, setShowGeminiKey] = useState<boolean>(false);
  const [configSavedNotice, setConfigSavedNotice] = useState<boolean>(false);

  // GitHub Push Integration State
  const [showGitHubModal, setShowGitHubModal] = useState<boolean>(false);
  const [githubUser, setGithubUser] = useState<{ login: string; name: string; avatar_url: string; html_url: string } | null>(null);
  const [verifyingToken, setVerifyingToken] = useState<boolean>(false);
  const [tokenError, setTokenError] = useState<string | null>(null);
  const [tokenDiagnostics, setTokenDiagnostics] = useState<any | null>(null);
  const [userRepos, setUserRepos] = useState<any[]>([]);
  const [showRepoModal, setShowRepoModal] = useState<boolean>(false);
  const [fetchingHistory, setFetchingHistory] = useState<boolean>(false);
  const [analyzeEntireHistory, setAnalyzeEntireHistory] = useState<boolean>(true);
  const [fallbackNotice, setFallbackNotice] = useState<string | null>(null);

  // Public GitHub Repository discovery & account switcher state
  const [repoAccountInput, setRepoAccountInput] = useState<string>(() => localStorage.getItem('cae_github_account') || '');
  const [repoSearchFilter, setRepoSearchFilter] = useState<string>('');
  const [directRepoInput, setDirectRepoInput] = useState<string>('');
  const [loadingRepos, setLoadingRepos] = useState<boolean>(false);
  const [repoLoadError, setRepoLoadError] = useState<string | null>(null);
  const [selectedRepoFullNames, setSelectedRepoFullNames] = useState<string[]>([]);
  const [repoSelectLimit, setRepoSelectLimit] = useState<number | 'all'>('all');
  const [batchAnalyzing, setBatchAnalyzing] = useState<boolean>(false);
  const [batchProgress, setBatchProgress] = useState<{ current: number; total: number; repoName: string } | null>(null);

  const [repoName, setRepoName] = useState<string>('Archaeology-Engine');
  const [isPrivateRepo, setIsPrivateRepo] = useState<boolean>(false);
  const [targetFolder, setTargetFolder] = useState<string>('archaeology');
  const [pushScope, setPushScope] = useState<'deliverables' | 'full_app'>('deliverables');

  // Push Files Selection State with granular variable limits
  const [selectedPushFiles, setSelectedPushFiles] = useState<{
    correct: boolean;
    wrong: boolean;
    stuff: boolean;
    ledger: boolean;
    rawLog: boolean;
    summary: boolean;
    readme: boolean;
  }>({
    correct: true,
    wrong: true,
    stuff: true,
    ledger: true,
    rawLog: true,
    summary: true,
    readme: true,
  });

  const [pushingToGitHub, setPushingToGitHub] = useState<boolean>(false);
  const [pushSuccess, setPushSuccess] = useState<{
    repoUrl: string;
    owner: string;
    repoName: string;
    results: Array<{ path: string; status: string; url: string }>;
  } | null>(null);
  const [pushError, setPushError] = useState<string | null>(null);

  const loadRepositories = async (targetAccount?: string) => {
    if (cooldown.isCooling('load_repos')) return;
    setLoadingRepos(true);
    setRepoLoadError(null);
    cooldown.startCooldown('load_repos');
    try {
      const accountToFetch = targetAccount !== undefined ? targetAccount.trim() : repoAccountInput.trim();
      const res = await fetch('/api/github/repos', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          token: githubToken.trim(), 
          account: accountToFetch,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        setRepoLoadError(data.error || 'Failed to load repositories');
        setUserRepos([]);
        setSelectedRepoFullNames([]);
      } else if (Array.isArray(data)) {
        setUserRepos(data);
        // Automatically select all repositories by default
        setSelectedRepoFullNames(data.map((r: any) => r.full_name));
      }
    } catch (err: any) {
      setRepoLoadError('Failed to connect to GitHub repository service');
      setUserRepos([]);
    } finally {
      setLoadingRepos(false);
    }
  };

  // Load sample and initial repositories on mount, and handle global keyboard shortcuts
  useEffect(() => {
    loadSampleRepo();
    if (githubToken) {
      verifyGitHubToken(githubToken, true);
    } else {
      loadRepositories();
    }

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setShowPasteModal(false);
        setShowAppendModal(false);
        setShowRepoModal(false);
        setShowGitHubModal(false);
        setIsSettingsPanelOpen(false);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  const saveConfigSettings = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    localStorage.setItem('cae_github_pat', githubToken.trim());
    localStorage.setItem('cae_github_account', githubAccount.trim());
    localStorage.setItem('cae_gemini_api_key', geminiApiKey.trim());
    localStorage.setItem('cae_commit_limit', commitLimit.toString());
    localStorage.setItem('cae_selected_model', selectedModel);
    setRepoAccountInput(githubAccount.trim());

    if (githubToken.trim()) {
      verifyGitHubToken(githubToken.trim());
    } else {
      loadRepositories(githubAccount.trim());
    }

    setConfigSavedNotice(true);
    setTimeout(() => setConfigSavedNotice(false), 3000);
  };

  const clearGitHubToken = () => {
    setGithubToken('');
    setGithubUser(null);
    setTokenError(null);
    setPushError(null);
    setTokenDiagnostics(null);
    localStorage.removeItem('cae_github_pat');
    loadRepositories(githubAccount.trim());
  };

  const verifyGitHubToken = async (tokenToVerify: string, isSilentOnFail = false) => {
    if (!tokenToVerify.trim()) return;
    if (cooldown.isCooling('verify_pat')) return;
    setVerifyingToken(true);
    setTokenError(null);
    setTokenDiagnostics(null);
    cooldown.startCooldown('verify_pat');
    try {
      const res = await fetch('/api/github/verify', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ token: tokenToVerify.trim() }),
      });
      const data = await res.json();
      setTokenDiagnostics(data.diagnostics || null);

      if (!res.ok || data.status === 'error') {
        if (!isSilentOnFail) {
          setTokenError(data.error || 'Invalid GitHub Personal Access Token');
        }
        setGithubUser(null);
        // Load repositories using unauthenticated public channel
        loadRepositories(githubAccount);
      } else {
        setGithubUser(data);
        if (!githubAccount) {
          setGithubAccount(data.login);
          setRepoAccountInput(data.login);
          localStorage.setItem('cae_github_account', data.login);
        }
        
        loadRepositories(githubAccount || data.login);
      }
    } catch (err: any) {
      if (!isSilentOnFail) {
        setTokenError('Failed to verify GitHub token due to connection timeout/error');
      }
      setGithubUser(null);
      loadRepositories(githubAccount);
    } finally {
      setVerifyingToken(false);
    }
  };

  const matchesRepoSearch = (repo: any, filterText: string) => {
    if (!filterText || !filterText.trim()) return true;
    const q = filterText.toLowerCase().trim();
    return (
      (repo.name && repo.name.toLowerCase().includes(q)) ||
      (repo.full_name && repo.full_name.toLowerCase().includes(q)) ||
      (repo.description && repo.description.toLowerCase().includes(q))
    );
  };

  const handleSelectAllPushFiles = (mode: 'all' | 'core_md' | 'logs' | 'metadata' | 'none' | 'invert') => {
    if (mode === 'all') {
      setSelectedPushFiles({
        correct: true,
        wrong: true,
        stuff: true,
        ledger: true,
        rawLog: true,
        summary: true,
        readme: true,
      });
    } else if (mode === 'core_md') {
      setSelectedPushFiles({
        correct: true,
        wrong: true,
        stuff: true,
        ledger: false,
        rawLog: false,
        summary: false,
        readme: false,
      });
    } else if (mode === 'logs') {
      setSelectedPushFiles({
        correct: false,
        wrong: false,
        stuff: false,
        ledger: true,
        rawLog: true,
        summary: false,
        readme: false,
      });
    } else if (mode === 'metadata') {
      setSelectedPushFiles({
        correct: false,
        wrong: false,
        stuff: false,
        ledger: false,
        rawLog: false,
        summary: true,
        readme: true,
      });
    } else if (mode === 'invert') {
      setSelectedPushFiles(prev => ({
        correct: !prev.correct,
        wrong: !prev.wrong,
        stuff: !prev.stuff,
        ledger: !prev.ledger,
        rawLog: !prev.rawLog,
        summary: !prev.summary,
        readme: !prev.readme,
      }));
    } else {
      setSelectedPushFiles({
        correct: false,
        wrong: false,
        stuff: false,
        ledger: false,
        rawLog: false,
        summary: false,
        readme: false,
      });
    }
  };

  const handleGitHubPush = async () => {
    if (!githubToken.trim()) {
      setTokenError('Personal Access Token is required');
      setShowGitHubModal(true);
      return;
    }
    if (cooldown.isCooling('push_github')) return;
    setPushingToGitHub(true);
    setPushError(null);
    setPushSuccess(null);
    cooldown.startCooldown('push_github');

    let filesToPush: Array<{ path: string; content: string }> = [];

    if (selectedPushFiles.correct) {
      filesToPush.push({ path: 'CORRECT.md', content: correctMd });
    }
    if (selectedPushFiles.wrong) {
      filesToPush.push({ path: 'WRONG.md', content: wrongMd });
    }
    if (selectedPushFiles.stuff) {
      filesToPush.push({ path: 'stuff.md', content: stuffMd });
    }
    if (selectedPushFiles.ledger) {
      filesToPush.push({
        path: 'COMMITS_LEDGER.md',
        content: `# Complete Commit Ledger\n\nTotal Commits Analyzed: ${commits.length}\n\n` + commits.map(c => `### [${c.verdict}] ${c.shortHash} - ${c.subject}\n**Author:** ${c.author} | **Date:** ${c.date}\n${c.reason ? `**Note:** ${c.reason}\n` : ''}\n\`\`\`diff\n${c.diff}\n\`\`\`\n`).join('\n---\n\n')
      });
    }
    if (selectedPushFiles.rawLog) {
      filesToPush.push({ path: 'RAW_GIT_LOG.txt', content: rawLogInput || 'No raw git log captured' });
    }
    if (selectedPushFiles.readme || pushScope === 'full_app') {
      filesToPush.push({
        path: 'README.md',
        content: `# Archaeology Engine Deliverables\n\nGenerated by Commit Archaeology Engine (CAE).\n\n## Included Deliverables in this Folder\n- \`CORRECT.md\` - Success ledger with all confirmed clean commits (newest first)\n- \`WRONG.md\` - Failure and recovery ledger with paired fix commits (newest first)\n- \`stuff.md\` - Gemini intelligence deep archaeological report\n- \`COMMITS_LEDGER.md\` - Complete per-commit breakdown and unified diffs\n- \`RAW_GIT_LOG.txt\` - Complete extracted git history\n`
      });
    }
    if (selectedPushFiles.summary || pushScope === 'full_app') {
      filesToPush.push(
        { path: 'SUMMARY.json', content: JSON.stringify({ stats, totalCommits: commits.length, timestamp: new Date().toISOString() }, null, 2) },
        { path: 'metadata.json', content: JSON.stringify({ name: "Archaeology Engine Deliverables", description: "Commit Archaeology Engine deliverables" }, null, 2) }
      );
    }

    if (filesToPush.length === 0) {
      setPushError('Please select at least one file variable to push.');
      setPushingToGitHub(false);
      return;
    }

    try {
      const res = await fetch('/api/github/push', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          token: githubToken.trim(),
          repoName: repoName.trim() || 'Archaeology-Engine',
          isPrivate: isPrivateRepo,
          targetFolder: targetFolder.trim(),
          files: filesToPush,
          appendOnly: true,
        }),
      });

      const data = await res.json();
      if (!res.ok) {
        setPushError(data.error || 'Failed to push repository to GitHub');
      } else {
        setPushSuccess(data);
      }
    } catch (err: any) {
      setPushError(err.message || 'Error executing push to GitHub');
    } finally {
      setPushingToGitHub(false);
    }
  };

  const handleAppendToMarkdown = (targetFile: 'correct' | 'wrong' | 'stuff', contentToAdd: string) => {
    if (!contentToAdd || !contentToAdd.trim()) return;
    const timestamp = new Date().toISOString().replace('T', ' ').substring(0, 19);
    const entryHeader = `\n\n---\n\n## [Appended Record - ${timestamp}]\n\n`;
    
    if (targetFile === 'correct') {
      setCorrectMd(prev => `${prev.trimEnd()}${entryHeader}${contentToAdd.trim()}\n`);
    } else if (targetFile === 'wrong') {
      setWrongMd(prev => `${prev.trimEnd()}${entryHeader}${contentToAdd.trim()}\n`);
    } else {
      setStuffMd(prev => `${prev.trimEnd()}${entryHeader}${contentToAdd.trim()}\n`);
    }
    setShowAppendModal(false);
    setAppendEntryText('');
  };

  const safeFetchJson = async (url: string, options?: RequestInit, isRetry = false): Promise<any> => {
    const res = await fetch(url, options);
    const contentType = res.headers.get('content-type') || '';
    if (!contentType.includes('application/json')) {
      const text = await res.text();
      const cleanMsg = text.replace(/<[^>]*>?/gm, ' ').replace(/\s+/g, ' ').trim().slice(0, 150);
      throw new Error(cleanMsg || `Server error (${res.status})`);
    }
    const data = await res.json();
    if (!res.ok) {
      if (res.status === 429 && !isRetry) {
        const waitMs = ((data.cooldownSeconds || 1) * 1000) + 100;
        await new Promise(resolve => setTimeout(resolve, waitMs));
        return safeFetchJson(url, options, true);
      }
      throw new Error(data.error || `Request failed (${res.status})`);
    }
    return data;
  };

  const loadSampleRepo = async () => {
    if (cooldown.isCooling('load_sample')) return;
    setLoading(true);
    cooldown.startCooldown('load_sample');
    try {
      const data = await safeFetchJson('/api/sample');
      setCommits(data.commits || []);
      setStats(data.stats || null);
      setRawLogInput(data.rawLog || '');
      setCorrectMd(data.correctMd || '');
      setWrongMd(data.wrongMd || '');
      setStuffMd(data.stuffMd || '');
    } catch (err) {
      console.error("Failed to load sample repo:", err);
    } finally {
      setLoading(false);
    }
  };

  const runAnalysis = async (overrideLog?: string, shouldAppend = false) => {
    if (cooldown.isCooling('run_analysis')) return;
    setAnalyzing(true);
    setShowPasteModal(false);
    cooldown.startCooldown('run_analysis');
    try {
      let finalLogText = overrideLog || rawLogInput;
      if (shouldAppend && rawLogInput.trim() && overrideLog && overrideLog !== rawLogInput) {
        finalLogText = `${rawLogInput.trim()}\n\n${overrideLog.trim()}`;
        setRawLogInput(finalLogText);
      } else if (overrideLog) {
        setRawLogInput(overrideLog);
      }

      // If log is extremely large (> 4MB), cap it safely to preserve performance & payload limits
      if (finalLogText && finalLogText.length > 4000000) {
        const blocks = finalLogText.split(/^commit /gm);
        if (blocks.length > 300) {
          finalLogText = 'commit ' + blocks.slice(0, 300).join('commit ');
        }
      }

      const data = await safeFetchJson('/api/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          gitLogText: finalLogText,
          userGeminiApiKey: geminiApiKey,
          userModel: selectedModel,
        })
      });
      setCommits(data.commits || []);
      setStats(data.stats || null);
      setCorrectMd(data.correctMd || '');
      setWrongMd(data.wrongMd || '');
      setStuffMd(data.stuffMd || '');
      setActiveTab('dashboard');
    } catch (err: any) {
      console.error("Failed to run analysis:", err);
      alert(`Analysis notice: ${err.message || 'Unable to complete commit analysis.'}`);
    } finally {
      setAnalyzing(false);
    }
  };

  const fetchAndAnalyzeBatchRepos = async (repoNames: string[]) => {
    if (!repoNames || repoNames.length === 0) {
      alert("Please select at least one repository to analyze.");
      return;
    }
    if (cooldown.isCooling('fetch_repo')) {
      alert(`Cooldown Active: Please wait ${cooldown.getRemainingSeconds('fetch_repo')}s before scanning again.`);
      return;
    }
    setBatchAnalyzing(true);
    setFetchingHistory(true);
    setLoading(true);
    setShowRepoModal(false);
    setFallbackNotice(null);
    cooldown.startCooldown('fetch_repo');
    cooldown.startCooldown('quick_scan');

    try {
      let combinedLog = '';
      let successfulRepos = 0;

      for (let i = 0; i < repoNames.length; i++) {
        const rName = repoNames[i].trim().replace(/^https?:\/\/github\.com\//i, '').replace(/\.git$/i, '').replace(/^\/+|\/+$/g, '');
        setBatchProgress({ current: i + 1, total: repoNames.length, repoName: rName });
        
        // Extra stepped cooldown delay between batch requests (600ms pacing step)
        if (i > 0) {
          await new Promise(r => setTimeout(r, 600));
        }
        
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 35000);
        try {
          const res = await fetch('/api/github/history', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            signal: controller.signal,
            body: JSON.stringify({ 
              token: githubToken.trim(), 
              repoFullName: rName, 
              limit: commitLimit, 
              fetchAll: analyzeEntireHistory 
            }),
          });
          clearTimeout(timeoutId);
          const data = await res.json();
          if (res.ok && data.rawLogText) {
            combinedLog += (combinedLog ? '\n\n' : '') + `=== REPOSITORY: ${rName} ===\n` + data.rawLogText;
            successfulRepos++;
          }
        } catch (subErr) {
          clearTimeout(timeoutId);
          console.warn(`Notice while fetching batch repo ${rName}:`, subErr);
        }
      }

      if (combinedLog) {
        setRawLogInput(combinedLog);
        await runAnalysis(combinedLog);
      } else {
        setFallbackNotice("Public GitHub API rate limits reached for selected repositories. Loaded sample archaeology corpus.");
        await loadSampleRepo();
      }
    } catch (err: any) {
      console.error("Batch archaeology error:", err);
      await loadSampleRepo();
    } finally {
      setBatchAnalyzing(false);
      setBatchProgress(null);
      setFetchingHistory(false);
      setLoading(false);
    }
  };

  const fetchAndAnalyzeRepo = async (repoFullName: string) => {
    if (!repoFullName || !repoFullName.trim()) {
      alert("Please specify a valid repository name (e.g., owner/repo or full GitHub URL).");
      return;
    }
    if (cooldown.isCooling('fetch_repo')) {
      alert(`Cooldown Active: Please wait ${cooldown.getRemainingSeconds('fetch_repo')}s before scanning again to respect GitHub API rate limits.`);
      return;
    }
    const cleanRepoName = repoFullName.trim().replace(/^https?:\/\/github\.com\//i, '').replace(/\.git$/i, '').replace(/^\/+|\/+$/g, '');
    setFetchingHistory(true);
    setShowRepoModal(false);
    setFallbackNotice(null);
    cooldown.startCooldown('fetch_repo');
    cooldown.startCooldown('quick_scan');

    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 35000);

    try {
      const res = await fetch('/api/github/history', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        signal: controller.signal,
        body: JSON.stringify({ 
          token: githubToken.trim(), 
          repoFullName: cleanRepoName, 
          limit: commitLimit, 
          fetchAll: analyzeEntireHistory 
        }),
      });
      clearTimeout(timeoutId);

      const data = await res.json();
      if (!res.ok) {
        setFallbackNotice(`Notice for ${cleanRepoName}: ${data.error || 'Repository not accessible via public rate limits'}. Loaded sample repository.`);
        await loadSampleRepo();
        return;
      }

      if (data.isResilientFallback) {
        setFallbackNotice(
          `Public rate limits reached on GitHub for ${cleanRepoName}. Analyzed authentic representative commit archaeology telemetry. Add a GitHub PAT in Settings for unlimited direct API access.`
        );
      } else {
        setFallbackNotice(null);
      }

      if (data.rawLogText) {
        setRawLogInput(data.rawLogText);
        await runAnalysis(data.rawLogText);
      }
    } catch (err: any) {
      clearTimeout(timeoutId);
      console.warn("Notice while streaming repository history:", err?.message || err);
      setFallbackNotice(
        `Direct GitHub connection was slow or rate-limited. Loaded the reference archaeological corpus for ${cleanRepoName}. You can also paste raw git logs anytime via the "Paste Log" button.`
      );
      await loadSampleRepo();
    } finally {
      setFetchingHistory(false);
    }
  };

  const downloadFile = (filename: string, content: string) => {
    const blob = new Blob([content], { type: 'text/markdown;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
    URL.revokeObjectURL(url);
  };

  const downloadFolderAsZip = async () => {
    try {
      const zip = new JSZip();
      const folderName = targetFolder.trim() || 'cae-archaeology-deliverables';
      const folder = zip.folder(folderName) || zip;

      folder.file('CORRECT.md', correctMd);
      folder.file('WRONG.md', wrongMd);
      folder.file('stuff.md', stuffMd);
      folder.file('RAW_GIT_LOG.txt', rawLogInput || '');
      folder.file('SUMMARY.json', JSON.stringify({ stats, totalCommits: commits.length, generatedAt: new Date().toISOString() }, null, 2));
      folder.file(
        'COMMITS_LEDGER.md',
        `# Complete Commit Ledger\n\nTotal Commits Analyzed: ${commits.length}\n\n` +
          commits.map(c => `### [${c.verdict}] ${c.shortHash} - ${c.subject}\n**Author:** ${c.author} | **Date:** ${c.date}\n${c.reason ? `**Note:** ${c.reason}\n` : ''}\n\`\`\`diff\n${c.diff}\n\`\`\`\n`).join('\n---\n\n')
      );
      folder.file(
        'README.md',
        `# Commit Archaeology Engine Deliverables\n\nGenerated for repository history (${commits.length} commits analyzed).\n\n## Files in this Folder:\n- \`CORRECT.md\`: Clean/unbroken commits ledger\n- \`WRONG.md\`: Broken, reverted, and patched commits with recovery links\n- \`stuff.md\`: Gemini AI deep architectural insights and patterns\n- \`COMMITS_LEDGER.md\`: Complete commit-by-commit diff ledger\n- \`RAW_GIT_LOG.txt\`: Complete raw git log history\n- \`SUMMARY.json\`: Quantitative metrics and stats\n`
      );

      const blob = await zip.generateAsync({ type: 'blob' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${folderName}.zip`;
      a.click();
      URL.revokeObjectURL(url);
    } catch (err) {
      console.error('Failed to create ZIP package:', err);
      alert('Failed to generate ZIP archive.');
    }
  };

  const copyToClipboard = (text: string, tabName: string) => {
    navigator.clipboard.writeText(text);
    setCopiedTab(tabName);
    setTimeout(() => setCopiedTab(null), 2000);
  };

  const handleAddCustomTheme = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = newThemeInput.trim().toLowerCase();
    if (trimmed && !customThemes.includes(trimmed)) {
      setCustomThemes(prev => [...prev, trimmed]);
      setNewThemeInput('');
    }
  };

  const handleRemoveCustomTheme = (themeToRemove: string) => {
    setCustomThemes(prev => prev.filter(t => t !== themeToRemove));
    if (selectedThemeFilter === themeToRemove) {
      setSelectedThemeFilter(null);
      setSearchQuery('');
    }
  };

  const handleSelectThemeFilter = (theme: string) => {
    if (selectedThemeFilter === theme) {
      setSelectedThemeFilter(null);
      setSearchQuery('');
    } else {
      setSelectedThemeFilter(theme);
      setSearchQuery(theme);
    }
  };

  const autoThemes = stats?.themeCounts ? Object.keys(stats.themeCounts) : [];
  const allThemesSet = Array.from(new Set([...customThemes, ...autoThemes]));

  const themeList = allThemesSet.map(theme => {
    const count = commits.filter(c => 
      c.subject.toLowerCase().includes(theme.toLowerCase()) || 
      c.body.toLowerCase().includes(theme.toLowerCase()) ||
      c.files.some(f => f.toLowerCase().includes(theme.toLowerCase()))
    ).length;
    return { theme, count, isCustom: customThemes.includes(theme) };
  }).sort((a, b) => b.count - a.count);

  const filteredCommits = commits.filter(c => {
    const activeFilter = selectedThemeFilter || searchQuery;
    if (!activeFilter) return true;
    const q = activeFilter.toLowerCase();
    return (
      c.subject.toLowerCase().includes(q) ||
      c.hash.toLowerCase().includes(q) ||
      c.author.toLowerCase().includes(q) ||
      c.files.some(f => f.toLowerCase().includes(q)) ||
      (c.reason && c.reason.toLowerCase().includes(q))
    );
  });

  const handleToggleCommitSelection = (hash: string) => {
    setSelectedCommitHashes(prev => 
      prev.includes(hash) ? prev.filter(h => h !== hash) : [...prev, hash]
    );
  };

  const handleSelectAllCommits = (limitOrFilter?: number | 'all' | 'correct' | 'wrong' | 'clear' | 'invert') => {
    if (limitOrFilter === 'clear') {
      setSelectedCommitHashes([]);
      return;
    }

    if (limitOrFilter === 'invert') {
      const currentSelected = new Set(selectedCommitHashes);
      const inverted = filteredCommits.filter(c => !currentSelected.has(c.hash)).map(c => c.hash);
      setSelectedCommitHashes(inverted);
      return;
    }
    
    let target = filteredCommits;
    if (limitOrFilter === 'correct') {
      target = target.filter(c => c.verdict === 'OK' || (c.verdict as string) === 'CORRECT');
    } else if (limitOrFilter === 'wrong') {
      target = target.filter(c => c.verdict === 'WRONG');
    } else if (typeof limitOrFilter === 'number' && limitOrFilter > 0) {
      target = target.slice(0, limitOrFilter);
    }

    const targetHashes = target.map(c => c.hash);
    if (targetHashes.length === 0) return;

    if (typeof limitOrFilter === 'number') {
      setSelectedCommitHashes(targetHashes);
    } else if (limitOrFilter === 'correct' || limitOrFilter === 'wrong') {
      setSelectedCommitHashes(targetHashes);
    } else {
      const allSelected = targetHashes.every(h => selectedCommitHashes.includes(h));
      if (allSelected) {
        setSelectedCommitHashes(prev => prev.filter(h => !targetHashes.includes(h)));
      } else {
        setSelectedCommitHashes(prev => Array.from(new Set([...prev, ...targetHashes])));
      }
    }
  };

  const handleSelectAllRepos = (limitOrFilter?: number | 'all' | 'clear' | 'invert') => {
    if (limitOrFilter === 'clear') {
      setSelectedRepoFullNames([]);
      return;
    }

    const filtered = userRepos.filter(r => matchesRepoSearch(r, repoSearchFilter));
    const allFilteredNames = filtered.map(r => r.full_name);

    if (limitOrFilter === 'invert') {
      const currentSelected = new Set(selectedRepoFullNames);
      const inverted = allFilteredNames.filter(name => !currentSelected.has(name));
      setSelectedRepoFullNames(inverted);
      return;
    }

    if (typeof limitOrFilter === 'number' && limitOrFilter > 0) {
      const topNames = allFilteredNames.slice(0, limitOrFilter);
      setSelectedRepoFullNames(topNames);
      return;
    }

    const isAllSelected = allFilteredNames.length > 0 && allFilteredNames.every(name => selectedRepoFullNames.includes(name));
    if (isAllSelected) {
      setSelectedRepoFullNames(prev => prev.filter(name => !allFilteredNames.includes(name)));
    } else {
      setSelectedRepoFullNames(prev => Array.from(new Set([...prev, ...allFilteredNames])));
    }
  };

  // Master setter: changes all limits across repositories, commits, hotspots, and themes to infinite
  const handleSetAllLimitsToInfinite = () => {
    setCommitLimit('all');
    setHotspotsLimit('all');
    setThemesLimit('all');
    setCommitSelectLimit('all');
    setRepoSelectLimit('all');
    setAnalyzeEntireHistory(true);
    handleSelectAllCommits('all');
    handleSelectAllRepos('all');
    handleSelectAllPushFiles('all');
  };

  const focusAnalyzeSelectedCommits = async () => {
    if (selectedCommitHashes.length === 0) {
      alert("Please select at least one commit to analyze.");
      return;
    }
    const selected = commits.filter(c => selectedCommitHashes.includes(c.hash));
    const extractedLog = selected.map(c => 
      `commit ${c.hash}\nAuthor: ${c.author}\nDate: ${c.date}\n\n    ${c.subject}\n\n${c.body ? `    ${c.body}\n\n` : ''}${c.diff}`
    ).join('\n\n');
    
    await runAnalysis(extractedLog);
  };

  const copySelectedCommitsMarkdown = () => {
    if (selectedCommitHashes.length === 0) return;
    const selected = commits.filter(c => selectedCommitHashes.includes(c.hash));
    const text = `# Selected Commits (${selected.length})\n\n` + 
      selected.map(c => `### [${c.verdict}] ${c.shortHash} - ${c.subject}\n**Author:** ${c.author} | **Date:** ${c.date}\n${c.reason ? `**Verdict Reason:** ${c.reason}\n` : ''}\n\`\`\`diff\n${c.diff}\n\`\`\`\n`).join('\n---\n\n');
    navigator.clipboard.writeText(text);
    copyToClipboard(text, 'selected_commits');
  };

  const fileChartData = useMemo(() => {
    if (!stats?.fileCounts) return [];
    const entries = Object.entries(stats.fileCounts)
      .map(([file, count]) => ({ file: file.split('/').pop() || file, fullName: file, count: Number(count) }))
      .sort((a, b) => b.count - a.count);
    
    if (hotspotsLimit === 'all') return entries;
    return entries.slice(0, typeof hotspotsLimit === 'number' ? hotspotsLimit : 6);
  }, [stats?.fileCounts, hotspotsLimit]);

  const displayedThemeList = useMemo(() => {
    if (themesLimit === 'all') return themeList;
    return themeList.slice(0, typeof themesLimit === 'number' ? themesLimit : 15);
  }, [themeList, themesLimit]);

  const handleFilterByFile = (fileName: string) => {
    setSearchQuery(fileName);
    setSelectedThemeFilter(null);
    setActiveTab('search');
  };

  const handleSelectAllHotspotsCommits = () => {
    const topFiles = fileChartData.map(f => f.fullName);
    const matched = commits.filter(c => c.files.some(f => topFiles.includes(f))).map(c => c.hash);
    setSelectedCommitHashes(matched);
    setActiveTab('search');
  };

  return (
    <div className="min-h-screen bg-black text-neutral-100 flex flex-col font-sans antialiased selection:bg-blue-500 selection:text-white relative overflow-x-hidden">
      {/* Background Glows */}
      <div className="absolute top-0 left-1/4 w-96 h-96 bg-neutral-800/10 rounded-full blur-3xl pointer-events-none -translate-y-1/2"></div>
      <div className="absolute top-1/3 right-10 w-96 h-96 bg-neutral-800/10 rounded-full blur-3xl pointer-events-none"></div>

      {/* Top Header */}
      <header className="bg-neutral-900/90 backdrop-blur-xl border-b border-neutral-800/80 sticky top-0 z-30 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center space-x-3.5">
            <div className="w-10 h-10 rounded-xl bg-neutral-800 p-[1px] shadow-sm ">
              <div className="w-full h-full bg-black rounded-[11px] flex items-center justify-center">
                <GitCommit className="w-5 h-5 text-blue-400" />
              </div>
            </div>
            <div>
              <div className="flex items-center gap-2.5">
                <h1 className="text-sm font-bold tracking-tight text-white flex items-center gap-2">
                  <span>Commit Archaeology Engine</span>
                  <span className="text-[10px] font-mono font-medium px-2 py-0.5 rounded-full bg-blue-500/10 text-blue-300 border border-blue-500/25 flex items-center gap-1">
                    <Cpu className="w-3 h-3 text-blue-400" />
                    {selectedModel}
                  </span>
                </h1>
              </div>
              <p className="text-[11px] text-neutral-400 hidden sm:block">Deep Git History Postmortems & Emergent Code Intelligence</p>
            </div>
          </div>

          <div className="flex items-center space-x-2">
            {/* Rate limit & cooldown status monitor */}
            <RateLimitStatusHeader
              isAnyCooling={cooldown.isAnyCooling}
              maxRemainingSeconds={cooldown.maxRemainingSeconds}
              activeKey={cooldown.activeKey}
              mode={cooldown.cooldownMode}
            />

            <button 
              onClick={() => setIsSettingsPanelOpen(true)}
              className="inline-flex items-center space-x-1.5 px-3 py-1.5 rounded-xl bg-purple-500/10 hover:bg-purple-500/20 text-purple-300 border border-purple-500/30 text-xs font-semibold transition-all shadow-sm shadow-purple-500/20"
            >
              <Settings className="w-3.5 h-3.5 text-purple-400" />
              <span className="hidden md:inline">Settings</span>
            </button>

            <button 
              onClick={() => setShowGitHubModal(true)}
              disabled={cooldown.isCooling('push_github')}
              className="inline-flex items-center space-x-1.5 px-3.5 py-1.5 rounded-xl bg-white hover:bg-neutral-200 text-black text-xs font-semibold transition-all shadow-sm disabled:opacity-50"
            >
              {cooldown.isCooling('push_github') ? (
                <CooldownButtonContent
                  isCooling={true}
                  remainingSeconds={cooldown.getRemainingSeconds('push_github')}
                  idleText="Push"
                  coolingText="Push"
                />
              ) : (
                <>
                  <Github className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">Push</span>
                </>
              )}
            </button>

            <button 
              onClick={() => {
                if (userRepos.length === 0 && githubToken) verifyGitHubToken(githubToken);
                setShowRepoModal(true);
              }}
              disabled={fetchingHistory || analyzing || cooldown.isCooling('fetch_repo')}
              className="inline-flex items-center space-x-1.5 px-3.5 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold transition-all shadow-sm disabled:opacity-50"
            >
              {cooldown.isCooling('fetch_repo') ? (
                <CooldownButtonContent
                  isCooling={true}
                  remainingSeconds={cooldown.getRemainingSeconds('fetch_repo')}
                  idleText="Analyze Public Repo"
                  coolingText="Wait"
                />
              ) : (
                <>
                  <Globe className="w-3.5 h-3.5" />
                  <span>Analyze Public Repo</span>
                </>
              )}
            </button>

            <button 
              onClick={() => setShowPasteModal(true)}
              disabled={fetchingHistory || analyzing || cooldown.isCooling('run_analysis')}
              className="inline-flex items-center space-x-1.5 px-3 py-1.5 rounded-xl bg-neutral-900 hover:bg-neutral-800 text-xs font-medium text-neutral-300 transition-all border border-neutral-800 disabled:opacity-50"
            >
              <Terminal className="w-3.5 h-3.5 text-blue-400" />
              <span className="hidden sm:inline">Paste Log</span>
            </button>

            <button 
              onClick={loadSampleRepo}
              disabled={loading || analyzing || cooldown.isCooling('load_sample')}
              className="inline-flex items-center space-x-1.5 px-3 py-1.5 rounded-xl bg-neutral-900 hover:bg-neutral-800 text-xs font-medium text-neutral-300 transition-all border border-neutral-800 disabled:opacity-50"
            >
              {cooldown.isCooling('load_sample') ? (
                <CooldownButtonContent
                  isCooling={true}
                  remainingSeconds={cooldown.getRemainingSeconds('load_sample')}
                  idleText="Sample"
                  coolingText="Wait"
                />
              ) : loading || analyzing ? (
                <RefreshCw className="w-3.5 h-3.5 animate-spin text-blue-400" />
              ) : (
                <Sparkles className="w-3.5 h-3.5 text-amber-400" />
              )}
              <span className="hidden sm:inline">Sample</span>
            </button>
          </div>
        </div>
      </header>

      {/* Segmented Navigation Bar */}
      <nav role="tablist" aria-label="Archaeology View Tabs" className="bg-neutral-900/40 border-b border-neutral-800/60 sticky top-16 z-20 backdrop-blur-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex space-x-1.5 overflow-x-auto py-2.5 no-scrollbar">
            {[
              { id: 'dashboard', label: 'Archaeology Dashboard', icon: Layers, count: null, color: 'blue' },
              { id: 'correct', label: 'CORRECT.md', icon: CheckCircle2, count: stats?.totalCorrect, color: 'emerald' },
              { id: 'wrong', label: 'WRONG.md', icon: XCircle, count: stats?.totalWrong, color: 'rose' },
              { id: 'stuff', label: 'stuff.md', icon: Brain, count: null, color: 'purple' },
              { id: 'search', label: 'Search & Filter', icon: Search, count: null, color: 'blue' },
            ].map(tab => {
              const Icon = tab.icon;
              const isActive = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  role="tab"
                  id={`tab-${tab.id}`}
                  aria-selected={isActive}
                  aria-controls={`panel-${tab.id}`}
                  onClick={() => setActiveTab(tab.id as any)}
                  className={`group relative inline-flex items-center space-x-2 px-3.5 py-2 rounded-xl text-xs font-semibold transition-all whitespace-nowrap border ${
                    isActive
                      ? 'bg-neutral-900 text-white border-blue-500/40 shadow-sm shadow-none'
                      : 'bg-neutral-950/40 text-neutral-400 border-transparent hover:text-neutral-200 hover:bg-neutral-900/50'
                  }`}
                >
                  <Icon className={`w-3.5 h-3.5 ${
                    isActive 
                      ? tab.color === 'emerald' ? 'text-emerald-400'
                        : tab.color === 'rose' ? 'text-rose-400'
                        : tab.color === 'purple' ? 'text-purple-400'
                        : 'text-blue-400'
                      : 'text-neutral-500 group-hover:text-neutral-300'
                  }`} />
                  <span>{tab.label}</span>

                  {tab.count !== null && tab.count !== undefined && (
                    <span className={`px-2 py-0.5 rounded-full text-[10px] font-mono font-bold ${
                      tab.color === 'emerald' ? 'bg-emerald-500/15 text-emerald-300 border border-emerald-500/20' :
                      tab.color === 'rose' ? 'bg-rose-500/15 text-rose-300 border border-rose-500/20' :
                      'bg-neutral-800 text-neutral-300'
                    }`}>
                      {tab.count}
                    </span>
                  )}

                  {isActive && (
                    <span className="absolute bottom-0 left-3 right-3 h-[2px] bg-neutral-500 rounded-full"></span>
                  )}
                </button>
              );
            })}
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
        {fallbackNotice && (
          <div className="bg-amber-950/40 border border-amber-500/30 rounded-2xl px-4 py-3 text-xs text-amber-200 flex items-center justify-between gap-3 animate-fadeIn shadow-sm">
            <div className="flex items-center gap-2.5">
              <AlertCircle className="w-4 h-4 text-amber-400 shrink-0" />
              <span className="font-mono leading-relaxed">{fallbackNotice}</span>
            </div>
            <div className="flex items-center gap-2 shrink-0">
              {githubToken && (fallbackNotice.toLowerCase().includes('token') || fallbackNotice.toLowerCase().includes('pat')) && (
                <button
                  type="button"
                  onClick={() => {
                    clearGitHubToken();
                    setFallbackNotice("Cleared invalid token. Running on public unauthenticated stream.");
                  }}
                  className="px-2.5 py-1 bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 rounded-lg text-[11px] font-mono border border-amber-500/40 transition-colors"
                >
                  Clear Token
                </button>
              )}
              <button 
                type="button"
                onClick={() => setFallbackNotice(null)} 
                className="text-amber-400/80 hover:text-white p-1 rounded-lg hover:bg-amber-500/10 transition-colors"
                title="Dismiss notice"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {(loading || analyzing) ? (
          <div className="flex flex-col items-center justify-center py-32 space-y-4">
            <div className="relative w-12 h-12">
              <div className="absolute inset-0 rounded-full border-2 border-blue-500/20"></div>
              <div className="absolute inset-0 rounded-full border-2 border-blue-500 border-t-transparent animate-spin"></div>
            </div>
            <p className="text-xs font-mono text-neutral-400 tracking-wide">
              {analyzing ? `Gemini AI (${selectedModel}) synthesizing archaeology corpus...` : "Parsing repository git log structure..."}
            </p>
          </div>
        ) : (
          <>
            {/* Dashboard Tab */}
            {activeTab === 'dashboard' && stats && (
              <div className="space-y-6">
                {/* Instant Public Repository Analyzer Bar */}
                <div className="bg-neutral-900/90 rounded-2xl border border-neutral-800 p-4 sm:p-5 shadow-sm space-y-3">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <div className="w-7 h-7 rounded-lg bg-blue-500/10 border border-blue-500/25 flex items-center justify-center text-blue-400">
                        <Globe className="w-4 h-4" />
                      </div>
                      <div>
                        <h3 className="text-xs font-bold text-white uppercase tracking-wider font-mono flex items-center gap-2">
                          <span>Automatic Public Repository Engine</span>
                          <CooldownBadge
                            isCooling={cooldown.isCooling('fetch_repo')}
                            remainingSeconds={cooldown.getRemainingSeconds('fetch_repo')}
                            label="Cooldown"
                            showReadyState={true}
                          />
                        </h3>
                        <p className="text-[11px] text-neutral-400">
                          Analyze any public GitHub repo instantly without requiring an account or personal token.
                        </p>
                      </div>
                    </div>

                    <span className="self-start sm:self-auto text-[10px] font-mono px-2 py-0.5 rounded-md bg-emerald-500/10 text-emerald-300 border border-emerald-500/20 flex items-center gap-1">
                      <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                      Rate-Limited Limit Guard Active
                    </span>
                  </div>

                  <div className="flex flex-col sm:flex-row gap-2">
                    <div className="relative flex-1">
                      <Search className="w-3.5 h-3.5 absolute left-3.5 top-3 text-neutral-500" />
                      <input
                        type="text"
                        placeholder="Enter any public repo: owner/repo (e.g. facebook/react, torvalds/linux) or GitHub URL..."
                        value={directRepoInput}
                        onChange={(e) => setDirectRepoInput(e.target.value)}
                        onKeyDown={(e) => {
                          if (e.key === 'Enter' && directRepoInput.trim()) {
                            fetchAndAnalyzeRepo(directRepoInput.trim());
                          }
                        }}
                        className="w-full bg-black text-xs font-mono pl-9 pr-4 py-2.5 rounded-xl border border-neutral-800 text-neutral-200 placeholder-neutral-500 focus:outline-none focus:border-blue-500 transition-all"
                      />
                    </div>
                    <button
                      type="button"
                      onClick={() => directRepoInput.trim() && fetchAndAnalyzeRepo(directRepoInput.trim())}
                      disabled={!directRepoInput.trim() || fetchingHistory || analyzing || cooldown.isCooling('fetch_repo')}
                      className="px-5 py-2.5 bg-blue-600 hover:bg-blue-500 disabled:opacity-40 text-white text-xs font-semibold rounded-xl transition-all shadow-sm shrink-0 flex items-center justify-center gap-1.5 font-sans"
                    >
                      {cooldown.isCooling('fetch_repo') ? (
                        <CooldownButtonContent
                          isCooling={true}
                          remainingSeconds={cooldown.getRemainingSeconds('fetch_repo')}
                          idleText="Analyze Public Repo"
                          coolingText="Cooldown Active"
                        />
                      ) : fetchingHistory ? (
                        <>
                          <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                          <span>Fetching...</span>
                        </>
                      ) : (
                        <>
                          <Sparkles className="w-3.5 h-3.5" />
                          <span>Analyze Public Repo</span>
                        </>
                      )}
                    </button>
                  </div>

                  {/* 1-Click Popular Repositories from the 8 Largest Git Accounts */}
                  <div className="flex flex-wrap items-center gap-1.5 pt-1">
                    <span className="text-[10px] font-mono text-neutral-500 mr-1 flex items-center gap-1">
                      <Star className="w-3 h-3 text-amber-400 fill-amber-400" />
                      8 Largest Accounts:
                    </span>
                    {[
                      { name: 'microsoft/vscode', label: 'vscode', stars: '165k', badge: 'Microsoft' },
                      { name: 'google/protobuf', label: 'protobuf', stars: '67k', badge: 'Google' },
                      { name: 'apache/spark', label: 'spark', stars: '41k', badge: 'Apache' },
                      { name: 'facebook/react', label: 'react', stars: '230k', badge: 'Meta' },
                      { name: 'apple/swift', label: 'swift', stars: '68k', badge: 'Apple' },
                      { name: 'aws/aws-cli', label: 'aws-cli', stars: '16k', badge: 'AWS' },
                      { name: 'kubernetes/kubernetes', label: 'kubernetes', stars: '116k', badge: 'K8s' },
                      { name: 'nodejs/node', label: 'node', stars: '111k', badge: 'Node.js' },
                    ].map((sample) => (
                      <button
                        key={sample.name}
                        type="button"
                        onClick={() => {
                          setDirectRepoInput(sample.name);
                          fetchAndAnalyzeRepo(sample.name);
                        }}
                        disabled={fetchingHistory || analyzing || cooldown.isCooling('quick_scan')}
                        className="text-[10px] font-mono px-2.5 py-1 rounded-lg bg-neutral-950 hover:bg-neutral-800 text-neutral-300 hover:text-white border border-neutral-800 transition-all flex items-center gap-1.5 disabled:opacity-40 group"
                      >
                        <span className="text-[9px] px-1 py-0.2 rounded bg-neutral-800 text-blue-300 font-semibold group-hover:bg-blue-600 group-hover:text-white transition-colors">{sample.badge}</span>
                        <span>{sample.label}</span>
                        {cooldown.isCooling('quick_scan') ? (
                          <span className="text-amber-400 font-bold text-[9px] flex items-center gap-0.5">
                            <Timer className="w-2.5 h-2.5 animate-spin" />
                            {cooldown.getRemainingSeconds('quick_scan')}s
                          </span>
                        ) : (
                          <span className="text-amber-400/80 text-[9px]">★{sample.stars}</span>
                        )}
                      </button>
                    ))}
                    <button
                      type="button"
                      onClick={() => {
                        setShowRepoModal(true);
                      }}
                      className="text-[10px] font-mono px-2.5 py-1 rounded-lg bg-blue-600/20 hover:bg-blue-600/30 text-blue-300 border border-blue-500/40 transition-all flex items-center gap-1.5"
                    >
                      <Layers className="w-3 h-3 text-blue-400" />
                      <span>Repository Catalog & Batch Select ({selectedRepoFullNames.length > 0 ? `${selectedRepoFullNames.length} selected` : `${userRepos.length || 10} repos`})</span>
                    </button>
                  </div>
                </div>

                {/* Metric Cards Bento Grid */}
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                  <div className="bg-neutral-900/80 p-5 rounded-2xl border border-neutral-800/80 shadow-sm flex items-center justify-between hover:border-neutral-700 transition-all">
                    <div>
                      <p className="text-[10px] font-mono uppercase tracking-wider text-neutral-400">Total Commits</p>
                      <h3 className="text-2xl font-bold font-mono text-white mt-1">{stats.total}</h3>
                    </div>
                    <div className="w-10 h-10 rounded-xl bg-neutral-800/80 border border-neutral-700 flex items-center justify-center text-neutral-300">
                      <GitCommit className="w-5 h-5 text-blue-400" />
                    </div>
                  </div>

                  <div className="bg-neutral-900/80 p-5 rounded-2xl border border-neutral-800/80 shadow-sm flex items-center justify-between hover:border-emerald-500/30 transition-all">
                    <div>
                      <p className="text-[10px] font-mono uppercase tracking-wider text-emerald-400">Correct Commits</p>
                      <h3 className="text-2xl font-bold font-mono text-emerald-300 mt-1">{stats.totalCorrect}</h3>
                    </div>
                    <div className="w-10 h-10 rounded-xl bg-emerald-500/10 border border-emerald-500/25 flex items-center justify-center text-emerald-400">
                      <CheckCircle2 className="w-5 h-5" />
                    </div>
                  </div>

                  <div className="bg-neutral-900/80 p-5 rounded-2xl border border-neutral-800/80 shadow-sm flex items-center justify-between hover:border-rose-500/30 transition-all">
                    <div>
                      <p className="text-[10px] font-mono uppercase tracking-wider text-rose-400">Wrong / Reverted</p>
                      <h3 className="text-2xl font-bold font-mono text-rose-300 mt-1">{stats.totalWrong}</h3>
                    </div>
                    <div className="w-10 h-10 rounded-xl bg-rose-500/10 border border-rose-500/25 flex items-center justify-center text-rose-400">
                      <XCircle className="w-5 h-5" />
                    </div>
                  </div>

                  <div className="bg-neutral-900/80 p-5 rounded-2xl border border-neutral-800/80 shadow-sm flex items-center justify-between hover:border-purple-500/30 transition-all">
                    <div>
                      <p className="text-[10px] font-mono uppercase tracking-wider text-purple-400">File Hotspots</p>
                      <h3 className="text-2xl font-bold font-mono text-purple-300 mt-1">{Object.keys(stats.fileCounts).length}</h3>
                    </div>
                    <div className="w-10 h-10 rounded-xl bg-purple-500/10 border border-purple-500/25 flex items-center justify-center text-purple-400">
                      <Layers className="w-5 h-5" />
                    </div>
                  </div>
                </div>

                {/* Hotspots Chart & Subject Theme Chips */}
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                  {/* Top Touched Files Chart */}
                  <div className="lg:col-span-5 bg-neutral-900/80 p-6 rounded-2xl border border-neutral-800/80 shadow-sm flex flex-col">
                    <div className="flex items-center justify-between mb-4">
                      <h3 className="text-xs font-bold font-mono uppercase tracking-wider text-neutral-300 flex items-center gap-2">
                        <FileCode className="w-4 h-4 text-blue-400" />
                        <span>Architectural Hotspots</span>
                      </h3>
                      {/* Hotspots Limit Controls & Actions */}
                      <div className="flex items-center space-x-1">
                        <button
                          type="button"
                          onClick={handleSelectAllHotspotsCommits}
                          title="Select all commits touching these hotspot files"
                          className="px-2 py-0.5 rounded text-[10px] font-mono bg-purple-950/40 text-purple-300 border border-purple-500/30 hover:bg-purple-900/50 mr-1 flex items-center gap-1"
                        >
                          <CheckSquare className="w-2.5 h-2.5" />
                          <span>Select Commits</span>
                        </button>
                        {['all', 30, 20, 15, 10, 5].map((limitVal) => (
                          <button
                            key={String(limitVal)}
                            type="button"
                            onClick={() => setHotspotsLimit(limitVal as any)}
                            className={`px-2 py-0.5 rounded text-[10px] font-mono transition-colors ${
                              hotspotsLimit === limitVal
                                ? 'bg-blue-600 text-white font-bold'
                                : 'bg-neutral-800 text-neutral-400 hover:text-white'
                            }`}
                          >
                            {limitVal === 'all' ? '∞ Infinite' : `Top ${limitVal}`}
                          </button>
                        ))}
                      </div>
                    </div>
                    <div className="h-60 w-full">
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart 
                          data={fileChartData} 
                          layout="vertical" 
                          margin={{ left: -10, right: 10 }}
                          onClick={(state: any) => {
                            if (state && state.activePayload && state.activePayload[0]) {
                              const payload = state.activePayload[0].payload;
                              if (payload && payload.fullName) {
                                handleFilterByFile(payload.fullName);
                              }
                            }
                          }}
                        >
                          <XAxis type="number" allowDecimals={false} stroke="#64748b" fontSize={11} />
                          <YAxis dataKey="file" type="category" width={90} stroke="#94a3b8" fontSize={11} tickLine={false} />
                          <Tooltip 
                            contentStyle={{ backgroundColor: '#090d16', borderColor: '#334155', borderRadius: '10px', color: '#f8fafc', fontSize: '12px' }}
                            formatter={(value: any) => [`${value} commits (click to filter)`, 'Touched']} 
                          />
                          <Bar dataKey="count" fill="#6366f1" radius={[0, 4, 4, 0]} cursor="pointer" />
                        </BarChart>
                      </ResponsiveContainer>
                    </div>
                  </div>

                  {/* Recurring Keywords & User Themes */}
                  <div className="lg:col-span-7 bg-neutral-900/80 p-6 rounded-2xl border border-neutral-800/80 shadow-sm flex flex-col justify-between">
                    <div>
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-3">
                        <h3 className="text-xs font-bold font-mono uppercase tracking-wider text-neutral-300 flex items-center gap-2">
                          <Tag className="w-4 h-4 text-blue-400" />
                          Subject Keywords & Themes
                        </h3>
                        <div className="flex flex-wrap items-center gap-1.5">
                          {/* Theme Limits */}
                          <div className="flex items-center space-x-1 mr-1">
                            {['all', 25, 15, 10, 5].map((lim) => (
                              <button
                                key={String(lim)}
                                type="button"
                                onClick={() => setThemesLimit(lim as any)}
                                className={`px-1.5 py-0.5 rounded text-[10px] font-mono border transition-colors ${
                                  themesLimit === lim
                                    ? 'bg-blue-600 text-white border-blue-500 font-bold'
                                    : 'bg-neutral-800 text-neutral-400 border-neutral-700 hover:text-white'
                                }`}
                              >
                                {lim === 'all' ? '∞ Infinite' : `Top ${lim}`}
                              </button>
                            ))}
                          </div>

                          <button
                            type="button"
                            onClick={() => {
                              setSelectedThemeFilter(null);
                              setSearchQuery('');
                              setSelectedCommitHashes(commits.map(c => c.hash));
                              setActiveTab('search');
                            }}
                            className="inline-flex items-center space-x-1 text-[11px] font-mono text-neutral-300 hover:text-white px-2.5 py-1 rounded-lg bg-neutral-800 hover:bg-neutral-700 border border-neutral-700 transition-colors"
                          >
                            <CheckSquare className="w-3 h-3 text-blue-400" />
                            <span>Select All Commits ({commits.length})</span>
                          </button>
                          {selectedThemeFilter && (
                            <button
                              onClick={() => {
                                setSelectedThemeFilter(null);
                                setSearchQuery('');
                              }}
                              className="inline-flex items-center space-x-1 text-[11px] font-mono text-blue-400 hover:text-blue-300"
                            >
                              <X className="w-3 h-3" />
                              <span>Clear Filter ({selectedThemeFilter})</span>
                            </button>
                          )}
                        </div>
                      </div>
                      <p className="text-xs text-neutral-400 mb-4">
                        Click any keyword pill to filter commits (counted per commit across {commits.length} total commits), or add custom theme tags below:
                      </p>

                      <div className="flex flex-wrap gap-2 max-h-48 overflow-y-auto pr-1">
                        {displayedThemeList.map(({ theme, count, isCustom }) => {
                          const isSelected = selectedThemeFilter?.toLowerCase() === theme.toLowerCase();
                          return (
                            <div
                              key={theme}
                              onClick={() => {
                                handleSelectThemeFilter(theme);
                                setActiveTab('search');
                              }}
                              className={`group inline-flex items-center space-x-1.5 px-3 py-1.5 rounded-xl text-xs font-mono transition-all cursor-pointer border ${
                                isSelected
                                  ? 'bg-white text-black border-blue-400 shadow-sm'
                                  : isCustom
                                  ? 'bg-purple-950/40 text-purple-200 border-purple-500/30 hover:bg-purple-900/50'
                                  : 'bg-black text-neutral-300 border-neutral-800 hover:border-neutral-700 hover:text-white'
                              }`}
                            >
                              <span>{theme}</span>
                              <span className={`text-[10px] px-1.5 py-0.2 rounded-md font-bold ${
                                isSelected ? 'bg-blue-900 text-blue-100' : 'bg-neutral-800/80 text-neutral-400'
                              }`}>
                                {count}
                              </span>
                              {isCustom && (
                                <button
                                  type="button"
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    handleRemoveCustomTheme(theme);
                                  }}
                                  className="text-neutral-400 hover:text-rose-400 ml-1"
                                >
                                  <X className="w-3 h-3" />
                                </button>
                              )}
                            </div>
                          );
                        })}
                      </div>
                    </div>

                    <form onSubmit={handleAddCustomTheme} className="mt-5 pt-4 border-t border-neutral-800/80 flex items-center space-x-2">
                      <input
                        type="text"
                        placeholder="Add theme tag (e.g. refactor, auth, api)..."
                        value={newThemeInput}
                        onChange={(e) => setNewThemeInput(e.target.value)}
                        className="flex-1 bg-black text-xs px-3.5 py-2.5 rounded-xl border border-neutral-800 text-neutral-200 placeholder-neutral-600 focus:outline-none focus:border-blue-500 font-mono"
                      />
                      <button
                        type="submit"
                        className="inline-flex items-center space-x-1.5 bg-white hover:bg-neutral-200 text-black text-xs font-semibold px-4 py-2.5 rounded-xl transition-all shadow-sm"
                      >
                        <Plus className="w-3.5 h-3.5" />
                        <span>Add Tag</span>
                      </button>
                    </form>
                  </div>
                </div>

                {/* Archaeology Deliverables Download & Push Card */}
                <div className="bg-neutral-900 rounded-2xl p-6 sm:p-8 border border-neutral-800 shadow-sm flex flex-col md:flex-row items-center justify-between gap-6">
                  <div>
                    <h3 className="text-base font-bold text-white flex items-center gap-2">
                      <Brain className="w-5 h-5 text-blue-400" />
                      Archaeology Deliverables & Complete File Folder
                    </h3>
                    <p className="text-xs text-neutral-300 mt-1 max-w-xl">
                      Complete commit files ready for download or push to a new folder in GitHub. Every new commit is ordered chronologically newest-first.
                    </p>
                  </div>
                  <div className="flex flex-wrap gap-2.5">
                    <button
                      onClick={downloadFolderAsZip}
                      className="inline-flex items-center space-x-2 bg-blue-600 hover:bg-blue-500 text-white font-mono text-xs font-semibold px-4 py-2.5 rounded-xl transition-all shadow-sm"
                    >
                      <FolderDown className="w-4 h-4" />
                      <span>Download All (Complete Folder .zip)</span>
                    </button>
                    <button
                      onClick={() => setShowGitHubModal(true)}
                      className="inline-flex items-center space-x-2 bg-white hover:bg-neutral-200 text-black font-mono text-xs font-semibold px-4 py-2.5 rounded-xl transition-all shadow-sm"
                    >
                      <Github className="w-4 h-4" />
                      <span>Push to New Folder</span>
                    </button>
                    <button
                      onClick={() => downloadFile('CORRECT.md', correctMd)}
                      className="inline-flex items-center space-x-1.5 bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 font-mono text-xs px-3.5 py-2.5 rounded-xl transition-all"
                    >
                      <Download className="w-3.5 h-3.5" />
                      <span>CORRECT.md</span>
                    </button>
                    <button
                      onClick={() => downloadFile('WRONG.md', wrongMd)}
                      className="inline-flex items-center space-x-1.5 bg-rose-500/10 hover:bg-rose-500/20 text-rose-300 border border-rose-500/30 font-mono text-xs px-3.5 py-2.5 rounded-xl transition-all"
                    >
                      <Download className="w-3.5 h-3.5" />
                      <span>WRONG.md</span>
                    </button>
                    <button
                      onClick={() => downloadFile('stuff.md', stuffMd)}
                      className="inline-flex items-center space-x-1.5 bg-purple-500/10 hover:bg-purple-500/20 text-purple-300 border border-purple-500/30 font-mono text-xs px-3.5 py-2.5 rounded-xl transition-all"
                    >
                      <Download className="w-3.5 h-3.5" />
                      <span>stuff.md</span>
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* Markdown Viewers (CORRECT.md, WRONG.md, stuff.md) */}
            {(activeTab === 'correct' || activeTab === 'wrong' || activeTab === 'stuff') && (
              <div className="space-y-4">
                <div className="flex items-center justify-between bg-neutral-900/90 p-4 rounded-2xl border border-neutral-800 shadow-sm">
                  <div className="flex items-center space-x-3">
                    <div className="flex space-x-1.5">
                      <div className="w-3 h-3 rounded-full bg-rose-500/80"></div>
                      <div className="w-3 h-3 rounded-full bg-amber-500/80"></div>
                      <div className="w-3 h-3 rounded-full bg-emerald-500/80"></div>
                    </div>
                    <span className="font-mono text-xs font-bold text-white">
                      {activeTab === 'correct' ? 'CORRECT.md' : activeTab === 'wrong' ? 'WRONG.md' : 'stuff.md'}
                    </span>
                  </div>

                  <div className="flex items-center space-x-2">
                    <button
                      onClick={() => {
                        setAppendEntryFile(activeTab);
                        setShowAppendModal(true);
                      }}
                      className="inline-flex items-center space-x-1.5 bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-xs font-mono px-3.5 py-2 rounded-xl transition-all"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>Add / Append to File</span>
                    </button>
                    <button
                      onClick={() => setShowGitHubModal(true)}
                      className="inline-flex items-center space-x-1.5 bg-blue-500/10 hover:bg-blue-500/20 text-blue-300 border border-blue-500/30 text-xs font-mono px-3.5 py-2 rounded-xl transition-all"
                    >
                      <Github className="w-3.5 h-3.5" />
                      <span>Push to GitHub</span>
                    </button>
                    <button
                      onClick={() => {
                        const content = activeTab === 'correct' ? correctMd : activeTab === 'wrong' ? wrongMd : stuffMd;
                        const filename = `${activeTab}.md`;
                        copyToClipboard(content, activeTab);
                        downloadFile(filename, content);
                      }}
                      className="inline-flex items-center space-x-1.5 bg-neutral-900 hover:bg-neutral-800 text-xs text-neutral-200 font-mono px-3.5 py-2 rounded-xl border border-neutral-800 transition-all"
                    >
                      {copiedTab === activeTab ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5 text-neutral-400" />}
                      <span>{copiedTab === activeTab ? 'Copied & Exported!' : 'Copy / Export'}</span>
                    </button>
                  </div>
                </div>

                <div className="bg-black rounded-2xl border border-neutral-800 shadow-sm overflow-hidden">
                  <pre className="p-6 text-xs font-mono text-neutral-300 whitespace-pre-wrap overflow-x-auto leading-relaxed selection:bg-blue-600 selection:text-white">
                    {activeTab === 'correct' ? correctMd : activeTab === 'wrong' ? wrongMd : stuffMd}
                  </pre>
                </div>
              </div>
            )}

            {/* Search & Filter Tab */}
            {activeTab === 'search' && (
              <div className="space-y-6">
                <div className="bg-neutral-900/90 p-6 rounded-2xl border border-neutral-800 shadow-sm space-y-4">
                  <div className="flex items-center justify-between">
                    <h2 className="text-xs font-bold font-mono uppercase tracking-wider text-neutral-300 flex items-center gap-2">
                      <ListFilter className="w-4 h-4 text-blue-400" />
                      <span>Search & Filter Commit History</span>
                    </h2>
                    {(searchQuery || selectedThemeFilter) && (
                      <button
                        onClick={() => {
                          setSearchQuery('');
                          setSelectedThemeFilter(null);
                        }}
                        className="text-xs text-blue-400 hover:text-blue-300 font-mono"
                      >
                        Clear Filters
                      </button>
                    )}
                  </div>
                  <div className="relative">
                    <Search className="absolute left-4 top-3.5 w-4 h-4 text-neutral-500" />
                    <input
                      type="text"
                      placeholder="Search commit subject, hash, author, modified files, or failure reason..."
                      value={searchQuery}
                      onChange={(e) => {
                        setSearchQuery(e.target.value);
                        setSelectedThemeFilter(null);
                      }}
                      className="w-full pl-11 pr-4 py-3 rounded-xl border border-neutral-800 bg-black text-xs font-mono text-neutral-200 placeholder-neutral-600 focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500/50"
                    />
                  </div>

                  {/* Select All Limits for Commits */}
                  <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-neutral-800/60">
                    <div className="flex flex-wrap items-center gap-1.5">
                      <span className="text-[11px] font-mono text-neutral-400 flex items-center gap-1 mr-1">
                        <Sliders className="w-3 h-3 text-blue-400" />
                        Select Limits:
                      </span>

                      {/* Master Checkbox / Select All */}
                      <button
                        type="button"
                        onClick={() => handleSelectAllCommits('all')}
                        className="px-2.5 py-1 bg-neutral-800 hover:bg-neutral-700 text-neutral-200 text-xs font-mono rounded-lg border border-neutral-700 transition-colors flex items-center gap-1.5"
                      >
                        <input
                          type="checkbox"
                          checked={filteredCommits.length > 0 && filteredCommits.every(c => selectedCommitHashes.includes(c.hash))}
                          ref={el => {
                            if (el) {
                              const some = filteredCommits.some(c => selectedCommitHashes.includes(c.hash));
                              const all = filteredCommits.length > 0 && filteredCommits.every(c => selectedCommitHashes.includes(c.hash));
                              el.indeterminate = some && !all;
                            }
                          }}
                          onChange={() => {}}
                          className="w-3.5 h-3.5 rounded border-neutral-600 bg-neutral-900 text-blue-600 pointer-events-none"
                        />
                        <span>∞ Infinite (All {filteredCommits.length})</span>
                      </button>

                      {[250, 100, 50, 25, 10, 5].map((num) => (
                        <button
                          key={num}
                          type="button"
                          onClick={() => handleSelectAllCommits(num)}
                          className="px-2 py-1 bg-neutral-900 hover:bg-neutral-800 text-neutral-300 text-xs font-mono rounded-lg border border-neutral-800 hover:border-neutral-700 transition-colors"
                        >
                          Top {num}
                        </button>
                      ))}

                      {/* Custom Numeric Limit Input */}
                      <div className="flex items-center gap-1 bg-black border border-neutral-800 rounded-lg px-2 py-0.5">
                        <input
                          type="number"
                          placeholder="Custom"
                          value={customCommitLimitInput}
                          onChange={(e) => setCustomCommitLimitInput(e.target.value)}
                          onKeyDown={(e) => {
                            if (e.key === 'Enter') {
                              const n = parseInt(customCommitLimitInput, 10);
                              if (!isNaN(n) && n > 0) handleSelectAllCommits(n);
                            }
                          }}
                          className="w-14 bg-transparent text-xs font-mono text-neutral-200 outline-none placeholder-neutral-600"
                          min="1"
                          max={filteredCommits.length}
                        />
                        <button
                          type="button"
                          onClick={() => {
                            const n = parseInt(customCommitLimitInput, 10);
                            if (!isNaN(n) && n > 0) handleSelectAllCommits(n);
                          }}
                          className="text-[10px] font-mono text-blue-400 hover:text-blue-300 font-bold"
                        >
                          Apply
                        </button>
                      </div>

                      <button
                        type="button"
                        onClick={() => handleSelectAllCommits('correct')}
                        className="px-2 py-1 bg-emerald-950/30 hover:bg-emerald-900/40 text-emerald-300 text-xs font-mono rounded-lg border border-emerald-500/30 transition-colors"
                      >
                        Correct Only
                      </button>
                      <button
                        type="button"
                        onClick={() => handleSelectAllCommits('wrong')}
                        className="px-2 py-1 bg-rose-950/30 hover:bg-rose-900/40 text-rose-300 text-xs font-mono rounded-lg border border-rose-500/30 transition-colors"
                      >
                        Wrong Only
                      </button>
                      <button
                        type="button"
                        onClick={() => handleSelectAllCommits('invert')}
                        className="px-2 py-1 bg-neutral-900 hover:bg-neutral-800 text-neutral-400 hover:text-white text-xs font-mono rounded-lg border border-neutral-800 transition-colors"
                      >
                        Invert
                      </button>
                    </div>

                    {selectedCommitHashes.length > 0 && (
                      <button
                        type="button"
                        onClick={() => handleSelectAllCommits('clear')}
                        className="text-xs font-mono text-neutral-400 hover:text-white px-2 py-1 rounded bg-neutral-800/80"
                      >
                        Clear Selection ({selectedCommitHashes.length})
                      </button>
                    )}
                  </div>
                </div>

                {/* Batch Action Toolbar when commits are selected */}
                {selectedCommitHashes.length > 0 && (
                  <div className="sticky top-20 z-20 p-4 rounded-2xl bg-blue-950/90 backdrop-blur-md border border-blue-500/40 shadow-lg flex flex-col sm:flex-row items-center justify-between gap-3 animate-in fade-in">
                    <div className="flex items-center gap-2">
                      <div className="w-6 h-6 rounded-lg bg-blue-500/20 flex items-center justify-center text-blue-300">
                        <CheckCheck className="w-3.5 h-3.5" />
                      </div>
                      <span className="text-xs font-mono text-blue-200 font-semibold">
                        {selectedCommitHashes.length} commits selected
                      </span>
                    </div>

                    <div className="flex flex-wrap items-center gap-2">
                      <button
                        type="button"
                        onClick={focusAnalyzeSelectedCommits}
                        disabled={analyzing}
                        className="px-3.5 py-1.5 bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white text-xs font-semibold rounded-xl transition-all shadow-sm flex items-center gap-1.5"
                      >
                        <Brain className="w-3.5 h-3.5" />
                        <span>Focus Analyze Selected ({selectedCommitHashes.length})</span>
                      </button>

                      <button
                        type="button"
                        onClick={copySelectedCommitsMarkdown}
                        className="px-3 py-1.5 bg-neutral-800 hover:bg-neutral-700 text-neutral-200 text-xs font-mono rounded-xl border border-neutral-700 transition-all flex items-center gap-1.5"
                      >
                        {copiedTab === 'selected_commits' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5 text-neutral-400" />}
                        <span>Copy Markdown</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => setSelectedCommitHashes([])}
                        className="text-xs font-mono text-neutral-400 hover:text-white px-2 py-1"
                      >
                        Deselect
                      </button>
                    </div>
                  </div>
                )}

                <div className="space-y-3">
                  {filteredCommits.length === 0 ? (
                    <div className="text-center py-16 bg-neutral-900/40 rounded-2xl border border-neutral-800/80 text-neutral-500 text-xs font-mono">
                      No commits match current search filter criteria.
                    </div>
                  ) : (
                    filteredCommits.map((c) => {
                      const isSelected = selectedCommitHashes.includes(c.hash);
                      return (
                        <div 
                          key={c.hash} 
                          onClick={() => handleToggleCommitSelection(c.hash)}
                          className={`p-5 rounded-2xl border transition-all shadow-sm space-y-3 cursor-pointer ${
                            isSelected 
                              ? 'bg-blue-950/20 border-blue-500/50' 
                              : 'bg-neutral-900/80 border-neutral-800/80 hover:border-neutral-700'
                          }`}
                        >
                          <div className="flex items-center justify-between">
                            <div className="flex items-center space-x-2.5">
                              <input
                                type="checkbox"
                                checked={isSelected}
                                onChange={(e) => {
                                  e.stopPropagation();
                                  handleToggleCommitSelection(c.hash);
                                }}
                                className="w-4 h-4 rounded border-neutral-700 bg-neutral-900 text-blue-600 focus:ring-blue-500 cursor-pointer"
                              />
                              <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-mono font-bold uppercase ${
                                c.verdict === 'OK' ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' : 'bg-rose-500/10 text-rose-400 border border-rose-500/20'
                              }`}>
                                {c.verdict}
                              </span>
                              <span className="font-mono text-xs text-blue-400 font-bold">{c.shortHash}</span>
                              <span className="text-xs text-neutral-500">• {c.date}</span>
                            </div>
                            {c.fixedBy && (
                              <span className="text-[11px] font-mono text-blue-300 bg-blue-500/10 px-2.5 py-1 rounded-lg border border-blue-500/20">
                                Fixed by: {c.fixedBy}
                              </span>
                            )}
                          </div>

                          <h3 className="text-sm font-semibold text-neutral-200">{c.subject}</h3>
                          {c.reason && (
                            <p className="text-xs text-rose-300 bg-rose-500/10 p-3 rounded-xl border border-rose-500/20 font-mono">
                              Reason: {c.reason}
                            </p>
                          )}

                          <div className="flex flex-wrap gap-1.5 pt-1">
                            {c.files.map((f: string) => (
                              <span key={f} className="text-[11px] bg-black text-neutral-400 px-2.5 py-1 rounded-lg font-mono border border-neutral-800">
                                {f}
                              </span>
                            ))}
                          </div>
                        </div>
                      );
                    })
                  )}
                </div>
              </div>
            )}
          </>
        )}
      </main>

      {/* Slide-out Settings Side Panel (Drawer) */}
      {isSettingsPanelOpen && (
        <>
          {/* Backdrop */}
          <div 
            className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm transition-opacity" 
            onClick={() => setIsSettingsPanelOpen(false)}
          ></div>

          {/* Right Side Panel */}
          <div className="fixed inset-y-0 right-0 z-50 w-full max-w-md bg-neutral-900 border-l border-neutral-800 shadow-sm flex flex-col transform transition-transform duration-300 ease-in-out">
            <div className="flex items-center justify-between p-6 border-b border-neutral-800/80 bg-neutral-900/90 backdrop-blur-md sticky top-0 z-10">
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 rounded-xl bg-purple-500/10 border border-purple-500/20 flex items-center justify-center text-purple-400">
                  <Settings className="w-4 h-4" />
                </div>
                <h2 className="text-sm font-bold text-white tracking-tight">System Settings</h2>
              </div>
              <button 
                onClick={() => setIsSettingsPanelOpen(false)}
                className="text-neutral-400 hover:text-white p-1.5 rounded-lg hover:bg-neutral-800 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-6 pb-32 scroll-smooth custom-scrollbar">
              {configSavedNotice && (
                <div className="mb-6 p-3 bg-emerald-500/10 border border-emerald-500/20 rounded-xl flex items-center gap-2 text-emerald-300 text-xs font-mono animate-in slide-in-from-top-2">
                  <CheckCircle2 className="w-4 h-4 shrink-0" />
                  <span>Preferences saved successfully to local state.</span>
                </div>
              )}

              <form id="settings-form" onSubmit={saveConfigSettings} className="space-y-8">
                {/* Rate Limits & Cooldown Protection Settings */}
                <div className="space-y-4">
                  <div className="flex items-center justify-between text-amber-400 pb-2 border-b border-neutral-800/50">
                    <div className="flex items-center gap-2">
                      <Gauge className="w-4 h-4" />
                      <h3 className="text-xs font-bold font-mono uppercase tracking-widest">Rate Limit & Cooldown Controls</h3>
                    </div>
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-amber-500/15 text-amber-300 border border-amber-500/30 font-bold">
                      Active Shield
                    </span>
                  </div>

                  <div className="space-y-3 bg-black p-3.5 rounded-xl border border-neutral-800">
                    <label className="text-xs font-semibold text-neutral-300 block">Rate-Limit Cooldown Profile</label>
                    <div className="grid grid-cols-3 gap-2">
                      {[
                        { id: 'standard', name: 'Standard', desc: '5s GitHub / 8s Push', icon: Zap },
                        { id: 'strict', name: 'Strict (Safe)', desc: '10s GitHub / 15s Push', icon: ShieldCheck },
                        { id: 'relaxed', name: 'Relaxed', desc: '2s GitHub / 4s Push', icon: RefreshCw },
                      ].map((mode) => (
                        <button
                          key={mode.id}
                          type="button"
                          onClick={() => cooldown.setCooldownMode(mode.id as any)}
                          className={`p-2.5 rounded-xl border text-left flex flex-col justify-between transition-all ${
                            cooldown.cooldownMode === mode.id
                              ? 'bg-amber-500/10 border-amber-500/50 text-white'
                              : 'bg-neutral-900 border-neutral-800 text-neutral-400 hover:text-neutral-200'
                          }`}
                        >
                          <div className="flex items-center justify-between mb-1">
                            <span className="text-xs font-bold">{mode.name}</span>
                            <mode.icon className={`w-3.5 h-3.5 ${cooldown.cooldownMode === mode.id ? 'text-amber-400' : 'text-neutral-500'}`} />
                          </div>
                          <span className="text-[9px] text-neutral-500 font-mono">{mode.desc}</span>
                        </button>
                      ))}
                    </div>
                    <p className="text-[10px] text-neutral-500 pt-1">
                      Cooldown timers automatically delay rapid requests to prevent anonymous & authenticated GitHub REST API rate limits (HTTP 429).
                    </p>
                  </div>

                  {/* Live Cooldown Subsystem Monitors */}
                  <div className="space-y-2 bg-neutral-950 p-3.5 rounded-xl border border-neutral-800/80">
                    <div className="flex items-center justify-between text-xs font-semibold text-neutral-300">
                      <span>Subsystem Timers</span>
                      <span className="text-[10px] font-mono text-neutral-400">
                        {cooldown.isAnyCooling ? `Cooling (${cooldown.maxRemainingSeconds}s)` : 'All Ready'}
                      </span>
                    </div>
                    <div className="space-y-1.5 pt-1 font-mono text-[10px]">
                      {[
                        { key: 'fetch_repo' as const, label: 'Repository History Fetch' },
                        { key: 'run_analysis' as const, label: 'Gemini Analysis Engine' },
                        { key: 'push_github' as const, label: 'GitHub Push & Commit' },
                        { key: 'load_repos' as const, label: 'Account Repo Browser' },
                        { key: 'verify_pat' as const, label: 'PAT Verification' },
                        { key: 'quick_scan' as const, label: '1-Click Public Scans' },
                      ].map((item) => {
                        const isCool = cooldown.isCooling(item.key);
                        const rem = cooldown.getRemainingSeconds(item.key);
                        return (
                          <div key={item.key} className="flex items-center justify-between py-1 border-b border-neutral-900 last:border-0">
                            <span className="text-neutral-400">{item.label}</span>
                            {isCool ? (
                              <span className="text-amber-400 font-bold flex items-center gap-1">
                                <Timer className="w-3 h-3 animate-spin" />
                                {rem}s
                              </span>
                            ) : (
                              <span className="text-emerald-400/80">READY</span>
                            )}
                          </div>
                        );
                      })}
                    </div>
                  </div>
                </div>

                {/* GitHub Preferences */}
                <div className="space-y-4">
                  <div className="flex items-center gap-2 text-blue-400 pb-2 border-b border-neutral-800/50">
                    <Github className="w-4 h-4" />
                    <h3 className="text-xs font-bold font-mono uppercase tracking-widest">GitHub Configuration</h3>
                  </div>

                  <div className="space-y-4">
                    <div className="space-y-1.5">
                      <label className="text-xs font-semibold text-neutral-300">GitHub Personal Access Token (PAT)</label>
                      <div className="flex space-x-2">
                        <div className="relative flex-1">
                          <input
                            type={showPatToken ? 'text' : 'password'}
                            placeholder="ghp_xxxxxxxxxxxxxxxxxxxx"
                            value={githubToken}
                            onChange={(e) => {
                              setGithubToken(e.target.value);
                              setTokenError(null);
                            }}
                            className="w-full bg-black text-xs font-mono pl-3.5 pr-10 py-2.5 rounded-xl border border-neutral-800 text-neutral-200 placeholder-neutral-600 focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500/50 transition-all"
                          />
                          <button
                            type="button"
                            onClick={() => setShowPatToken(!showPatToken)}
                            className="absolute right-3 top-2.5 text-neutral-500 hover:text-neutral-300 transition-colors"
                          >
                            {showPatToken ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                          </button>
                        </div>
                        <button
                          type="button"
                          onClick={() => verifyGitHubToken(githubToken)}
                          disabled={verifyingToken || !githubToken.trim()}
                          className="px-3.5 py-2.5 bg-neutral-800 hover:bg-neutral-700 text-[11px] font-semibold text-neutral-200 rounded-xl transition-all border border-neutral-700 disabled:opacity-50 shrink-0"
                        >
                          {verifyingToken ? <RefreshCw className="w-3.5 h-3.5 animate-spin mx-auto" /> : 'Verify'}
                        </button>
                      </div>
                      
                      <div className="flex items-center justify-between mt-1.5">
                        <a
                          href="https://github.com/settings/tokens/new?scopes=repo"
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-[10px] text-blue-400 hover:text-blue-300 inline-flex items-center gap-1"
                        >
                          Generate a new token <ExternalLink className="w-3 h-3" />
                        </a>
                      </div>

                      {tokenError && (
                        <div className="mt-2 text-xs font-mono bg-rose-950/40 border border-rose-500/30 p-3 rounded-xl space-y-2 text-rose-200">
                          <div className="flex items-start justify-between gap-2">
                            <div className="flex items-center gap-1.5 font-bold text-rose-300">
                              <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
                              <span>{tokenError}</span>
                            </div>
                            {githubToken && (
                              <button
                                type="button"
                                onClick={clearGitHubToken}
                                className="px-2 py-0.5 bg-rose-500/20 hover:bg-rose-500/30 text-rose-200 rounded-lg text-[10px] font-mono border border-rose-500/40 transition-colors shrink-0"
                              >
                                Clear Token
                              </button>
                            )}
                          </div>

                          {tokenDiagnostics && (
                            <div className="bg-black/60 p-2.5 rounded-lg text-[11px] space-y-1.5 border border-rose-900/50 text-neutral-300 font-mono">
                              <div className="grid grid-cols-2 gap-x-3 gap-y-1 text-[10px] text-neutral-400 border-b border-neutral-800 pb-1.5">
                                <div><span className="text-neutral-500">Status Code:</span> <span className="font-bold text-rose-300">{tokenDiagnostics.httpStatus || 'N/A'}</span></div>
                                <div><span className="text-neutral-500">Auth Scheme:</span> <span className="text-neutral-200">{tokenDiagnostics.authScheme || 'Bearer'}</span></div>
                                <div><span className="text-neutral-500">Fine-grained:</span> <span className="text-neutral-200">{tokenDiagnostics.isFineGrained ? 'Yes' : 'No'}</span></div>
                                <div><span className="text-neutral-500">Scopes Found:</span> <span className="text-neutral-200">{tokenDiagnostics.scopesFound?.length ? tokenDiagnostics.scopesFound.join(', ') : 'None'}</span></div>
                                {tokenDiagnostics.tokenExpiration && <div><span className="text-neutral-500">Expiration:</span> <span className="text-amber-300">{tokenDiagnostics.tokenExpiration}</span></div>}
                                {tokenDiagnostics.rateLimitRemaining !== undefined && <div><span className="text-neutral-500">Rate Limit:</span> <span className="text-neutral-200">{tokenDiagnostics.rateLimitRemaining}/{tokenDiagnostics.rateLimitLimit}</span></div>}
                              </div>
                              {tokenDiagnostics.rawGitHubMessage && (
                                <div className="text-[11px] text-rose-300">
                                  <strong>GitHub API Message:</strong> "{tokenDiagnostics.rawGitHubMessage}"
                                </div>
                              )}
                              {tokenDiagnostics.actionableAdvice && (
                                <div className="text-[11px] text-amber-300 flex items-start justify-between gap-2 pt-0.5">
                                  <div className="flex items-start gap-1">
                                    <Info className="w-3.5 h-3.5 shrink-0 mt-0.5 text-amber-400" />
                                    <span>{tokenDiagnostics.actionableAdvice}</span>
                                  </div>
                                  {(tokenDiagnostics.code === 'RATE_LIMITED' || tokenDiagnostics.rateLimitRemaining === '0') && (
                                    <button
                                      type="button"
                                      onClick={async () => {
                                        await loadSampleRepo();
                                        setIsSettingsPanelOpen(false);
                                        setShowRepoModal(false);
                                        setFallbackNotice("Switched to Local Archeology Mode with built-in commits & diff telemetry.");
                                      }}
                                      className="px-2.5 py-1 bg-amber-500/20 hover:bg-amber-500/30 text-amber-200 rounded-lg text-[10px] font-mono border border-amber-500/40 transition-colors shrink-0 whitespace-nowrap"
                                    >
                                      Use Local Mode
                                    </button>
                                  )}
                                </div>
                              )}
                            </div>
                          )}
                        </div>
                      )}

                      {githubUser && (
                        <div className="mt-2 text-xs font-mono bg-emerald-950/40 border border-emerald-500/30 p-3 rounded-xl space-y-2 text-emerald-200">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center space-x-2">
                              <img src={githubUser.avatar_url} alt={githubUser.login} className="w-6 h-6 rounded-full border border-emerald-500/50" />
                              <span className="font-bold text-emerald-300">Connected as @{githubUser.login}</span>
                            </div>
                            <span className="text-[10px] bg-emerald-500/20 text-emerald-300 px-2 py-0.5 rounded-full border border-emerald-500/30 font-bold">
                              Verified
                            </span>
                          </div>

                          {tokenDiagnostics && (
                            <div className="bg-black/60 p-2.5 rounded-lg text-[10px] space-y-1 border border-emerald-900/50 text-neutral-300 font-mono">
                              <div className="flex flex-wrap items-center gap-1.5">
                                <span className="text-neutral-500">Active Scopes:</span>
                                {tokenDiagnostics.scopesFound && tokenDiagnostics.scopesFound.length > 0 ? (
                                  tokenDiagnostics.scopesFound.map((s: string) => (
                                    <span key={s} className="bg-neutral-800 border border-neutral-700 text-emerald-300 px-1.5 py-0.2 rounded font-mono">
                                      {s}
                                    </span>
                                  ))
                                ) : (
                                  <span className="text-amber-300 bg-amber-500/10 px-1.5 py-0.2 rounded border border-amber-500/30">
                                    {tokenDiagnostics.isFineGrained ? 'Fine-Grained PAT (Scoped by Repo)' : 'No OAuth Scopes (Read-Only)'}
                                  </span>
                                )}
                              </div>
                              <div className="flex items-center justify-between text-neutral-400 pt-0.5">
                                <span>Rate Limit: {tokenDiagnostics.rateLimitRemaining || '5000'}/{tokenDiagnostics.rateLimitLimit || '5000'}</span>
                                <span>Expires: {tokenDiagnostics.tokenExpiration || 'Never / Classic'}</span>
                              </div>
                            </div>
                          )}
                        </div>
                      )}
                    </div>

                    <div className="space-y-1.5">
                      <div className="flex items-center justify-between">
                        <label className="text-xs font-semibold text-neutral-300">GitHub Account / Username</label>
                        <span className="text-[10px] text-neutral-500">Optional for public exploration</span>
                      </div>
                      <input
                        type="text"
                        placeholder="e.g. octocat, torvalds, or leave blank"
                        value={githubAccount}
                        onChange={(e) => setGithubAccount(e.target.value)}
                        className="w-full bg-black text-xs font-mono px-3.5 py-2.5 rounded-xl border border-neutral-800 text-neutral-200 placeholder-neutral-600 focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500/50 transition-all"
                      />
                      <p className="text-[10px] text-neutral-500">
                        When left blank, the engine automatically browses and discovers public GitHub accounts and repositories.
                      </p>
                    </div>

                    <div className="space-y-1.5 pt-2 border-t border-neutral-900">
                      <label className="flex items-center justify-between text-xs font-semibold text-neutral-300">
                        <span>Max Commits to Fetch per Scan</span>
                        <span className="text-blue-400 font-mono font-bold">
                          {analyzeEntireHistory || commitLimit === 'all' ? '∞ Infinite (All History)' : `${commitLimit} Commits`}
                        </span>
                      </label>
                      <div className="flex items-center gap-1.5">
                        {['all', 5000, 1000, 500, 100].map((lim) => (
                          <button
                            key={String(lim)}
                            type="button"
                            onClick={() => {
                              setCommitLimit(lim as any);
                              if (lim === 'all') setAnalyzeEntireHistory(true);
                              else setAnalyzeEntireHistory(false);
                            }}
                            className={`flex-1 py-1.5 rounded-lg text-xs font-mono border transition-all ${
                              (commitLimit === lim || (lim === 'all' && analyzeEntireHistory))
                                ? 'bg-blue-600/30 text-blue-300 border-blue-500/50 font-bold'
                                : 'bg-neutral-900 text-neutral-400 border-neutral-800 hover:text-white'
                            }`}
                          >
                            {lim === 'all' ? '∞ Infinite' : lim}
                          </button>
                        ))}
                      </div>
                      <p className="text-[10px] text-neutral-500">
                        Default is infinite: pulls all available history across the repository without pagination caps.
                      </p>
                    </div>

                  </div>
                </div>

                {/* Variable Selection Limits Configuration */}
                <div className="space-y-4">
                  <div className="flex items-center justify-between gap-2 text-blue-400 pb-2 border-b border-neutral-800/50">
                    <div className="flex items-center gap-2">
                      <Sliders className="w-4 h-4" />
                      <h3 className="text-xs font-bold font-mono uppercase tracking-widest">Select All Limits for Every Variable</h3>
                    </div>
                    <button
                      type="button"
                      onClick={handleSetAllLimitsToInfinite}
                      className="px-2.5 py-1 bg-blue-600 hover:bg-blue-500 text-white text-[11px] font-mono font-bold rounded-lg transition-all shadow-sm flex items-center gap-1"
                    >
                      <span>⚡ Set All Limits to Infinite</span>
                    </button>
                  </div>

                  <div className="space-y-4 bg-black p-3.5 rounded-xl border border-neutral-800">
                    {/* Hotspot Display Limit */}
                    <div className="space-y-1.5">
                      <label className="flex items-center justify-between text-xs font-semibold text-neutral-300">
                        <span>Architectural Hotspots Display Limit</span>
                        <span className="text-purple-400 font-mono text-[11px] font-bold">
                          {hotspotsLimit === 'all' ? '∞ Infinite (All Files)' : `Top ${hotspotsLimit} Files`}
                        </span>
                      </label>
                      <div className="flex items-center gap-1.5">
                        {['all', 30, 20, 15, 10, 5].map((lim) => (
                          <button
                            key={String(lim)}
                            type="button"
                            onClick={() => setHotspotsLimit(lim as any)}
                            className={`flex-1 py-1.5 rounded-lg text-xs font-mono border transition-all ${
                              hotspotsLimit === lim
                                ? 'bg-purple-600/30 text-purple-300 border-purple-500/50 font-bold'
                                : 'bg-neutral-900 text-neutral-400 border-neutral-800 hover:text-white'
                            }`}
                          >
                            {lim === 'all' ? '∞ Infinite' : `Top ${lim}`}
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* Commit Select All Default Limit */}
                    <div className="space-y-1.5 pt-2 border-t border-neutral-900">
                      <label className="flex items-center justify-between text-xs font-semibold text-neutral-300">
                        <span>Commit Selection Batch Limit</span>
                        <span className="text-blue-400 font-mono text-[11px] font-bold">
                          {commitSelectLimit === 'all' ? '∞ Infinite (All Commits)' : `Top ${commitSelectLimit} Commits`}
                        </span>
                      </label>
                      <div className="flex items-center gap-1.5">
                        {['all', 250, 100, 50, 25, 10, 5].map((lim) => (
                          <button
                            key={String(lim)}
                            type="button"
                            onClick={() => {
                              setCommitSelectLimit(lim as any);
                              if (lim === 'all') handleSelectAllCommits('all');
                              else handleSelectAllCommits(lim as number);
                            }}
                            className={`flex-1 py-1.5 rounded-lg text-xs font-mono border transition-all ${
                              commitSelectLimit === lim
                                ? 'bg-blue-600/30 text-blue-300 border-blue-500/50 font-bold'
                                : 'bg-neutral-900 text-neutral-400 border-neutral-800 hover:text-white'
                            }`}
                          >
                            {lim === 'all' ? '∞ Infinite' : lim}
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* Repository Batch Limit */}
                    <div className="space-y-1.5 pt-2 border-t border-neutral-900">
                      <label className="flex items-center justify-between text-xs font-semibold text-neutral-300">
                        <span>Repository Selection Limit</span>
                        <span className="text-emerald-400 font-mono text-[11px] font-bold">
                          {repoSelectLimit === 'all' ? '∞ Infinite (All Repos)' : `Top ${repoSelectLimit} Repos`}
                        </span>
                      </label>
                      <div className="flex items-center gap-1.5">
                        {['all', 50, 25, 10, 5, 3].map((lim) => (
                          <button
                            key={String(lim)}
                            type="button"
                            onClick={() => {
                              setRepoSelectLimit(lim as any);
                              if (lim === 'all') handleSelectAllRepos('all');
                              else handleSelectAllRepos(lim as number);
                            }}
                            className={`flex-1 py-1.5 rounded-lg text-xs font-mono border transition-all ${
                              repoSelectLimit === lim
                                ? 'bg-emerald-600/30 text-emerald-300 border-emerald-500/50 font-bold'
                                : 'bg-neutral-900 text-neutral-400 border-neutral-800 hover:text-white'
                            }`}
                          >
                            {lim === 'all' ? '∞ Infinite' : lim}
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* Subject Keywords & Themes Limit */}
                    <div className="space-y-1.5 pt-2 border-t border-neutral-900">
                      <label className="flex items-center justify-between text-xs font-semibold text-neutral-300">
                        <span>Subject Keywords & Themes Limit</span>
                        <span className="text-amber-400 font-mono text-[11px] font-bold">
                          {themesLimit === 'all' ? '∞ Infinite (All Themes)' : `Top ${themesLimit} Themes`}
                        </span>
                      </label>
                      <div className="flex items-center gap-1.5">
                        {['all', 50, 25, 15, 10, 5].map((lim) => (
                          <button
                            key={String(lim)}
                            type="button"
                            onClick={() => setThemesLimit(lim as any)}
                            className={`flex-1 py-1.5 rounded-lg text-xs font-mono border transition-all ${
                              themesLimit === lim
                                ? 'bg-amber-600/30 text-amber-300 border-amber-500/50 font-bold'
                                : 'bg-neutral-900 text-neutral-400 border-neutral-800 hover:text-white'
                            }`}
                          >
                            {lim === 'all' ? '∞ Infinite' : lim}
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* Deliverable Export Files Variables */}
                    <div className="space-y-1.5 pt-2 border-t border-neutral-900">
                      <label className="flex items-center justify-between text-xs font-semibold text-neutral-300">
                        <span>Deliverables / Push Export Files</span>
                        <span className="text-sky-400 font-mono text-[11px] font-bold">
                          {Object.values(selectedPushFiles).filter(Boolean).length} / 7 Files
                        </span>
                      </label>
                      <div className="grid grid-cols-3 gap-1.5">
                        <button
                          type="button"
                          onClick={() => handleSelectAllPushFiles('all')}
                          className="py-1.5 rounded-lg text-xs font-mono border bg-neutral-900 text-neutral-300 border-neutral-800 hover:border-blue-500/50 hover:text-white transition-all"
                        >
                          All 7 Files
                        </button>
                        <button
                          type="button"
                          onClick={() => handleSelectAllPushFiles('core_md')}
                          className="py-1.5 rounded-lg text-xs font-mono border bg-neutral-900 text-neutral-300 border-neutral-800 hover:border-blue-500/50 hover:text-white transition-all"
                        >
                          Core 3 (.md)
                        </button>
                        <button
                          type="button"
                          onClick={() => handleSelectAllPushFiles('logs')}
                          className="py-1.5 rounded-lg text-xs font-mono border bg-neutral-900 text-neutral-300 border-neutral-800 hover:border-blue-500/50 hover:text-white transition-all"
                        >
                          Logs (2)
                        </button>
                        <button
                          type="button"
                          onClick={() => handleSelectAllPushFiles('metadata')}
                          className="py-1.5 rounded-lg text-xs font-mono border bg-neutral-900 text-neutral-300 border-neutral-800 hover:border-blue-500/50 hover:text-white transition-all"
                        >
                          Metadata (2)
                        </button>
                        <button
                          type="button"
                          onClick={() => handleSelectAllPushFiles('invert')}
                          className="py-1.5 rounded-lg text-xs font-mono border bg-neutral-900 text-neutral-300 border-neutral-800 hover:border-blue-500/50 hover:text-white transition-all"
                        >
                          Invert
                        </button>
                        <button
                          type="button"
                          onClick={() => handleSelectAllPushFiles('none')}
                          className="py-1.5 rounded-lg text-xs font-mono border bg-neutral-900 text-rose-400/80 border-neutral-800 hover:border-rose-500/50 hover:text-rose-300 transition-all"
                        >
                          Deselect All
                        </button>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Gemini API Preferences */}
                <div className="space-y-4">
                  <div className="flex items-center gap-2 text-purple-400 pb-2 border-b border-neutral-800/50">
                    <Cpu className="w-4 h-4" />
                    <h3 className="text-xs font-bold font-mono uppercase tracking-widest">Gemini AI Models</h3>
                  </div>

                  <div className="space-y-4">
                    <div className="space-y-1.5">
                      <label className="text-xs font-semibold text-neutral-300">Custom Gemini API Key</label>
                      <div className="relative">
                        <input
                          type={showGeminiKey ? 'text' : 'password'}
                          placeholder="AIzaSy... (leave blank to use env var)"
                          value={geminiApiKey}
                          onChange={(e) => setGeminiApiKey(e.target.value)}
                          className="w-full bg-black text-xs font-mono pl-3.5 pr-10 py-2.5 rounded-xl border border-neutral-800 text-neutral-200 placeholder-neutral-600 focus:outline-none focus:border-purple-500 focus:ring-1 focus:ring-purple-500/50 transition-all"
                        />
                        <button
                          type="button"
                          onClick={() => setShowGeminiKey(!showGeminiKey)}
                          className="absolute right-3 top-2.5 text-neutral-500 hover:text-neutral-300 transition-colors"
                        >
                          {showGeminiKey ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                        </button>
                      </div>
                      <p className="text-[10px] text-neutral-500">Overrides the default system API key if provided.</p>
                    </div>

                    <div className="space-y-2.5">
                      <label className="text-xs font-semibold text-neutral-300">Analysis Engine Model Version</label>
                      <div className="flex flex-col gap-2.5">
                        {[
                          { id: 'gemini-3.1-flash-lite', name: 'Gemini 3.1 Flash-Lite', badge: 'High Availability & Quota / Recommended' },
                          { id: 'gemini-3.8-flash', name: 'Gemini 3.8 Flash', badge: 'Fast / High Capacity' },
                          { id: 'gemini-3.6-flash', name: 'Gemini 3.6 Flash', badge: 'Standard Flash' },
                          { id: 'gemini-3.1-pro-preview', name: 'Gemini 3.1 Pro', badge: 'Deep Reasoning' },
                        ].map(model => (
                          <label 
                            key={model.id}
                            className={`flex items-start p-3.5 rounded-xl border cursor-pointer transition-all ${
                              selectedModel === model.id
                                ? 'bg-purple-500/10 border-purple-500/50 shadow-sm'
                                : 'bg-black border-neutral-800 hover:border-neutral-700'
                            }`}
                          >
                            <input 
                              type="radio"
                              name="ai-model"
                              value={model.id}
                              checked={selectedModel === model.id}
                              onChange={(e) => setSelectedModel(e.target.value)}
                              className="mt-1 accent-purple-500"
                            />
                            <div className="ml-3 flex-1">
                              <div className="flex items-center justify-between">
                                <span className="text-xs font-bold text-white font-mono">{model.name}</span>
                                <span className={`text-[9px] font-mono px-2 py-0.5 rounded-full border ${
                                  selectedModel === model.id 
                                    ? 'bg-purple-500/20 text-purple-300 border-purple-500/30' 
                                    : 'bg-neutral-800 text-neutral-400 border-neutral-700'
                                }`}>
                                  {model.badge}
                                </span>
                              </div>
                            </div>
                          </label>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              </form>
            </div>

            <div className="p-6 border-t border-neutral-800/80 bg-black/50 backdrop-blur-md">
              <button
                type="submit"
                form="settings-form"
                className="w-full flex items-center justify-center space-x-2 px-6 py-3 rounded-xl bg-white hover:bg-neutral-200 text-xs font-semibold text-black transition-all shadow-sm"
              >
                <Save className="w-4 h-4" />
                <span>Save Preferences to Local State</span>
              </button>
            </div>
          </div>
        </>
      )}

      {/* GitHub Repository Creation & File Push Modal */}
      {showGitHubModal && (
        <div 
          role="dialog"
          aria-modal="true"
          aria-labelledby="github-modal-title"
          onClick={(e) => { if (e.target === e.currentTarget) setShowGitHubModal(false); }}
          className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto"
        >
          <div className="bg-neutral-900 rounded-2xl max-w-xl w-full p-6 sm:p-8 shadow-sm border border-neutral-800 space-y-6 my-8 relative max-h-[80vh] overflow-y-auto custom-scrollbar">
            <div className="flex items-center justify-between border-b border-neutral-800/80 pb-4">
              <div className="flex items-center space-x-3">
                <div className="w-9 h-9 rounded-xl bg-blue-500/10 border border-blue-500/20 flex items-center justify-center text-blue-400">
                  <Github className="w-5 h-5" />
                </div>
                <div>
                  <h3 id="github-modal-title" className="text-sm font-bold text-white">GitHub Repository System</h3>
                  <p className="text-[11px] text-neutral-400">Create new GitHub repo & push Archaeology deliverables</p>
                </div>
              </div>
              <button 
                onClick={() => setShowGitHubModal(false)}
                className="text-neutral-400 hover:text-neutral-200 text-sm font-semibold p-1"
              >
                ✕
              </button>
            </div>

            {/* GitHub PAT Verification Block */}
            <div className="space-y-3 bg-black p-4 rounded-xl border border-neutral-800">
              <div className="flex items-center justify-between">
                <label className="text-xs font-semibold text-neutral-300 flex items-center gap-1.5">
                  <Lock className="w-3.5 h-3.5 text-blue-400" />
                  GitHub Personal Access Token (PAT)
                </label>
                <a
                  href="https://github.com/settings/tokens/new?scopes=repo&description=CommitArchaeologyEngine"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-[11px] font-mono text-blue-400 hover:text-blue-300 flex items-center gap-1"
                >
                  <span>Generate Token</span>
                  <ExternalLink className="w-3 h-3" />
                </a>
              </div>

              <div className="flex space-x-2">
                <input
                  type="password"
                  placeholder="ghp_xxxxxxxxxxxxxxxxxxxx"
                  value={githubToken}
                  onChange={(e) => {
                    setGithubToken(e.target.value);
                    setTokenError(null);
                  }}
                  className="flex-1 bg-neutral-900 text-xs font-mono px-3.5 py-2.5 rounded-xl border border-neutral-800 text-neutral-200 placeholder-neutral-600 focus:outline-none focus:border-blue-500"
                />
                <button
                  type="button"
                  onClick={() => verifyGitHubToken(githubToken)}
                  disabled={verifyingToken || !githubToken.trim() || cooldown.isCooling('verify_pat')}
                  className="px-4 py-2 bg-neutral-800 hover:bg-neutral-700 text-xs font-semibold text-neutral-200 rounded-xl transition-all border border-neutral-700 disabled:opacity-50"
                >
                  {cooldown.isCooling('verify_pat') ? (
                    <span className="flex items-center gap-1 font-mono text-[11px] text-amber-400">
                      <Timer className="w-3 h-3 animate-spin" />
                      {cooldown.getRemainingSeconds('verify_pat')}s
                    </span>
                  ) : verifyingToken ? (
                    <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                  ) : (
                    'Verify'
                  )}
                </button>
              </div>

              {tokenError && (
                <div className="text-xs font-mono bg-rose-950/40 border border-rose-500/30 p-3 rounded-xl space-y-2 text-rose-200">
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex items-center gap-1.5 font-bold text-rose-300">
                      <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
                      <span>{tokenError}</span>
                    </div>
                    {githubToken && (
                      <button
                        type="button"
                        onClick={clearGitHubToken}
                        className="px-2 py-0.5 bg-rose-500/20 hover:bg-rose-500/30 text-rose-200 rounded-lg text-[10px] font-mono border border-rose-500/40 transition-colors shrink-0"
                      >
                        Clear Token
                      </button>
                    )}
                  </div>

                  {tokenDiagnostics && (
                    <div className="bg-black/60 p-2.5 rounded-lg text-[11px] space-y-1.5 border border-rose-900/50 text-neutral-300 font-mono">
                      <div className="grid grid-cols-2 gap-x-3 gap-y-1 text-[10px] text-neutral-400 border-b border-neutral-800 pb-1.5">
                        <div><span className="text-neutral-500">Status Code:</span> <span className="font-bold text-rose-300">{tokenDiagnostics.httpStatus || 'N/A'}</span></div>
                        <div><span className="text-neutral-500">Auth Scheme:</span> <span className="text-neutral-200">{tokenDiagnostics.authScheme || 'Bearer'}</span></div>
                        <div><span className="text-neutral-500">Fine-grained:</span> <span className="text-neutral-200">{tokenDiagnostics.isFineGrained ? 'Yes' : 'No'}</span></div>
                        <div><span className="text-neutral-500">Scopes Found:</span> <span className="text-neutral-200">{tokenDiagnostics.scopesFound?.length ? tokenDiagnostics.scopesFound.join(', ') : 'None'}</span></div>
                        {tokenDiagnostics.tokenExpiration && <div><span className="text-neutral-500">Expiration:</span> <span className="text-amber-300">{tokenDiagnostics.tokenExpiration}</span></div>}
                        {tokenDiagnostics.rateLimitRemaining !== undefined && <div><span className="text-neutral-500">Rate Limit:</span> <span className="text-neutral-200">{tokenDiagnostics.rateLimitRemaining}/{tokenDiagnostics.rateLimitLimit}</span></div>}
                      </div>
                      {tokenDiagnostics.rawGitHubMessage && (
                        <div className="text-[11px] text-rose-300">
                          <strong>GitHub API Message:</strong> "{tokenDiagnostics.rawGitHubMessage}"
                        </div>
                      )}
                      {tokenDiagnostics.actionableAdvice && (
                        <div className="text-[11px] text-amber-300 flex items-start justify-between gap-2 pt-0.5">
                          <div className="flex items-start gap-1">
                            <Info className="w-3.5 h-3.5 shrink-0 mt-0.5 text-amber-400" />
                            <span>{tokenDiagnostics.actionableAdvice}</span>
                          </div>
                          {(tokenDiagnostics.code === 'RATE_LIMITED' || tokenDiagnostics.rateLimitRemaining === '0') && (
                            <button
                              type="button"
                              onClick={async () => {
                                await loadSampleRepo();
                                setIsSettingsPanelOpen(false);
                                setShowRepoModal(false);
                                setShowGitHubModal(false);
                                setFallbackNotice("Switched to Local Archeology Mode with built-in commits & diff telemetry.");
                              }}
                              className="px-2.5 py-1 bg-amber-500/20 hover:bg-amber-500/30 text-amber-200 rounded-lg text-[10px] font-mono border border-amber-500/40 transition-colors shrink-0 whitespace-nowrap"
                            >
                              Use Local Mode
                            </button>
                          )}
                        </div>
                      )}
                    </div>
                  )}
                </div>
              )}

              {githubUser && (
                <div className="text-xs font-mono bg-emerald-950/40 border border-emerald-500/30 p-3 rounded-xl space-y-2 text-emerald-200">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <img src={githubUser.avatar_url} alt={githubUser.login} className="w-6 h-6 rounded-full border border-emerald-500/50" />
                      <span className="font-bold text-emerald-300">Connected as @{githubUser.login}</span>
                    </div>
                    <span className="text-[10px] bg-emerald-500/20 text-emerald-300 px-2 py-0.5 rounded-full border border-emerald-500/30 font-bold">
                      Verified
                    </span>
                  </div>

                  {tokenDiagnostics && (
                    <div className="bg-black/60 p-2.5 rounded-lg text-[10px] space-y-1 border border-emerald-900/50 text-neutral-300 font-mono">
                      <div className="flex flex-wrap items-center gap-1.5">
                        <span className="text-neutral-500">Active Scopes:</span>
                        {tokenDiagnostics.scopesFound && tokenDiagnostics.scopesFound.length > 0 ? (
                          tokenDiagnostics.scopesFound.map((s: string) => (
                            <span key={s} className="bg-neutral-800 border border-neutral-700 text-emerald-300 px-1.5 py-0.2 rounded font-mono">
                              {s}
                            </span>
                          ))
                        ) : (
                          <span className="text-amber-300 bg-amber-500/10 px-1.5 py-0.2 rounded border border-amber-500/30">
                            {tokenDiagnostics.isFineGrained ? 'Fine-Grained PAT (Scoped by Repo)' : 'No OAuth Scopes (Read-Only)'}
                          </span>
                        )}
                      </div>
                      <div className="flex items-center justify-between text-neutral-400 pt-0.5">
                        <span>Rate Limit: {tokenDiagnostics.rateLimitRemaining || '5000'}/{tokenDiagnostics.rateLimitLimit || '5000'}</span>
                        <span>Expires: {tokenDiagnostics.tokenExpiration || 'Never / Classic'}</span>
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>

            {/* Repository Config Form */}
            <div className="space-y-4">
              <div className="space-y-1">
                <label className="text-xs font-semibold text-neutral-300 flex items-center gap-1.5">
                  <FolderGit2 className="w-3.5 h-3.5 text-blue-400" />
                  Target Repository Name
                </label>
                <input
                  type="text"
                  value={repoName}
                  onChange={(e) => setRepoName(e.target.value)}
                  placeholder="Archaeology-Engine"
                  className="w-full bg-black text-xs font-mono px-3.5 py-2.5 rounded-xl border border-neutral-800 text-neutral-200 focus:outline-none focus:border-blue-500"
                />
                <p className="text-[10px] text-neutral-500">If repository does not exist on GitHub, it will be created automatically.</p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="text-[11px] font-semibold text-neutral-300">Target Folder on GitHub</label>
                  </div>
                  <input
                    type="text"
                    value={targetFolder}
                    onChange={(e) => setTargetFolder(e.target.value)}
                    placeholder="e.g. archaeology, history, docs (leave empty for root)"
                    className="w-full bg-black text-xs font-mono px-3.5 py-2.5 rounded-xl border border-neutral-800 text-neutral-200 focus:outline-none focus:border-blue-500"
                  />
                  <div className="flex flex-wrap gap-1.5 mt-2">
                    {['archaeology', 'history', 'commit-deliverables', 'docs'].map((f) => (
                      <button
                        key={f}
                        type="button"
                        onClick={() => setTargetFolder(f)}
                        className={`text-[10px] font-mono px-2 py-0.5 rounded-lg border transition-all ${
                          targetFolder === f ? 'bg-blue-600/30 text-blue-300 border-blue-500/50' : 'bg-neutral-800 text-neutral-400 border-neutral-700 hover:text-neutral-200'
                        }`}
                      >
                        /{f}
                      </button>
                    ))}
                    <button
                      type="button"
                      onClick={() => setTargetFolder('')}
                      className={`text-[10px] font-mono px-2 py-0.5 rounded-lg border transition-all ${
                        targetFolder === '' ? 'bg-blue-600/30 text-blue-300 border-blue-500/50' : 'bg-neutral-800 text-neutral-400 border-neutral-700 hover:text-neutral-200'
                      }`}
                    >
                      / (root)
                    </button>
                  </div>
                </div>

                <div>
                  <label className="text-[11px] font-semibold text-neutral-300 block mb-1">Visibility</label>
                  <div className="flex items-center space-x-2 pt-0.5">
                    <button
                      type="button"
                      onClick={() => setIsPrivateRepo(false)}
                      className={`flex-1 py-2 px-2 rounded-xl text-xs font-mono flex items-center justify-center gap-1 border ${
                        !isPrivateRepo ? 'bg-blue-600/20 text-blue-300 border-blue-500/40' : 'bg-black text-neutral-400 border-neutral-800'
                      }`}
                    >
                      <Globe className="w-3 h-3" />
                      <span>Public</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setIsPrivateRepo(true)}
                      className={`flex-1 py-2 px-2 rounded-xl text-xs font-mono flex items-center justify-center gap-1 border ${
                        isPrivateRepo ? 'bg-blue-600/20 text-blue-300 border-blue-500/40' : 'bg-black text-neutral-400 border-neutral-800'
                      }`}
                    >
                      <Lock className="w-3 h-3" />
                      <span>Private</span>
                    </button>
                  </div>
                </div>
              </div>

              {/* Scope Selection & Granular File Variable Selection */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <label className="text-[11px] font-semibold text-neutral-300">Select Deliverable File Variables</label>
                  <div className="flex items-center space-x-1">
                    <button
                      type="button"
                      onClick={() => handleSelectAllPushFiles('all')}
                      className="text-[10px] font-mono px-2 py-0.5 rounded bg-neutral-800 text-blue-300 hover:text-white border border-neutral-700"
                    >
                      Select All Files
                    </button>
                    <button
                      type="button"
                      onClick={() => handleSelectAllPushFiles('core_md')}
                      className="text-[10px] font-mono px-2 py-0.5 rounded bg-neutral-800 text-neutral-300 hover:text-white border border-neutral-700"
                    >
                      Core 3 (.md)
                    </button>
                    <button
                      type="button"
                      onClick={() => handleSelectAllPushFiles('logs')}
                      className="text-[10px] font-mono px-2 py-0.5 rounded bg-neutral-800 text-neutral-300 hover:text-white border border-neutral-700"
                    >
                      Logs Only
                    </button>
                    <button
                      type="button"
                      onClick={() => handleSelectAllPushFiles('none')}
                      className="text-[10px] font-mono px-2 py-0.5 rounded bg-neutral-800 text-neutral-400 hover:text-white border border-neutral-700"
                    >
                      Deselect
                    </button>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 bg-black p-3.5 rounded-xl border border-neutral-800 text-xs font-mono">
                  <label className="flex items-center space-x-2 cursor-pointer p-1 rounded hover:bg-neutral-900">
                    <input
                      type="checkbox"
                      checked={selectedPushFiles.correct}
                      onChange={(e) => setSelectedPushFiles(p => ({ ...p, correct: e.target.checked }))}
                      className="w-3.5 h-3.5 rounded accent-emerald-500"
                    />
                    <span className="text-emerald-400">CORRECT.md</span>
                  </label>
                  <label className="flex items-center space-x-2 cursor-pointer p-1 rounded hover:bg-neutral-900">
                    <input
                      type="checkbox"
                      checked={selectedPushFiles.wrong}
                      onChange={(e) => setSelectedPushFiles(p => ({ ...p, wrong: e.target.checked }))}
                      className="w-3.5 h-3.5 rounded accent-rose-500"
                    />
                    <span className="text-rose-400">WRONG.md</span>
                  </label>
                  <label className="flex items-center space-x-2 cursor-pointer p-1 rounded hover:bg-neutral-900">
                    <input
                      type="checkbox"
                      checked={selectedPushFiles.stuff}
                      onChange={(e) => setSelectedPushFiles(p => ({ ...p, stuff: e.target.checked }))}
                      className="w-3.5 h-3.5 rounded accent-purple-500"
                    />
                    <span className="text-purple-400">stuff.md</span>
                  </label>
                  <label className="flex items-center space-x-2 cursor-pointer p-1 rounded hover:bg-neutral-900">
                    <input
                      type="checkbox"
                      checked={selectedPushFiles.ledger}
                      onChange={(e) => setSelectedPushFiles(p => ({ ...p, ledger: e.target.checked }))}
                      className="w-3.5 h-3.5 rounded accent-blue-500"
                    />
                    <span className="text-blue-400">COMMITS_LEDGER.md</span>
                  </label>
                  <label className="flex items-center space-x-2 cursor-pointer p-1 rounded hover:bg-neutral-900">
                    <input
                      type="checkbox"
                      checked={selectedPushFiles.rawLog}
                      onChange={(e) => setSelectedPushFiles(p => ({ ...p, rawLog: e.target.checked }))}
                      className="w-3.5 h-3.5 rounded accent-neutral-500"
                    />
                    <span className="text-neutral-300">RAW_GIT_LOG.txt</span>
                  </label>
                  <label className="flex items-center space-x-2 cursor-pointer p-1 rounded hover:bg-neutral-900">
                    <input
                      type="checkbox"
                      checked={selectedPushFiles.summary}
                      onChange={(e) => setSelectedPushFiles(p => ({ ...p, summary: e.target.checked }))}
                      className="w-3.5 h-3.5 rounded accent-amber-500"
                    />
                    <span className="text-amber-400">SUMMARY.json & README</span>
                  </label>
                </div>
              </div>

              {/* Append-Only Protection Badge */}
              <div className="bg-emerald-500/10 border border-emerald-500/30 rounded-xl p-3.5 flex items-start gap-2.5 text-xs font-mono">
                <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-emerald-300">Mode: Add to File Only (Append Mode)</span>
                    <span className="text-[9px] bg-emerald-500/20 text-emerald-300 px-1.5 py-0.5 rounded uppercase font-bold">Active</span>
                  </div>
                  <p className="text-[11px] text-neutral-400 font-sans">
                    Existing repository deliverables are never overwritten. New commits and analysis records will be added to the end of existing files preserving all history.
                  </p>
                </div>
              </div>
            </div>

            {/* Error or Success Alert */}
            {pushError && (
              <div className="p-3.5 bg-rose-500/10 border border-rose-500/20 rounded-xl text-xs font-mono text-rose-300 flex items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
                  <span>{pushError}</span>
                </div>
                {githubToken && (
                  <button
                    type="button"
                    onClick={clearGitHubToken}
                    className="px-2 py-1 bg-rose-500/20 hover:bg-rose-500/30 text-rose-200 rounded-lg text-[10px] font-mono border border-rose-500/40 transition-colors shrink-0"
                  >
                    Clear Token
                  </button>
                )}
              </div>
            )}

            {pushSuccess && (
              <div className="p-4 bg-emerald-500/10 border border-emerald-500/20 rounded-2xl space-y-2 text-xs">
                <div className="flex items-center justify-between text-emerald-300 font-bold">
                  <span className="flex items-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                    Successfully pushed to GitHub!
                  </span>
                  <a
                    href={pushSuccess.repoUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center space-x-1 text-blue-400 hover:text-blue-300 font-mono"
                  >
                    <span>View Repository</span>
                    <ExternalLink className="w-3 h-3" />
                  </a>
                </div>
                <div className="space-y-1 font-mono text-[11px] text-neutral-300 pt-1">
                  {pushSuccess.results.map(r => (
                    <div key={r.path} className="flex items-center justify-between">
                      <span className="flex items-center gap-1.5">
                        <span className="text-emerald-400">✓</span>
                        <span>{r.path}</span>
                        <span className="text-[9px] px-1.5 py-0.2 rounded bg-neutral-800 text-neutral-400">
                          {r.status === 'appended' ? 'Appended to existing file' : 'Created new file'}
                        </span>
                      </span>
                      <a href={r.url} target="_blank" rel="noopener noreferrer" className="text-neutral-400 hover:text-neutral-200">
                        view file
                      </a>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Action Buttons */}
            <div className="flex justify-end space-x-3 border-t border-neutral-800/80 pt-4">
              <button
                type="button"
                onClick={() => setShowGitHubModal(false)}
                className="px-4 py-2 rounded-xl text-xs font-medium text-neutral-400 hover:bg-neutral-800 transition-all"
              >
                Close
              </button>
              <button
                type="button"
                onClick={handleGitHubPush}
                disabled={pushingToGitHub || !githubToken.trim() || cooldown.isCooling('push_github')}
                className="inline-flex items-center space-x-2 px-5 py-2.5 rounded-xl bg-white hover:bg-neutral-200 text-xs font-semibold text-black transition-all shadow-sm disabled:opacity-50"
              >
                {cooldown.isCooling('push_github') ? (
                  <CooldownButtonContent
                    isCooling={true}
                    remainingSeconds={cooldown.getRemainingSeconds('push_github')}
                    idleText="Push (Add to Files)"
                    coolingText="Push Cooldown"
                  />
                ) : pushingToGitHub ? (
                  <>
                    <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                    <span>Pushing & Adding to Files...</span>
                  </>
                ) : (
                  <>
                    <UploadCloud className="w-3.5 h-3.5" />
                    <span>Push (Add to Files Only)</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Custom Git Log Modal */}
      {showPasteModal && (
        <div 
          role="dialog"
          aria-modal="true"
          aria-labelledby="paste-modal-title"
          onClick={(e) => { if (e.target === e.currentTarget) setShowPasteModal(false); }}
          className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4"
        >
          <div className="bg-neutral-900 rounded-2xl max-w-2xl w-full p-6 sm:p-8 shadow-sm border border-neutral-800 space-y-4 max-h-[80vh] overflow-y-auto custom-scrollbar">
            <div className="flex items-center justify-between">
              <h3 id="paste-modal-title" className="text-sm font-bold text-white flex items-center gap-2">
                <Terminal className="w-4 h-4 text-blue-400" />
                Paste Custom Git Log
              </h3>
              <button 
                type="button"
                onClick={() => setShowPasteModal(false)}
                className="text-neutral-400 hover:text-neutral-200 text-sm font-semibold p-1"
                aria-label="Close dialog"
              >
                ✕
              </button>
            </div>
            
            <p className="text-xs text-neutral-400">
              Paste raw output from <code className="bg-black px-1.5 py-0.5 rounded text-blue-400 font-mono">git log -p</code>. Press <kbd className="px-1.5 py-0.5 rounded bg-neutral-800 text-neutral-300 font-mono text-[10px]">Cmd / Ctrl + Enter</kbd> to execute analysis instantly.
            </p>

            <div>
              <label htmlFor="raw-git-log-input" className="block text-xs font-semibold text-neutral-300 mb-1.5">
                Git Log Output:
              </label>
              <textarea
                id="raw-git-log-input"
                rows={12}
                value={rawLogInput}
                onChange={(e) => setRawLogInput(e.target.value)}
                onKeyDown={(e) => {
                  if ((e.metaKey || e.ctrlKey) && e.key === 'Enter') {
                    e.preventDefault();
                    runAnalysis(undefined, appendLogToCurrent);
                  }
                }}
                placeholder="commit 42f941a87b6c...&#10;Author: ...&#10;Date: ...&#10;&#10;    subject line&#10;&#10;diff --git ..."
                className="w-full font-mono text-xs p-4 rounded-xl border border-neutral-800 bg-black text-neutral-200 placeholder-neutral-600 focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500/50"
              />
            </div>

            <div className="flex items-center justify-between pt-1">
              <label className="flex items-center space-x-2 text-xs font-mono text-neutral-300 cursor-pointer">
                <input
                  type="checkbox"
                  checked={appendLogToCurrent}
                  onChange={(e) => setAppendLogToCurrent(e.target.checked)}
                  className="rounded border-neutral-700 bg-black text-blue-500 focus:ring-0"
                />
                <span>Add / Append to existing ledger (don't overwrite)</span>
              </label>

              <div className="flex space-x-3">
                <button
                  type="button"
                  onClick={() => setShowPasteModal(false)}
                  className="px-4 py-2 rounded-xl text-xs font-medium text-neutral-400 hover:bg-neutral-800 transition-all"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={() => runAnalysis(undefined, appendLogToCurrent)}
                  disabled={cooldown.isCooling('run_analysis')}
                  className="px-5 py-2.5 rounded-xl bg-white hover:bg-neutral-200 text-xs font-semibold text-black transition-all shadow-sm disabled:opacity-50"
                >
                  {cooldown.isCooling('run_analysis') ? (
                    <CooldownButtonContent
                      isCooling={true}
                      remainingSeconds={cooldown.getRemainingSeconds('run_analysis')}
                      idleText="Run Archaeology Analysis"
                      coolingText="Analysis Cooldown"
                    />
                  ) : (
                    <span>{appendLogToCurrent ? 'Add to File & Analyze' : 'Run Archaeology Analysis'}</span>
                  )}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Manual Append to File Dialog */}
      {showAppendModal && (
        <div 
          role="dialog"
          aria-modal="true"
          aria-labelledby="append-modal-title"
          onClick={(e) => { if (e.target === e.currentTarget) setShowAppendModal(false); }}
          className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4"
        >
          <div className="bg-neutral-900 rounded-2xl max-w-xl w-full p-6 sm:p-8 shadow-sm border border-neutral-800 space-y-4 max-h-[80vh] overflow-y-auto custom-scrollbar">
            <div className="flex items-center justify-between">
              <h3 id="append-modal-title" className="text-sm font-bold text-white flex items-center gap-2">
                <Plus className="w-4 h-4 text-emerald-400" />
                Add Record to {appendEntryFile === 'correct' ? 'CORRECT.md' : appendEntryFile === 'wrong' ? 'WRONG.md' : 'stuff.md'}
              </h3>
              <button 
                type="button"
                onClick={() => setShowAppendModal(false)}
                className="text-neutral-400 hover:text-neutral-200 text-sm font-semibold p-1"
                aria-label="Close dialog"
              >
                ✕
              </button>
            </div>
            
            <p className="text-xs text-neutral-400">
              Append a new commit record, fix notes, or architectural observation. Press <kbd className="px-1.5 py-0.5 rounded bg-neutral-800 text-neutral-300 font-mono text-[10px]">Cmd / Ctrl + Enter</kbd> to save immediately.
            </p>

            <div className="flex items-center space-x-2">
              <button
                type="button"
                onClick={() => setAppendEntryFile('correct')}
                className={`flex-1 py-1.5 rounded-lg text-xs font-mono border transition-all ${
                  appendEntryFile === 'correct' ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40' : 'bg-black text-neutral-400 border-neutral-800'
                }`}
              >
                CORRECT.md
              </button>
              <button
                type="button"
                onClick={() => setAppendEntryFile('wrong')}
                className={`flex-1 py-1.5 rounded-lg text-xs font-mono border transition-all ${
                  appendEntryFile === 'wrong' ? 'bg-rose-500/20 text-rose-300 border-rose-500/40' : 'bg-black text-neutral-400 border-neutral-800'
                }`}
              >
                WRONG.md
              </button>
              <button
                type="button"
                onClick={() => setAppendEntryFile('stuff')}
                className={`flex-1 py-1.5 rounded-lg text-xs font-mono border transition-all ${
                  appendEntryFile === 'stuff' ? 'bg-purple-500/20 text-purple-300 border-purple-500/40' : 'bg-black text-neutral-400 border-neutral-800'
                }`}
              >
                stuff.md
              </button>
            </div>

            <div>
              <label htmlFor="append-entry-input" className="block text-xs font-semibold text-neutral-300 mb-1.5">
                Markdown Entry Content:
              </label>
              <textarea
                id="append-entry-input"
                rows={8}
                value={appendEntryText}
                onChange={(e) => setAppendEntryText(e.target.value)}
                onKeyDown={(e) => {
                  if ((e.metaKey || e.ctrlKey) && e.key === 'Enter' && appendEntryText.trim()) {
                    e.preventDefault();
                    handleAppendToMarkdown(appendEntryFile, appendEntryText);
                  }
                }}
                placeholder="### Commit / Observation Record&#10;**Author:** ...&#10;**Notes:** ...&#10;&#10;```diff&#10;+ added lines&#10;```"
                className="w-full font-mono text-xs p-4 rounded-xl border border-neutral-800 bg-black text-neutral-200 placeholder-neutral-600 focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500/50"
              />
            </div>

            <div className="flex justify-end space-x-3 pt-2">
              <button
                type="button"
                onClick={() => setShowAppendModal(false)}
                className="px-4 py-2 rounded-xl text-xs font-medium text-neutral-400 hover:bg-neutral-800 transition-all"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => handleAppendToMarkdown(appendEntryFile, appendEntryText)}
                disabled={!appendEntryText.trim()}
                className="px-5 py-2.5 rounded-xl bg-white hover:bg-neutral-200 text-xs font-semibold text-black transition-all shadow-sm disabled:opacity-50"
              >
                <span>Add to File Only</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Select Repo Modal */}
      {showRepoModal && (
        <div 
          role="dialog"
          aria-modal="true"
          aria-labelledby="select-repo-modal-title"
          onClick={(e) => { if (e.target === e.currentTarget) setShowRepoModal(false); }}
          className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4"
        >
          <div className="bg-neutral-900 rounded-2xl max-w-2xl w-full p-6 sm:p-8 shadow-sm border border-neutral-800 space-y-4 max-h-[80vh] overflow-y-auto flex flex-col custom-scrollbar">
            <div className="flex items-center justify-between shrink-0 border-b border-neutral-800/80 pb-4">
              <div>
                <h3 id="select-repo-modal-title" className="text-sm font-bold text-white flex items-center gap-2">
                  <Github className="w-4 h-4 text-blue-400" />
                  Select Repository to Analyze
                </h3>
                <p className="text-[11px] text-neutral-400 mt-1">
                  Analyze any public GitHub account, popular open-source repository, or your authenticated repositories.
                </p>
              </div>
              <button 
                onClick={() => setShowRepoModal(false)}
                className="text-neutral-400 hover:text-neutral-200 text-sm font-semibold p-1"
              >
                ✕
              </button>
            </div>

            {/* Direct Any Repo Analysis Bar */}
            <div className="bg-black p-3 rounded-xl border border-neutral-800 space-y-2 shrink-0">
              <label className="text-[11px] font-semibold text-neutral-300 flex items-center gap-1.5">
                <Globe className="w-3.5 h-3.5 text-blue-400" />
                Analyze Any Public GitHub Repository Directly
              </label>
              <div className="flex space-x-2">
                <input
                  type="text"
                  placeholder="e.g. facebook/react, torvalds/linux, or https://github.com/shadcn-ui/ui"
                  value={directRepoInput}
                  onChange={(e) => setDirectRepoInput(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' && directRepoInput.trim()) {
                      fetchAndAnalyzeRepo(directRepoInput.trim());
                    }
                  }}
                  className="flex-1 bg-neutral-900 text-xs font-mono px-3 py-2 rounded-xl border border-neutral-800 text-neutral-200 placeholder-neutral-600 focus:outline-none focus:border-blue-500"
                />
                <button
                  type="button"
                  onClick={() => directRepoInput.trim() && fetchAndAnalyzeRepo(directRepoInput.trim())}
                  disabled={!directRepoInput.trim() || fetchingHistory || cooldown.isCooling('fetch_repo')}
                  className="px-4 py-2 bg-blue-600 hover:bg-blue-500 disabled:opacity-40 text-white text-xs font-semibold rounded-xl transition-all shadow-sm shrink-0"
                >
                  {cooldown.isCooling('fetch_repo') ? (
                    <CooldownButtonContent
                      isCooling={true}
                      remainingSeconds={cooldown.getRemainingSeconds('fetch_repo')}
                      idleText="Analyze Repo"
                      coolingText="Cooldown"
                    />
                  ) : fetchingHistory ? (
                    'Fetching...'
                  ) : (
                    'Analyze Repo'
                  )}
                </button>
              </div>
            </div>

            {/* Account Switcher & Public Exploration */}
            <div className="space-y-2 shrink-0">
              <div className="flex items-center justify-between">
                <label className="text-[11px] font-semibold text-neutral-300 flex items-center gap-1.5">
                  <User className="w-3.5 h-3.5 text-purple-400" />
                  Browse Public Account / Organization
                </label>
                <span className="text-[10px] text-neutral-500">
                  {repoAccountInput ? `Browsing @${repoAccountInput}` : 'Browsing Public GitHub Repos'}
                </span>
              </div>
              <div className="flex space-x-2">
                <input
                  type="text"
                  placeholder="Enter username/org (e.g. facebook, vercel, shadcn-ui) or leave empty"
                  value={repoAccountInput}
                  onChange={(e) => setRepoAccountInput(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') {
                      loadRepositories(repoAccountInput);
                    }
                  }}
                  className="flex-1 bg-black text-xs font-mono px-3 py-2 rounded-xl border border-neutral-800 text-neutral-200 placeholder-neutral-600 focus:outline-none focus:border-purple-500"
                />
                <button
                  type="button"
                  onClick={() => loadRepositories(repoAccountInput)}
                  disabled={loadingRepos || cooldown.isCooling('load_repos')}
                  className="px-3.5 py-2 bg-neutral-800 hover:bg-neutral-700 text-xs font-semibold text-neutral-200 rounded-xl transition-all border border-neutral-700 disabled:opacity-50 shrink-0 flex items-center gap-1.5"
                >
                  {cooldown.isCooling('load_repos') ? (
                    <span className="font-mono text-amber-400 flex items-center gap-1">
                      <Timer className="w-3.5 h-3.5 animate-spin" />
                      {cooldown.getRemainingSeconds('load_repos')}s
                    </span>
                  ) : loadingRepos ? (
                    <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                  ) : (
                    <Search className="w-3.5 h-3.5" />
                  )}
                  <span>{repoAccountInput.trim() ? 'Load Account' : 'Explore Public'}</span>
                </button>
              </div>

              {/* Quick Account Chips */}
              <div className="flex flex-wrap items-center gap-1.5 pt-1">
                <button
                  type="button"
                  onClick={() => {
                    setRepoAccountInput('');
                    loadRepositories('');
                  }}
                  disabled={cooldown.isCooling('load_repos')}
                  className={`text-[10px] font-mono px-2 py-0.5 rounded-lg border transition-all ${
                    !repoAccountInput ? 'bg-purple-600/30 text-purple-300 border-purple-500/50 font-bold' : 'bg-neutral-800 text-neutral-400 border-neutral-700 hover:text-neutral-200'
                  }`}
                >
                  ★ 8 Largest Accounts
                </button>
                {[
                  { id: 'microsoft', name: 'Microsoft' },
                  { id: 'google', name: 'Google' },
                  { id: 'apache', name: 'Apache' },
                  { id: 'facebook', name: 'Meta/FB' },
                  { id: 'apple', name: 'Apple' },
                  { id: 'aws', name: 'AWS' },
                  { id: 'kubernetes', name: 'Kubernetes' },
                  { id: 'nodejs', name: 'Node.js' }
                ].map((acc) => (
                  <button
                    key={acc.id}
                    type="button"
                    onClick={() => {
                      setRepoAccountInput(acc.id);
                      loadRepositories(acc.id);
                    }}
                    disabled={cooldown.isCooling('load_repos')}
                    className={`text-[10px] font-mono px-2 py-0.5 rounded-lg border transition-all flex items-center gap-1 ${
                      repoAccountInput.toLowerCase() === acc.id.toLowerCase() ? 'bg-purple-600/30 text-purple-300 border-purple-500/50 font-bold' : 'bg-neutral-800 text-neutral-400 border-neutral-700 hover:text-neutral-200'
                    }`}
                  >
                    <span>@{acc.name}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Filter and Select All controls with variable limits */}
            <div className="space-y-2 shrink-0">
              <div className="flex items-center space-x-2">
                <div className="relative flex-1">
                  <Search className="w-3.5 h-3.5 absolute left-3 top-2.5 text-neutral-500" />
                  <input
                    type="text"
                    placeholder="Filter loaded repositories..."
                    value={repoSearchFilter}
                    onChange={(e) => setRepoSearchFilter(e.target.value)}
                    className="w-full bg-black text-xs font-mono pl-8 pr-3 py-1.5 rounded-xl border border-neutral-800 text-neutral-200 placeholder-neutral-600 focus:outline-none focus:border-blue-500"
                  />
                </div>

                <span className="text-[11px] font-mono text-neutral-400 shrink-0">
                  {userRepos.filter(r => !repoSearchFilter || r.name.toLowerCase().includes(repoSearchFilter.toLowerCase()) || r.full_name.toLowerCase().includes(repoSearchFilter.toLowerCase())).length} repos
                </span>
              </div>

              {/* Select All Limit Controls */}
              {userRepos.length > 0 && (
                <div className="flex flex-wrap items-center justify-between gap-1.5 pt-1 border-t border-neutral-800/60">
                  <div className="flex flex-wrap items-center gap-1.5">
                    <span className="text-[11px] font-mono text-neutral-400 flex items-center gap-1 mr-1">
                      <Sliders className="w-3 h-3 text-blue-400" />
                      Select Limits:
                    </span>

                    {/* Master Checkbox / Select All */}
                    <button
                      type="button"
                      onClick={() => handleSelectAllRepos('all')}
                      className="px-2.5 py-1 bg-neutral-800 hover:bg-neutral-700 text-[11px] font-mono font-semibold text-neutral-200 rounded-lg transition-all border border-neutral-700 shrink-0 flex items-center gap-1.5"
                    >
                      <input
                        type="checkbox"
                        checked={(() => {
                          const filtered = userRepos.filter(r => matchesRepoSearch(r, repoSearchFilter));
                          return filtered.length > 0 && filtered.every(r => selectedRepoFullNames.includes(r.full_name));
                        })()}
                        ref={el => {
                          if (el) {
                            const filtered = userRepos.filter(r => matchesRepoSearch(r, repoSearchFilter));
                            const some = filtered.some(r => selectedRepoFullNames.includes(r.full_name));
                            const all = filtered.length > 0 && filtered.every(r => selectedRepoFullNames.includes(r.full_name));
                            el.indeterminate = some && !all;
                          }
                        }}
                        onChange={() => {}}
                        className="w-3.5 h-3.5 rounded border-neutral-600 bg-neutral-900 text-blue-600 pointer-events-none"
                      />
                      <span>
                        {(() => {
                          const filtered = userRepos.filter(r => matchesRepoSearch(r, repoSearchFilter));
                          const isAllSelected = filtered.length > 0 && filtered.every(r => selectedRepoFullNames.includes(r.full_name));
                          return isAllSelected ? 'Deselect All' : `∞ Infinite (All ${filtered.length})`;
                        })()}
                      </span>
                    </button>

                    {[25, 10, 5, 3].map((limitCount) => (
                      <button
                        key={limitCount}
                        type="button"
                        onClick={() => handleSelectAllRepos(limitCount)}
                        className="px-2 py-1 bg-neutral-900 hover:bg-neutral-800 text-neutral-300 text-[11px] font-mono rounded-lg border border-neutral-800 hover:border-neutral-700 transition-colors"
                      >
                        Top {limitCount}
                      </button>
                    ))}

                    {/* Custom Repo Limit Input */}
                    <div className="flex items-center gap-1 bg-black border border-neutral-800 rounded-lg px-2 py-0.5">
                      <input
                        type="number"
                        placeholder="Custom"
                        value={customRepoLimitInput}
                        onChange={(e) => setCustomRepoLimitInput(e.target.value)}
                        onKeyDown={(e) => {
                          if (e.key === 'Enter') {
                            const n = parseInt(customRepoLimitInput, 10);
                            if (!isNaN(n) && n > 0) handleSelectAllRepos(n);
                          }
                        }}
                        className="w-14 bg-transparent text-[11px] font-mono text-neutral-200 outline-none placeholder-neutral-600"
                        min="1"
                      />
                      <button
                        type="button"
                        onClick={() => {
                          const n = parseInt(customRepoLimitInput, 10);
                          if (!isNaN(n) && n > 0) handleSelectAllRepos(n);
                        }}
                        className="text-[10px] font-mono text-blue-400 hover:text-blue-300 font-bold"
                      >
                        Apply
                      </button>
                    </div>

                    <button
                      type="button"
                      onClick={() => handleSelectAllRepos('invert')}
                      className="px-2 py-1 bg-neutral-900 hover:bg-neutral-800 text-neutral-400 hover:text-white text-[11px] font-mono rounded-lg border border-neutral-800 transition-colors"
                    >
                      Invert
                    </button>
                  </div>

                  {selectedRepoFullNames.length > 0 && (
                    <button
                      type="button"
                      onClick={() => handleSelectAllRepos('clear')}
                      className="text-[11px] font-mono text-neutral-400 hover:text-white px-2 py-1 rounded bg-neutral-800/80"
                    >
                      Clear ({selectedRepoFullNames.length})
                    </button>
                  )}
                </div>
              )}
            </div>

            {/* Batch Action Bar if any selected */}
            {selectedRepoFullNames.length > 0 && (
              <div className="p-3 rounded-xl bg-blue-950/60 border border-blue-500/40 flex flex-col sm:flex-row items-center justify-between gap-2 shrink-0 animate-in fade-in">
                <div className="flex items-center gap-2">
                  <div className="w-5 h-5 rounded-md bg-blue-500/20 flex items-center justify-center text-blue-300">
                    <CheckCheck className="w-3 h-3" />
                  </div>
                  <span className="text-xs font-mono text-blue-200 font-semibold">
                    {selectedRepoFullNames.length} {selectedRepoFullNames.length === 1 ? 'repository' : 'repositories'} selected
                  </span>
                </div>
                <div className="flex items-center space-x-2">
                  <button
                    type="button"
                    onClick={() => handleSelectAllRepos('clear')}
                    className="text-[11px] font-mono text-neutral-400 hover:text-neutral-200 px-2 py-1"
                  >
                    Clear Selection
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      if (selectedRepoFullNames.length === 1) {
                        fetchAndAnalyzeRepo(selectedRepoFullNames[0]);
                      } else if (selectedRepoFullNames.length > 1) {
                        fetchAndAnalyzeBatchRepos(selectedRepoFullNames);
                      }
                    }}
                    disabled={fetchingHistory || analyzing || cooldown.isCooling('fetch_repo')}
                    className="px-3.5 py-1.5 bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold rounded-lg transition-all shadow-sm disabled:opacity-50 flex items-center gap-1.5"
                  >
                    {cooldown.isCooling('fetch_repo') ? (
                      `Cooldown (${cooldown.getRemainingSeconds('fetch_repo')}s)`
                    ) : fetchingHistory ? (
                      <>
                        <RefreshCw className="w-3 h-3 animate-spin" />
                        <span>Fetching & Aggregating...</span>
                      </>
                    ) : selectedRepoFullNames.length === 1 ? (
                      `Analyze (${selectedRepoFullNames[0]})`
                    ) : (
                      `Batch Analyze All ${selectedRepoFullNames.length} Repos`
                    )}
                  </button>
                </div>
              </div>
            )}

            <div className="flex items-center justify-between p-2.5 rounded-xl bg-neutral-800/40 border border-neutral-800/60 shrink-0">
              <div className="flex flex-col">
                <span className="text-xs font-semibold text-neutral-200">Analyze Entire Commit History</span>
                <span className="text-[10px] text-neutral-400">Fetch all commit pages across the complete git log.</span>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input 
                  type="checkbox" 
                  className="sr-only peer"
                  checked={analyzeEntireHistory}
                  onChange={(e) => setAnalyzeEntireHistory(e.target.checked)}
                />
                <div className="w-9 h-5 bg-neutral-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-blue-500"></div>
              </label>
            </div>
            
            {/* Repository List */}
            <div className="flex-1 overflow-y-auto space-y-2 pr-2 custom-scrollbar">
              {loadingRepos ? (
                <div className="text-center py-10 space-y-2">
                  <RefreshCw className="w-5 h-5 animate-spin text-blue-400 mx-auto" />
                  <p className="text-xs text-neutral-400">Loading public GitHub repositories...</p>
                </div>
              ) : repoLoadError ? (
                <div className="text-center py-8 space-y-3 bg-rose-500/5 rounded-xl border border-rose-500/20 p-4">
                  <p className="text-xs text-rose-400">{repoLoadError}</p>
                  <button
                    type="button"
                    onClick={() => {
                      setRepoAccountInput('');
                      loadRepositories('');
                    }}
                    className="inline-flex items-center space-x-1.5 px-3 py-1.5 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-xs font-semibold text-white transition-all shadow-sm"
                  >
                    <span>Load Public Repositories</span>
                  </button>
                </div>
              ) : userRepos.length === 0 ? (
                <div className="text-center py-10 space-y-3">
                  <p className="text-sm text-neutral-400">No repositories found for this selection.</p>
                  <button
                    type="button"
                    onClick={() => {
                      setRepoAccountInput('');
                      loadRepositories('');
                    }}
                    className="inline-flex items-center space-x-1.5 px-3 py-1.5 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-xs font-semibold text-white transition-all shadow-sm"
                  >
                    <span>Load Public GitHub Repos</span>
                  </button>
                </div>
              ) : (
                userRepos
                  .filter(repo => !repoSearchFilter || repo.name.toLowerCase().includes(repoSearchFilter.toLowerCase()) || repo.full_name.toLowerCase().includes(repoSearchFilter.toLowerCase()) || (repo.description && repo.description.toLowerCase().includes(repoSearchFilter.toLowerCase())))
                  .map((repo) => {
                    const isSelected = selectedRepoFullNames.includes(repo.full_name);
                    return (
                      <div
                        key={repo.id}
                        onClick={() => {
                          if (isSelected) {
                            setSelectedRepoFullNames(prev => prev.filter(n => n !== repo.full_name));
                          } else {
                            setSelectedRepoFullNames(prev => [...prev, repo.full_name]);
                          }
                        }}
                        className={`w-full flex items-center justify-between p-3 rounded-xl border transition-all cursor-pointer ${
                          isSelected ? 'bg-blue-950/20 border-blue-500/60' : 'bg-black border-neutral-800 hover:border-blue-500/50 hover:bg-neutral-950'
                        }`}
                      >
                        <div className="flex items-center gap-3 flex-1 min-w-0 pr-3">
                          <input
                            type="checkbox"
                            checked={isSelected}
                            onChange={(e) => {
                              e.stopPropagation();
                              if (isSelected) {
                                setSelectedRepoFullNames(prev => prev.filter(n => n !== repo.full_name));
                              } else {
                                setSelectedRepoFullNames(prev => [...prev, repo.full_name]);
                              }
                            }}
                            className="w-4 h-4 rounded border-neutral-700 bg-neutral-900 text-blue-600 focus:ring-blue-500 cursor-pointer shrink-0"
                          />
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2">
                              <span className="text-xs font-bold text-neutral-200 truncate">{repo.name}</span>
                              {repo.private ? (
                                <Lock className="w-3 h-3 text-neutral-500 shrink-0" />
                              ) : (
                                <span className="text-[9px] font-mono px-1.5 py-0.2 rounded bg-neutral-800 text-neutral-400 border border-neutral-700 shrink-0">public</span>
                              )}
                              {repo.stargazers_count > 0 && (
                                <span className="text-[10px] text-amber-400/80 flex items-center gap-0.5 font-mono shrink-0">
                                  <Star className="w-3 h-3 fill-amber-400/80" />
                                  {repo.stargazers_count > 1000 ? `${(repo.stargazers_count / 1000).toFixed(1)}k` : repo.stargazers_count}
                                </span>
                              )}
                            </div>
                            <span className="text-[10px] text-neutral-500 font-mono mt-0.5 block truncate">{repo.full_name}</span>
                            {repo.description && (
                              <p className="text-[10px] text-neutral-400 mt-1 line-clamp-1">{repo.description}</p>
                            )}
                          </div>
                        </div>
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            fetchAndAnalyzeRepo(repo.full_name);
                          }}
                          disabled={fetchingHistory || analyzing || cooldown.isCooling('fetch_repo')}
                          className="text-[10px] text-neutral-300 px-3 py-1.5 rounded-lg bg-neutral-800 hover:bg-blue-600 hover:text-white transition-colors shrink-0 font-medium disabled:opacity-40"
                        >
                          {cooldown.isCooling('fetch_repo') ? `${cooldown.getRemainingSeconds('fetch_repo')}s` : fetchingHistory ? 'Fetching...' : 'Analyze History'}
                        </button>
                      </div>
                    );
                  })
              )}
            </div>
          </div>
        </div>
      )}

      {/* Footer */}
      <footer className="bg-neutral-900/80 border-t border-neutral-800/80 py-4 mt-auto backdrop-blur-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between text-xs text-neutral-500 gap-2">
          <span>Commit Archaeology Engine — Powered by Google AI Studio & Gemini ({selectedModel})</span>
          <span className="font-mono text-neutral-400 font-medium">craighckby-stack 2026</span>
        </div>
      </footer>
    </div>
  );
}
