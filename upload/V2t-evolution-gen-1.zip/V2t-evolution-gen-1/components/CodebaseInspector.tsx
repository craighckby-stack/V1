'use client';

import React, { useState } from 'react';
import {
  FileCode,
  Folder,
  FileText,
  Copy,
  Check,
  Code2,
  Terminal,
  ShieldCheck,
  GitBranch,
  Clock,
  Sparkles,
  Upload,
  RotateCcw,
  RefreshCw,
  Edit3,
  CheckCircle2,
  AlertCircle
} from 'lucide-react';

interface CodebaseInspectorProps {
  generation: number;
}

interface ProjectFile {
  path: string;
  name: string;
  category: 'code' | 'doc' | 'config';
  language: string;
  lines: number;
  description: string;
  badge?: string;
  content: string;
}

const INITIAL_PROJECT_FILES: ProjectFile[] = [
  {
    path: 'app/page.tsx',
    name: 'app/page.tsx',
    category: 'code',
    language: 'typescript',
    lines: 432,
    description: 'Main studio interface orchestrating recursive cycles, UI state, and evolutionary execution.',
    badge: 'Core UI',
    content: `// Main studio interface orchestrating recursive cycles`,
  },
  {
    path: 'app/api/biological-ai/generate/route.ts',
    name: 'app/api/biological-ai/generate/route.ts',
    category: 'code',
    language: 'typescript',
    lines: 245,
    description: 'Server-side endpoint utilizing Gemini 3.8 Flash with structured JSON output and fallback synthesis.',
    badge: 'Gemini 3.8 Flash',
    content: `// Server-side endpoint utilizing Gemini 3.8 Flash`,
  },
  {
    path: 'app/api/codebase/mutate/route.ts',
    name: 'app/api/codebase/mutate/route.ts',
    category: 'code',
    language: 'typescript',
    lines: 110,
    description: 'Autonomous filesystem mutation engine: writes .tsx, .ts, and .css changes to disk with automatic snapshot backups.',
    badge: 'Mutation Engine',
    content: `// Autonomous filesystem mutation engine`,
  },
  {
    path: 'components/GenerationViewer.tsx',
    name: 'components/GenerationViewer.tsx',
    category: 'code',
    language: 'typescript',
    lines: 380,
    description: 'Evolution specimen viewer with live code mutation inspection, diff views, and one-click disk writing.',
    badge: 'Code Diff View',
    content: `// Evolution specimen viewer with live code mutation inspection`,
  },
  {
    path: 'components/BioSubstrateSimulator.tsx',
    name: 'components/BioSubstrateSimulator.tsx',
    category: 'code',
    language: 'typescript',
    lines: 85,
    description: 'Dynamic neural organoid substrate simulator component with real-time membrane potential dynamics.',
    badge: 'Bio Component',
    content: `// Dynamic neural organoid substrate simulator component`,
  },
  {
    path: 'lib/syntheticGeneNetwork.ts',
    name: 'lib/syntheticGeneNetwork.ts',
    category: 'code',
    language: 'typescript',
    lines: 55,
    description: 'Synthetic gene kinetics library computing transcription Hill equations and repressor toggle dynamics.',
    badge: 'Bio Kinetics',
    content: `// Synthetic gene kinetics library`,
  },
  {
    path: 'lib/eventBrokerEngine.ts',
    name: 'lib/eventBrokerEngine.ts',
    category: 'code',
    language: 'typescript',
    lines: 75,
    description: 'Partitioned event broker engine with append-only commit ring buffer and backpressure regulation.',
    badge: 'CQRS Engine',
    content: `// Partitioned event broker engine with append-only commit ring buffer`,
  },
  {
    path: 'docs/EVOLUTION_GEN_8_REPORT.md',
    name: 'docs/EVOLUTION_GEN_8_REPORT.md',
    category: 'doc',
    language: 'markdown',
    lines: 50,
    description: 'Autonomous generation report detailing the Gen 8 mutation invariants, CQRS topologies, and metrics.',
    badge: 'Report Artifact',
    content: `# Recursive Architecture Evolution - Generation 8`,
  },
  {
    path: 'docs/evolution_history.json',
    name: 'docs/evolution_history.json',
    category: 'doc',
    language: 'json',
    lines: 696,
    description: 'Persistent immutable ledger recording full 8 generations of evolutionary mutation data and node graphs.',
    badge: 'Ledger',
    content: `{"generation": 8}`,
  }
];

export const CodebaseInspector: React.FC<CodebaseInspectorProps> = ({ generation }) => {
  const [files] = useState<ProjectFile[]>(INITIAL_PROJECT_FILES);
  const [selectedFile, setSelectedFile] = useState<ProjectFile>(INITIAL_PROJECT_FILES[0]);
  const [liveContent, setLiveContent] = useState<string>('');
  const [isLoadingFile, setIsLoadingFile] = useState<boolean>(false);
  const [isEditing, setIsEditing] = useState<boolean>(false);
  const [isSaving, setIsSaving] = useState<boolean>(false);
  const [hasBackup, setHasBackup] = useState<boolean>(false);
  const [statusNotice, setStatusNotice] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const [copied, setCopied] = useState<boolean>(false);
  const [searchFilter, setSearchFilter] = useState<string>('');

  // Fetch real file content from disk on select
  const fetchFileFromDisk = async (filePath: string) => {
    setIsLoadingFile(true);
    setStatusNotice(null);
    try {
      const res = await fetch(`/api/codebase/mutate?path=${encodeURIComponent(filePath)}`);
      if (res.ok) {
        const data = await res.json();
        setLiveContent(data.content);
        setHasBackup(data.hasBackup);
      } else {
        // Fallback to initial content
        setLiveContent(selectedFile.content);
      }
    } catch {
      setLiveContent(selectedFile.content);
    } finally {
      setIsLoadingFile(false);
    }
  };



  const handleCopy = () => {
    navigator.clipboard.writeText(liveContent || selectedFile.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleSaveToDisk = async () => {
    setIsSaving(true);
    setStatusNotice(null);
    try {
      const res = await fetch('/api/codebase/mutate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          filePath: selectedFile.path,
          mutatedCode: liveContent,
          action: 'apply',
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to write file to disk.');

      setStatusNotice({ type: 'success', text: data.message || 'File successfully saved to disk!' });
      setIsEditing(false);
      setHasBackup(true);
    } catch (err: any) {
      setStatusNotice({ type: 'error', text: err?.message || 'Error saving file to disk.' });
    } finally {
      setIsSaving(false);
    }
  };

  const handleRollback = async () => {
    setIsSaving(true);
    setStatusNotice(null);
    try {
      const res = await fetch('/api/codebase/mutate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          filePath: selectedFile.path,
          action: 'rollback',
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to rollback file.');

      setStatusNotice({ type: 'success', text: data.message || 'File reverted from backup snapshot!' });
      fetchFileFromDisk(selectedFile.path);
    } catch (err: any) {
      setStatusNotice({ type: 'error', text: err?.message || 'Error during rollback.' });
    } finally {
      setIsSaving(false);
    }
  };

  const filteredFiles = files.filter(
    (f) =>
      f.name.toLowerCase().includes(searchFilter.toLowerCase()) ||
      f.description.toLowerCase().includes(searchFilter.toLowerCase())
  );

  return (
    <div className="space-y-6">
      {/* Overview Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-4 flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-teal-500/10 border border-teal-500/30 flex items-center justify-center text-teal-400">
            <GitBranch className="w-5 h-5" />
          </div>
          <div>
            <span className="text-[11px] font-mono uppercase text-slate-400">Live Disk Sync</span>
            <p className="text-sm font-bold text-white font-mono">Real File I/O Active</p>
          </div>
        </div>

        <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-4 flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-indigo-500/10 border border-indigo-500/30 flex items-center justify-center text-indigo-400">
            <Sparkles className="w-5 h-5" />
          </div>
          <div>
            <span className="text-[11px] font-mono uppercase text-slate-400">Evolution Cycle</span>
            <p className="text-sm font-bold text-white">Gen {generation > 0 ? generation : 8} (Active)</p>
          </div>
        </div>

        <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-4 flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
            <ShieldCheck className="w-5 h-5" />
          </div>
          <div>
            <span className="text-[11px] font-mono uppercase text-slate-400">Invariants</span>
            <p className="text-sm font-bold text-emerald-400">Zero Unsaved Drift</p>
          </div>
        </div>

        <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-4 flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-purple-500/10 border border-purple-500/30 flex items-center justify-center text-purple-400">
            <Clock className="w-5 h-5" />
          </div>
          <div>
            <span className="text-[11px] font-mono uppercase text-slate-400">Safe Rollback</span>
            <p className="text-sm font-bold text-white">{hasBackup ? 'Backup Available' : 'Ready'}</p>
          </div>
        </div>
      </div>

      {statusNotice && (
        <div
          className={`p-3.5 rounded-xl border text-xs flex items-center gap-2 ${
            statusNotice.type === 'success'
              ? 'bg-emerald-950/70 border-emerald-500/40 text-emerald-200'
              : 'bg-rose-950/70 border-rose-500/40 text-rose-200'
          }`}
        >
          {statusNotice.type === 'success' ? (
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          ) : (
            <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
          )}
          <span>{statusNotice.text}</span>
        </div>
      )}

      {/* Main File Browser & Code View */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-2xl overflow-hidden shadow-2xl grid grid-cols-1 md:grid-cols-12 min-h-[580px]">
        {/* Left Column: Explorer */}
        <div className="md:col-span-4 border-b md:border-b-0 md:border-r border-slate-800 bg-slate-950/60 p-4 flex flex-col justify-between">
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-2">
                <Folder className="w-3.5 h-3.5 text-teal-400" />
                <span>Codebase Files</span>
              </span>
              <span className="text-[10px] font-mono bg-slate-800 text-slate-300 px-2 py-0.5 rounded">
                {files.length} tracked
              </span>
            </div>

            {/* Quick search input */}
            <input
              type="text"
              placeholder="Filter files..."
              value={searchFilter}
              onChange={(e) => setSearchFilter(e.target.value)}
              className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-1.5 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-teal-500"
            />

            {/* File List */}
            <div className="space-y-1.5 max-h-[420px] overflow-y-auto pr-1">
              {filteredFiles.map((file) => {
                const isSelected = selectedFile.path === file.path;
                return (
                  <button
                    key={file.path}
                    onClick={() => {
                      setSelectedFile(file);
                      setIsEditing(false);
                      fetchFileFromDisk(file.path);
                    }}
                    className={`w-full text-left p-2.5 rounded-xl transition-all flex items-start justify-between gap-2 border ${
                      isSelected
                        ? 'bg-teal-500/15 border-teal-500/40 text-teal-200'
                        : 'bg-slate-900/50 hover:bg-slate-800/60 border-slate-800/80 text-slate-300'
                    }`}
                  >
                    <div className="flex items-start gap-2 min-w-0">
                      {file.category === 'code' ? (
                        <FileCode
                          className={`w-4 h-4 shrink-0 mt-0.5 ${
                            isSelected ? 'text-teal-400' : 'text-slate-400'
                          }`}
                        />
                      ) : (
                        <FileText
                          className={`w-4 h-4 shrink-0 mt-0.5 ${
                            isSelected ? 'text-teal-400' : 'text-slate-400'
                          }`}
                        />
                      )}
                      <div className="min-w-0">
                        <div className="text-xs font-mono font-medium truncate">{file.name}</div>
                        <div className="text-[10px] text-slate-400 truncate">{file.description}</div>
                      </div>
                    </div>
                    {file.badge && (
                      <span className="text-[9px] font-mono px-1.5 py-0.5 rounded bg-slate-800 border border-slate-700 text-slate-300 shrink-0">
                        {file.badge}
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
          </div>

          <div className="pt-4 border-t border-slate-800 text-[11px] text-slate-400 flex items-center justify-between">
            <span className="font-mono">Mutation I/O: Enabled</span>
            <span className="text-teal-400">FS-Sync Ready</span>
          </div>
        </div>

        {/* Right Column: Code Viewer & Editor */}
        <div className="md:col-span-8 flex flex-col bg-slate-950">
          {/* File Header */}
          <div className="px-5 py-3 border-b border-slate-800 bg-slate-900/70 flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-2 min-w-0">
              <span className="text-xs font-mono font-semibold text-slate-200 truncate">
                {selectedFile.path}
              </span>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-800 text-slate-300 border border-slate-700">
                {liveContent ? liveContent.split('\n').length : selectedFile.lines} lines
              </span>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => fetchFileFromDisk(selectedFile.path)}
                disabled={isLoadingFile}
                className="p-1.5 text-xs text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-lg border border-slate-700 transition-colors"
                title="Reload file from disk"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${isLoadingFile ? 'animate-spin' : ''}`} />
              </button>

              <button
                onClick={() => setIsEditing(!isEditing)}
                className={`px-3 py-1.5 text-xs font-medium rounded-lg border transition-colors flex items-center gap-1.5 ${
                  isEditing
                    ? 'bg-amber-500/20 text-amber-300 border-amber-500/40'
                    : 'bg-slate-800 hover:bg-slate-700 text-slate-200 border-slate-700'
                }`}
              >
                <Edit3 className="w-3.5 h-3.5" />
                <span>{isEditing ? 'Viewing Mode' : 'Edit / Mutate'}</span>
              </button>

              {isEditing && (
                <button
                  onClick={handleSaveToDisk}
                  disabled={isSaving}
                  className="px-3 py-1.5 text-xs font-bold bg-teal-500 hover:bg-teal-400 text-slate-950 rounded-lg transition-colors flex items-center gap-1.5 shadow-sm disabled:opacity-50"
                >
                  <Upload className="w-3.5 h-3.5" />
                  <span>{isSaving ? 'Writing...' : 'Save to Disk'}</span>
                </button>
              )}

              {hasBackup && (
                <button
                  onClick={handleRollback}
                  disabled={isSaving}
                  className="px-3 py-1.5 text-xs font-medium bg-slate-800 hover:bg-slate-700 text-amber-300 rounded-lg border border-slate-700 transition-colors flex items-center gap-1.5"
                  title="Revert to backup before mutation"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>Rollback</span>
                </button>
              )}

              <button
                onClick={handleCopy}
                className="px-3 py-1.5 text-xs font-medium bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg border border-slate-700 transition-colors flex items-center gap-1.5 shrink-0"
              >
                {copied ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-400" />
                    <span className="text-emerald-400">Copied</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" />
                    <span>Copy</span>
                  </>
                )}
              </button>
            </div>
          </div>

          {/* Code Area: View or Edit */}
          {isEditing ? (
            <div className="flex-1 p-3 bg-slate-950 flex flex-col">
              <textarea
                value={liveContent}
                onChange={(e) => setLiveContent(e.target.value)}
                className="flex-1 w-full p-3 font-mono text-xs bg-slate-900 text-slate-100 border border-slate-800 rounded-xl focus:outline-none focus:ring-1 focus:ring-teal-500 resize-none min-h-[440px]"
                spellCheck={false}
              />
            </div>
          ) : (
            <div className="flex-1 p-5 overflow-x-auto font-mono text-xs text-slate-300 leading-relaxed bg-slate-950/80 max-h-[500px]">
              {isLoadingFile ? (
                <div className="p-8 text-center text-slate-400 font-sans">
                  <RefreshCw className="w-5 h-5 animate-spin mx-auto mb-2 text-teal-400" />
                  <span>Loading live file from filesystem...</span>
                </div>
              ) : (
                <pre className="whitespace-pre-wrap">{liveContent || selectedFile.content}</pre>
              )}
            </div>
          )}

          {/* Bottom Bar */}
          <div className="px-5 py-2.5 border-t border-slate-800 bg-slate-900/40 text-[11px] font-mono text-slate-400 flex items-center justify-between">
            <span>Encoding: UTF-8</span>
            <span>Target: {selectedFile.path}</span>
            <span>Language: {selectedFile.language.toUpperCase()}</span>
          </div>
        </div>
      </div>
    </div>
  );
};
