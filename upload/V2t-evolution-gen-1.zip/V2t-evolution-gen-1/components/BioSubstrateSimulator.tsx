'use client';

import React, { useState, useEffect } from 'react';
import { Activity, Zap, Play, Pause, ShieldCheck, Dna } from 'lucide-react';

interface BioSubstrateSimulatorProps {
  generation?: number;
  firingThreshold?: number;
}

export function BioSubstrateSimulator({ generation = 1, firingThreshold = -55 }: BioSubstrateSimulatorProps) {
  const [isRunning, setIsRunning] = useState(true);
  const [membranePotential, setMembranePotential] = useState(-70);
  const [spikeCount, setSpikeCount] = useState(14);
  const [synapticWeight, setSynapticWeight] = useState(0.78);

  useEffect(() => {
    if (!isRunning) return;
    const interval = setInterval(() => {
      setMembranePotential((prev) => {
        const noise = (Math.random() - 0.48) * 6;
        const nextVal = prev + noise;
        if (nextVal >= firingThreshold) {
          setSpikeCount((s) => s + 1);
          setSynapticWeight((w) => Math.min(0.99, +(w + 0.01).toFixed(2)));
          return -75; // refractory reset
        }
        return Math.max(-85, Math.min(-50, nextVal));
      });
    }, 150);
    return () => clearInterval(interval);
  }, [isRunning, firingThreshold]);

  return (
    <div className="bg-slate-900 border border-teal-500/30 rounded-2xl p-5 space-y-4 shadow-xl">
      <div className="flex items-center justify-between border-b border-slate-800 pb-3">
        <div className="flex items-center gap-2">
          <Activity className="w-5 h-5 text-teal-400 animate-pulse" />
          <div>
            <h4 className="text-sm font-bold text-white flex items-center gap-2">
              <span>Neural Organoid Substrate Simulator</span>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-teal-500/20 text-teal-300 border border-teal-500/30">
                Gen {generation}
              </span>
            </h4>
            <p className="text-[11px] text-slate-400">Hodgkin-Huxley bio-computational oscillator</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-800 text-teal-300 border border-slate-700">
            Synaptic Weight: {synapticWeight}
          </span>
          <button
            onClick={() => setIsRunning(!isRunning)}
            className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors"
          >
            {isRunning ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
        <div className="bg-slate-950 p-3 rounded-xl border border-slate-800">
          <span className="text-slate-400 block text-[10px] uppercase font-mono">Membrane Potential</span>
          <span className="text-lg font-mono font-bold text-teal-300">{membranePotential.toFixed(1)} mV</span>
          <div className="w-full bg-slate-800 h-1 rounded-full mt-2 overflow-hidden">
            <div
              className="bg-teal-400 h-full transition-all duration-150"
              style={{ width: `${Math.max(0, Math.min(100, ((membranePotential + 85) / 35) * 100))}%` }}
            />
          </div>
        </div>
        <div className="bg-slate-950 p-3 rounded-xl border border-slate-800">
          <span className="text-slate-400 block text-[10px] uppercase font-mono">Action Potentials</span>
          <span className="text-lg font-mono font-bold text-cyan-300">{spikeCount} spikes</span>
          <span className="text-[10px] text-slate-500 block mt-1">Spike-timing plasticity active</span>
        </div>
        <div className="bg-slate-950 p-3 rounded-xl border border-slate-800">
          <span className="text-slate-400 block text-[10px] uppercase font-mono">Biochemical Substrate</span>
          <span className="text-lg font-mono font-bold text-emerald-300">Coherent</span>
          <span className="text-[10px] text-emerald-400/80 block mt-1">Zero neurotransmitter decay</span>
        </div>
      </div>
    </div>
  );
}
