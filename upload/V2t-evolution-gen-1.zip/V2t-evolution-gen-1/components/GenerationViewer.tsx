'use client';

import React, { useState } from 'react';
import { GenerationResult, DomainCategory, CodeMutation } from '@/lib/types';
import { ArchitectureNodeGraph } from './ArchitectureNodeGraph';
import { MetricsPanel } from './MetricsPanel';
import {
  Sparkles,
  HelpCircle,
  ShieldCheck,
  FileText,
  Network,
  BarChart2,
  AlertCircle,
  ArrowUpRight,
  Code2,
  Check,
  Copy,
  RotateCcw,
  FileCode,
  CheckCircle2,
  Terminal,
  Upload
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface GenerationViewerProps {
  result: GenerationResult;
  totalGenerations: number;
  domain?: DomainCategory;
  onStepNext?: () => void;
  onForkGen?: () => void;
  isRunning?: boolean;
}

export const GenerationViewer: React.FC<GenerationViewerProps> = ({
  result,
  totalGenerations,
  domain = 'codebase-meta',
  onStepNext,
  onForkGen,
  isRunning,
}) => {
  const [activeTab, setActiveTab] = useState<'design' | 'code' | 'graph' | 'analysis' | 'verification' | 'questions'>('design');
  const [selectedMutationIdx, setSelectedMutationIdx] = useState<number>(0);
  const [appliedStatus, setAppliedStatus] = useState<Record<string, { applied: boolean; message: string }>>({});
  const [isApplying, setIsApplying] = useState<boolean>(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const mutations = result.code_mutations || [];
  const activeMutation = mutations[selectedMutationIdx] || mutations[0];

  const getDecisionBadge = (decision: string) => {
    switch (decision) {
      case 'stop':
        return {
          label: 'Sufficiently Developed (Optimal Stop)',
          bg: 'bg-emerald-950/80 border-emerald-500/40 text-emerald-300',
          dot: 'bg-emerald-400',
        };
      case 'pivot':
        return {
          label: 'Architectural Pivot Recommended',
          bg: 'bg-amber-950/80 border-amber-500/40 text-amber-300',
          dot: 'bg-amber-400',
        };
      case 'continue':
      default:
        return {
          label: 'Active Refinement Loop (Continue)',
          bg: 'bg-teal-950/80 border-teal-500/40 text-teal-300',
          dot: 'bg-teal-400',
        };
    }
  };

  const decisionBadge = getDecisionBadge(result.decision);

  const handleCopyCode = (mutation: CodeMutation) => {
    navigator.clipboard.writeText(mutation.mutatedCode);
    setCopiedId(mutation.id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleApplyMutation = async (mutation: CodeMutation) => {
    setIsApplying(true);
    try {
      const res = await fetch('/api/codebase/mutate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          filePath: mutation.filePath,
          mutatedCode: mutation.mutatedCode,
          action: 'apply',
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Failed to apply mutation');
      }
      setAppliedStatus((prev) => ({
        ...prev,
        [mutation.id]: { applied: true, message: data.message || 'Mutation applied to filesystem!' },
      }));
    } catch (err: any) {
      setAppliedStatus((prev) => ({
        ...prev,
        [mutation.id]: { applied: false, message: `Error: ${err?.message}` },
      }));
    } finally {
      setIsApplying(false);
    }
  };

  const handleRollbackMutation = async (mutation: CodeMutation) => {
    setIsApplying(true);
    try {
      const res = await fetch('/api/codebase/mutate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          filePath: mutation.filePath,
          action: 'rollback',
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Failed to rollback');
      }
      setAppliedStatus((prev) => ({
        ...prev,
        [mutation.id]: { applied: false, message: 'Rolled back to previous version.' },
      }));
    } catch (err: any) {
      alert(`Rollback failed: ${err.message}`);
    } finally {
      setIsApplying(false);
    }
  };

  return (
    <div className="w-full max-w-5xl mx-auto space-y-6">
      {/* Top Generation Banner */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-6 backdrop-blur-md shadow-xl">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-4 border-b border-slate-800">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-mono font-bold tracking-wider text-teal-400 uppercase">
                Generation {result.generation} Evolution Cycle
              </span>
              <span className="text-slate-600">•</span>
              <span className="text-xs font-mono text-slate-400">
                {new Date(result.timestamp).toLocaleTimeString()}
              </span>
              {mutations.length > 0 && (
                <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
                  {mutations.length} Code Mutations
                </span>
              )}
            </div>
            <h2 className="text-xl sm:text-2xl font-bold text-white mt-1">
              Architecture Evolution Specimen #{result.generation}
            </h2>
          </div>

          {/* Decision Pill */}
          <div className="flex items-center gap-2 shrink-0">
            <div className={`px-3 py-1.5 rounded-xl border flex items-center gap-2 ${decisionBadge.bg}`}>
              <span className={`w-2 h-2 rounded-full animate-ping ${decisionBadge.dot}`} />
              <span className="text-xs font-bold font-mono uppercase tracking-wide">
                {decisionBadge.label}
              </span>
            </div>

            {onForkGen && (
              <button
                onClick={onForkGen}
                className="px-3 py-1.5 text-xs font-medium text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-xl border border-slate-700 transition-colors flex items-center gap-1.5"
                title="Fork a new branch from this design iteration"
              >
                <ArrowUpRight className="w-3.5 h-3.5" />
                <span>Fork</span>
              </button>
            )}
          </div>
        </div>

        {/* Reason Callout */}
        {result.reason && (
          <div className="mt-4 p-3 bg-slate-950/80 rounded-xl border border-slate-800/80 flex items-start gap-2.5">
            <Sparkles className="w-4 h-4 text-teal-400 shrink-0 mt-0.5" />
            <p className="text-xs text-slate-300 leading-relaxed font-sans">
              <strong className="text-white">Evolution Rationale: </strong>
              {result.reason}
            </p>
          </div>
        )}
      </div>

      {/* Dynamic Metrics Row */}
      <MetricsPanel metrics={result.key_metrics} generation={result.generation} domain={domain} />

      {/* View Tabs */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-2xl overflow-hidden shadow-xl">
        <div className="flex items-center gap-1 p-2 bg-slate-950 border-b border-slate-800 overflow-x-auto no-scrollbar">
          <button
            onClick={() => setActiveTab('design')}
            className={`px-4 py-2 text-xs font-semibold rounded-xl transition-all whitespace-nowrap shrink-0 flex items-center gap-2 ${
              activeTab === 'design'
                ? 'bg-slate-800 text-teal-300 border border-teal-500/30 shadow-sm'
                : 'text-slate-400 hover:text-white hover:bg-slate-900'
            }`}
          >
            <FileText className="w-3.5 h-3.5" />
            <span>Evolved Specification</span>
          </button>

          {/* New Live Code Mutations Tab */}
          <button
            onClick={() => setActiveTab('code')}
            className={`px-4 py-2 text-xs font-semibold rounded-xl transition-all whitespace-nowrap shrink-0 flex items-center gap-2 ${
              activeTab === 'code'
                ? 'bg-slate-800 text-cyan-300 border border-cyan-500/30 shadow-sm'
                : 'text-slate-400 hover:text-white hover:bg-slate-900'
            }`}
          >
            <Code2 className="w-3.5 h-3.5 text-cyan-400" />
            <span>Live Code Mutations ({mutations.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('graph')}
            className={`px-4 py-2 text-xs font-semibold rounded-xl transition-all whitespace-nowrap shrink-0 flex items-center gap-2 ${
              activeTab === 'graph'
                ? 'bg-slate-800 text-teal-300 border border-teal-500/30 shadow-sm'
                : 'text-slate-400 hover:text-white hover:bg-slate-900'
            }`}
          >
            <Network className="w-3.5 h-3.5" />
            <span>System Node Topology</span>
          </button>
          <button
            onClick={() => setActiveTab('analysis')}
            className={`px-4 py-2 text-xs font-semibold rounded-xl transition-all whitespace-nowrap shrink-0 flex items-center gap-2 ${
              activeTab === 'analysis'
                ? 'bg-slate-800 text-teal-300 border border-teal-500/30 shadow-sm'
                : 'text-slate-400 hover:text-white hover:bg-slate-900'
            }`}
          >
            <BarChart2 className="w-3.5 h-3.5" />
            <span>Scan & Bottleneck Analysis</span>
          </button>
          <button
            onClick={() => setActiveTab('verification')}
            className={`px-4 py-2 text-xs font-semibold rounded-xl transition-all whitespace-nowrap shrink-0 flex items-center gap-2 ${
              activeTab === 'verification'
                ? 'bg-slate-800 text-teal-300 border border-teal-500/30 shadow-sm'
                : 'text-slate-400 hover:text-white hover:bg-slate-900'
            }`}
          >
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>Feasibility & Invariants</span>
          </button>
          <button
            onClick={() => setActiveTab('questions')}
            className={`px-4 py-2 text-xs font-semibold rounded-xl transition-all whitespace-nowrap shrink-0 flex items-center gap-2 ${
              activeTab === 'questions'
                ? 'bg-slate-800 text-teal-300 border border-teal-500/30 shadow-sm'
                : 'text-slate-400 hover:text-white hover:bg-slate-900'
            }`}
          >
            <HelpCircle className="w-3.5 h-3.5" />
            <span>Open Questions ({result.open_questions.length})</span>
          </button>
        </div>

        {/* Tab Contents */}
        <div className="p-6">
          <AnimatePresence mode="wait">
            {activeTab === 'design' && (
              <motion.div
                key="design"
                initial={{ opacity: 0, y: 5 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -5 }}
                className="space-y-4"
              >
                <div className="flex items-center justify-between">
                  <h3 className="text-base font-bold text-white flex items-center gap-2">
                    <FileText className="w-4 h-4 text-teal-400" />
                    <span>Architectural Specification (Markdown AST)</span>
                  </h3>
                  <button
                    onClick={() => {
                      navigator.clipboard.writeText(result.mutated_design);
                      setCopiedId('design');
                      setTimeout(() => setCopiedId(null), 2000);
                    }}
                    className="px-2.5 py-1 text-xs bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg border border-slate-700 flex items-center gap-1.5"
                  >
                    {copiedId === 'design' ? (
                      <>
                        <Check className="w-3 h-3 text-emerald-400" />
                        <span className="text-emerald-400">Copied</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3 h-3" />
                        <span>Copy Spec</span>
                      </>
                    )}
                  </button>
                </div>
                <div className="p-5 bg-slate-950 border border-slate-800/90 rounded-xl font-mono text-xs sm:text-sm text-slate-300 leading-relaxed overflow-x-auto whitespace-pre-wrap selection:bg-teal-500/20 max-h-[500px]">
                  {result.mutated_design}
                </div>
              </motion.div>
            )}

            {/* Live Code Mutations Tab Content */}
            {activeTab === 'code' && (
              <motion.div
                key="code"
                initial={{ opacity: 0, y: 5 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -5 }}
                className="space-y-5"
              >
                <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 pb-3 border-b border-slate-800">
                  <div>
                    <h3 className="text-base font-bold text-white flex items-center gap-2">
                      <Code2 className="w-4 h-4 text-cyan-400" />
                      <span>Synthesized Source Code Files (.tsx / .ts / .css)</span>
                    </h3>
                    <p className="text-xs text-slate-400">
                      Executable code components generated in Generation {result.generation} ready to be applied directly to the filesystem.
                    </p>
                  </div>

                  {activeMutation && (
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => handleCopyCode(activeMutation)}
                        className="px-3 py-1.5 text-xs font-medium bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg border border-slate-700 flex items-center gap-1.5"
                      >
                        {copiedId === activeMutation.id ? (
                          <>
                            <Check className="w-3.5 h-3.5 text-emerald-400" />
                            <span className="text-emerald-400">Copied</span>
                          </>
                        ) : (
                          <>
                            <Copy className="w-3.5 h-3.5" />
                            <span>Copy Code</span>
                          </>
                        )}
                      </button>

                      <button
                        onClick={() => handleApplyMutation(activeMutation)}
                        disabled={isApplying}
                        className="px-3.5 py-1.5 text-xs font-bold bg-teal-500 hover:bg-teal-400 text-slate-950 rounded-lg shadow-sm flex items-center gap-1.5 disabled:opacity-50"
                      >
                        <Upload className="w-3.5 h-3.5" />
                        <span>{isApplying ? 'Writing...' : 'Apply to Disk'}</span>
                      </button>

                      {appliedStatus[activeMutation.id]?.applied && (
                        <button
                          onClick={() => handleRollbackMutation(activeMutation)}
                          className="px-3 py-1.5 text-xs font-medium bg-slate-800 hover:bg-slate-700 text-amber-300 rounded-lg border border-slate-700 flex items-center gap-1.5"
                        >
                          <RotateCcw className="w-3.5 h-3.5" />
                          <span>Rollback</span>
                        </button>
                      )}
                    </div>
                  )}
                </div>

                {appliedStatus[activeMutation?.id]?.message && (
                  <div
                    className={`p-3 rounded-xl border text-xs flex items-center gap-2 ${
                      appliedStatus[activeMutation.id].applied
                        ? 'bg-emerald-950/70 border-emerald-500/40 text-emerald-200'
                        : 'bg-amber-950/70 border-amber-500/40 text-amber-200'
                    }`}
                  >
                    <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400" />
                    <span>{appliedStatus[activeMutation.id].message}</span>
                  </div>
                )}

                {mutations.length > 0 ? (
                  <div className="grid grid-cols-1 md:grid-cols-12 gap-4">
                    {/* File list on left */}
                    <div className="md:col-span-4 space-y-2">
                      <span className="text-[11px] font-mono uppercase text-slate-400 block font-semibold">
                        Generated Files
                      </span>
                      {mutations.map((m, idx) => {
                        const isSelected = idx === selectedMutationIdx;
                        const isApplied = appliedStatus[m.id]?.applied;
                        return (
                          <button
                            key={m.id}
                            onClick={() => setSelectedMutationIdx(idx)}
                            className={`w-full text-left p-3 rounded-xl border transition-all space-y-1 ${
                              isSelected
                                ? 'bg-cyan-500/15 border-cyan-500/40 text-cyan-200'
                                : 'bg-slate-950 hover:bg-slate-900 border-slate-800 text-slate-300'
                            }`}
                          >
                            <div className="flex items-center justify-between gap-1">
                              <span className="text-xs font-mono font-bold truncate">{m.filePath}</span>
                              <span className="text-[9px] font-mono uppercase px-1.5 py-0.5 rounded bg-slate-800 border border-slate-700">
                                {m.fileType}
                              </span>
                            </div>
                            <p className="text-[10px] text-slate-400 line-clamp-2">{m.description}</p>
                            {isApplied && (
                              <span className="text-[9px] font-mono text-emerald-400 font-bold block">
                                ✓ Applied on disk
                              </span>
                            )}
                          </button>
                        );
                      })}
                    </div>

                    {/* Code block on right */}
                    <div className="md:col-span-8 bg-slate-950 border border-slate-800 rounded-xl overflow-hidden flex flex-col">
                      <div className="px-4 py-2.5 bg-slate-900 border-b border-slate-800 flex items-center justify-between">
                        <span className="text-xs font-mono text-slate-300">{activeMutation.filePath}</span>
                        <span className="text-[10px] font-mono text-teal-400">{activeMutation.diffSummary}</span>
                      </div>
                      <pre className="p-4 font-mono text-xs text-slate-200 overflow-x-auto leading-relaxed max-h-[440px] whitespace-pre">
                        {activeMutation.mutatedCode}
                      </pre>
                    </div>
                  </div>
                ) : (
                  <div className="p-8 text-center text-slate-400 border border-slate-800 rounded-xl bg-slate-950">
                    <p className="text-sm">No code mutations generated for this cycle. Run next step to evolve code.</p>
                  </div>
                )}
              </motion.div>
            )}

            {activeTab === 'graph' && (
              <motion.div
                key="graph"
                initial={{ opacity: 0, y: 5 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -5 }}
              >
                <ArchitectureNodeGraph nodes={result.graph_nodes} generation={result.generation} />
              </motion.div>
            )}

            {activeTab === 'analysis' && (
              <motion.div
                key="analysis"
                initial={{ opacity: 0, y: 5 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -5 }}
                className="space-y-4"
              >
                <h3 className="text-base font-bold text-white flex items-center gap-2">
                  <BarChart2 className="w-4 h-4 text-teal-400" />
                  <span>Subsystem Scan & Bottleneck Assessment</span>
                </h3>
                <div className="p-5 bg-slate-950 border border-slate-800/90 rounded-xl font-mono text-xs sm:text-sm text-slate-300 leading-relaxed overflow-x-auto whitespace-pre-wrap">
                  {result.analysis}
                </div>
              </motion.div>
            )}

            {activeTab === 'verification' && (
              <motion.div
                key="verification"
                initial={{ opacity: 0, y: 5 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -5 }}
                className="space-y-4"
              >
                <h3 className="text-base font-bold text-white flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-emerald-400" />
                  <span>Theoretical Feasibility & Invariant Inoculation</span>
                </h3>
                <div className="p-5 bg-slate-950 border border-slate-800/90 rounded-xl font-mono text-xs sm:text-sm text-slate-300 leading-relaxed overflow-x-auto whitespace-pre-wrap">
                  {result.verification}
                </div>
              </motion.div>
            )}

            {activeTab === 'questions' && (
              <motion.div
                key="questions"
                initial={{ opacity: 0, y: 5 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -5 }}
                className="space-y-4"
              >
                <h3 className="text-base font-bold text-white flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 text-amber-400" />
                  <span>Key Open Research & System Challenges</span>
                </h3>
                <div className="space-y-2.5">
                  {result.open_questions.map((q, idx) => (
                    <div
                      key={idx}
                      className="p-4 rounded-xl bg-slate-950 border border-slate-800/90 text-xs sm:text-sm text-slate-200 flex items-start gap-3"
                    >
                      <span className="font-mono text-teal-400 font-bold bg-teal-500/10 px-2 py-0.5 rounded border border-teal-500/20 shrink-0">
                        Q{idx + 1}
                      </span>
                      <p className="leading-relaxed">{q}</p>
                    </div>
                  ))}
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
};
