'use client';

import React from 'react';
import { Play, Pause, StepForward, RotateCcw, Download, Sparkles, CheckCircle, AlertTriangle, GitBranch } from 'lucide-react';

interface LoopControlsProps {
  generation: number;
  maxGenerations: number;
  status: 'idle' | 'running' | 'paused' | 'stopped' | 'error';
  onStep: () => void;
  onToggleAutoRun: () => void;
  onReset: () => void;
  onExport: () => void;
  onOpenGitHubPush?: () => void;
  autoRun: boolean;
}

export const LoopControls: React.FC<LoopControlsProps> = ({
  generation,
  maxGenerations,
  status,
  onStep,
  onToggleAutoRun,
  onReset,
  onExport,
  onOpenGitHubPush,
  autoRun,
}) => {
  const isRunning = status === 'running';

  return (
    <div className="sticky bottom-4 z-40 w-full max-w-4xl mx-auto px-4">
      <div className="bg-slate-900/95 border border-slate-700/80 rounded-2xl p-4 shadow-2xl shadow-slate-950 backdrop-blur-xl flex flex-col sm:flex-row items-center justify-between gap-4">
        {/* Status info */}
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-teal-500/10 border border-teal-500/30 flex items-center justify-center text-teal-400 shrink-0">
            {isRunning ? (
              <Sparkles className="w-5 h-5 animate-spin" />
            ) : status === 'stopped' ? (
              <CheckCircle className="w-5 h-5 text-emerald-400" />
            ) : status === 'error' ? (
              <AlertTriangle className="w-5 h-5 text-amber-400" />
            ) : (
              <Sparkles className="w-5 h-5" />
            )}
          </div>

          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-white uppercase tracking-wide">
                Recursive Loop State
              </span>
              <span
                className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded border uppercase ${
                  isRunning
                    ? 'bg-teal-500/20 text-teal-300 border-teal-500/30 animate-pulse'
                    : status === 'stopped'
                    ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30'
                    : 'bg-slate-800 text-slate-300 border-slate-700'
                }`}
              >
                {status}
              </span>
            </div>

            <p className="text-xs text-slate-400 font-mono">
              Generation <span className="text-teal-300 font-bold">{generation}</span> of {maxGenerations}
            </p>
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
          {/* Step 1 Gen */}
          <button
            onClick={onStep}
            disabled={isRunning || generation >= maxGenerations || status === 'stopped'}
            className="px-3.5 py-2 text-xs font-medium bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl border border-slate-700 transition-colors disabled:opacity-40 flex items-center gap-1.5"
            title="Perform single evolution step (Scan -> Analyse -> Mutate -> Verify)"
          >
            <StepForward className="w-3.5 h-3.5" />
            <span>Step 1 Gen</span>
          </button>

          {/* Toggle Auto Run */}
          <button
            onClick={onToggleAutoRun}
            disabled={generation >= maxGenerations || status === 'stopped'}
            className={`px-4 py-2 text-xs font-bold rounded-xl border transition-all flex items-center gap-1.5 shadow-md ${
              autoRun
                ? 'bg-amber-500 text-slate-950 border-amber-400 hover:bg-amber-400'
                : 'bg-teal-500 text-slate-950 border-teal-400 hover:bg-teal-400 shadow-teal-500/20'
            } disabled:opacity-40`}
          >
            {autoRun ? (
              <>
                <Pause className="w-3.5 h-3.5 fill-slate-950" />
                <span>Pause Auto-Run</span>
              </>
            ) : (
              <>
                <Play className="w-3.5 h-3.5 fill-slate-950" />
                <span>Auto-Evolve</span>
              </>
            )}
          </button>

          {/* Export Report */}
          <button
            onClick={onExport}
            className="px-3.5 py-2 text-xs font-medium bg-slate-950 hover:bg-slate-850 text-slate-300 hover:text-white rounded-xl border border-slate-800 transition-colors flex items-center gap-1.5"
            title="Export full Biological AI design report"
          >
            <Download className="w-3.5 h-3.5" />
            <span className="hidden xs:inline">Export</span>
          </button>

          {/* GitHub Commit / Push */}
          {onOpenGitHubPush && (
            <button
              onClick={onOpenGitHubPush}
              className="px-3.5 py-2 text-xs font-medium bg-slate-800 hover:bg-slate-700 text-teal-300 rounded-xl border border-teal-500/30 transition-colors flex items-center gap-1.5"
              title="Push evolution commit to GitHub"
            >
              <GitBranch className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Push Commit</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
