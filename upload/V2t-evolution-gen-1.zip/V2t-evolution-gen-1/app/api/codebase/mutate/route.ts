import { NextRequest, NextResponse } from "next/server";
import fs from "fs/promises";
import path from "path";

// Allowed extensions for source code mutation
const ALLOWED_EXTENSIONS = new Set([".tsx", ".ts", ".css", ".json", ".md"]);

// Paths strictly forbidden from runtime mutation
const FORBIDDEN_FILENAMES = new Set([
  ".env",
  ".env.local",
  ".env.example",
  "package.json",
  "package-lock.json",
  "bun.lock",
  "tsconfig.json",
  "next.config.ts",
  "eslint.config.mjs"
]);

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { filePath, mutatedCode, action = "apply" } = body;

    if (!filePath || typeof filePath !== "string") {
      return NextResponse.json(
        { error: "filePath is required." },
        { status: 400 }
      );
    }

    // Normalize path and prevent directory traversal
    const cleanRelativePath = filePath.replace(/^(\.\/|\/)/, "").trim();
    const resolvedPath = path.resolve(process.cwd(), cleanRelativePath);
    const workspaceRoot = path.resolve(process.cwd());

    // Security check: Must reside inside workspace root
    if (!resolvedPath.startsWith(workspaceRoot)) {
      return NextResponse.json(
        { error: "Forbidden: Path escapes workspace root." },
        { status: 403 }
      );
    }

    const ext = path.extname(cleanRelativePath).toLowerCase();
    const baseName = path.basename(cleanRelativePath).toLowerCase();

    if (FORBIDDEN_FILENAMES.has(baseName) || cleanRelativePath.includes("node_modules") || cleanRelativePath.includes(".git")) {
      return NextResponse.json(
        { error: `Forbidden: Critical configuration file '${cleanRelativePath}' cannot be mutated directly.` },
        { status: 403 }
      );
    }

    if (!ALLOWED_EXTENSIONS.has(ext)) {
      return NextResponse.json(
        { error: `Invalid extension: Only ${Array.from(ALLOWED_EXTENSIONS).join(", ")} files can be mutated.` },
        { status: 400 }
      );
    }

    const backupPath = `${resolvedPath}.evolution.bak`;

    // Handle Rollback
    if (action === "rollback") {
      try {
        const backupContent = await fs.readFile(backupPath, "utf-8");
        await fs.writeFile(resolvedPath, backupContent, "utf-8");
        await fs.unlink(backupPath).catch(() => {});
        return NextResponse.json({
          success: true,
          action: "rollback",
          filePath: cleanRelativePath,
          message: `File '${cleanRelativePath}' successfully restored from backup snapshot.`,
        });
      } catch (err: any) {
        return NextResponse.json(
          { error: `No backup available for '${cleanRelativePath}' to rollback.` },
          { status: 404 }
        );
      }
    }

    // Handle Apply / Create Mutation
    if (typeof mutatedCode !== "string") {
      return NextResponse.json(
        { error: "mutatedCode string is required to apply mutation." },
        { status: 400 }
      );
    }

    let originalContent = "";
    let fileExists = false;

    try {
      originalContent = await fs.readFile(resolvedPath, "utf-8");
      fileExists = true;
      // Save backup snapshot before overwriting
      await fs.writeFile(backupPath, originalContent, "utf-8");
    } catch {
      // File does not exist yet (create action)
      fileExists = false;
    }

    // Ensure parent directory exists
    await fs.mkdir(path.dirname(resolvedPath), { recursive: true });

    // Write mutated code to actual disk file
    await fs.writeFile(resolvedPath, mutatedCode, "utf-8");

    const originalLines = fileExists ? originalContent.split("\n").length : 0;
    const newLines = mutatedCode.split("\n").length;

    return NextResponse.json({
      success: true,
      action: fileExists ? "modified" : "created",
      filePath: cleanRelativePath,
      linesBefore: originalLines,
      linesAfter: newLines,
      bytesWritten: Buffer.byteLength(mutatedCode, "utf-8"),
      hasBackup: fileExists,
      timestamp: new Date().toISOString(),
      message: fileExists
        ? `Successfully applied mutation to '${cleanRelativePath}' (${newLines} lines). Backup snapshot created.`
        : `Successfully created new component '${cleanRelativePath}' (${newLines} lines).`,
    });
  } catch (error: any) {
    console.error("Error applying code mutation:", error);
    return NextResponse.json(
      { error: error?.message || "Failed to apply code mutation." },
      { status: 500 }
    );
  }
}

// GET: Read live file content from disk for inspector
export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const target = searchParams.get("path");

    if (!target) {
      return NextResponse.json({ error: "path parameter is required." }, { status: 400 });
    }

    const cleanRelativePath = target.replace(/^(\.\/|\/)/, "").trim();
    const resolvedPath = path.resolve(process.cwd(), cleanRelativePath);
    const workspaceRoot = path.resolve(process.cwd());

    if (!resolvedPath.startsWith(workspaceRoot)) {
      return NextResponse.json({ error: "Forbidden path." }, { status: 403 });
    }

    const content = await fs.readFile(resolvedPath, "utf-8");
    const stat = await fs.stat(resolvedPath);
    const backupPath = `${resolvedPath}.evolution.bak`;
    let hasBackup = false;
    try {
      await fs.access(backupPath);
      hasBackup = true;
    } catch {
      hasBackup = false;
    }

    return NextResponse.json({
      filePath: cleanRelativePath,
      content,
      size: stat.size,
      lines: content.split("\n").length,
      lastModified: stat.mtime.toISOString(),
      hasBackup,
    });
  } catch (err: any) {
    return NextResponse.json({ error: err?.message || "File not found" }, { status: 404 });
  }
}
