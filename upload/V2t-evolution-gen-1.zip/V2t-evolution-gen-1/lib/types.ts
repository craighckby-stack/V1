export type DomainCategory = 
  | 'biological-ai'
  | 'software-architecture'
  | 'codebase-meta'
  | 'quant-trading'
  | 'aerospace-physics'
  | 'game-balancer'
  | 'governance-tokenomics';

export interface DomainConfig {
  id: DomainCategory;
  name: string;
  tagline: string;
  badge: string;
  iconName: string;
  description: string;
  subFocusLabel: string;
  subFocusOptions: Array<{ id: string; label: string; desc: string }>;
  metricLabels: {
    m1Title: string;
    m1Desc: string;
    m2Title: string;
    m2Desc: string;
    m3Title: string;
    m3Desc: string;
    m4Title: string;
    m4Desc: string;
  };
  systemPrompt: string;
}

export interface CodeMutation {
  id: string;
  filePath: string;
  fileType: 'tsx' | 'ts' | 'css' | 'json';
  description: string;
  action: 'create' | 'modify';
  mutatedCode: string;
  originalSnippet?: string;
  diffSummary?: string;
  linesAdded?: number;
  linesRemoved?: number;
  applied?: boolean;
}

export interface ArchitectureNode {
  id: string;
  label: string;
  type: 'input' | 'transducer' | 'processor' | 'memory' | 'output' | 'feedback' | 'service' | 'module';
  description: string;
  substrate: string;
  connections: string[];
}

export interface KeyMetrics {
  coherenceScore: number; // 0 - 100
  metricTwoValue: string; // Dynamic label 2
  metricThreeValue: string; // Dynamic label 3
  metricFourValue: string; // Dynamic label 4
  plasticityIndex: number; // 0 - 100
}

export interface GenerationResult {
  generation: number;
  timestamp: string;
  domain: DomainCategory;
  analysis: string;
  mutated_design: string;
  verification: string;
  decision: 'continue' | 'stop' | 'pivot';
  reason: string;
  open_questions: string[];
  graph_nodes: ArchitectureNode[];
  key_metrics: KeyMetrics;
  code_mutations?: CodeMutation[];
}

export interface LoopState {
  generation: number;
  maxGenerations: number;
  domain: DomainCategory;
  goal: string;
  substrateFocus: string;
  currentDesign: string;
  history: GenerationResult[];
  status: 'idle' | 'running' | 'paused' | 'stopped' | 'error';
  error: string | null;
}

export interface PresetGoal {
  id: string;
  domain: DomainCategory;
  title: string;
  substrate: string;
  description: string;
  goalPrompt: string;
}
