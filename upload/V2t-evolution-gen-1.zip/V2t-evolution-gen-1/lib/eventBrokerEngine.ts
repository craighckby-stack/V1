/**
 * High-Throughput Event Broker Engine (CQRS / Partitioned Log)
 * Implements in-memory append-only ring buffer with deterministic partition hashing.
 */

export interface SystemEvent<T = any> {
  id: string;
  partitionKey: string;
  topic: string;
  payload: T;
  timestamp: number;
  offset: number;
}

export class PartitionedEventBroker {
  private partitions: Map<number, SystemEvent[]> = new Map();
  private numPartitions: number;
  private currentOffsets: Map<number, number> = new Map();

  constructor(numPartitions: number = 8) {
    this.numPartitions = numPartitions;
    for (let i = 0; i < numPartitions; i++) {
      this.partitions.set(i, []);
      this.currentOffsets.set(i, 0);
    }
  }

  private hashKey(key: string): number {
    let hash = 0;
    for (let i = 0; i < key.length; i++) {
      hash = (hash << 5) - hash + key.charCodeAt(i);
      hash |= 0;
    }
    return Math.abs(hash) % this.numPartitions;
  }

  public publish<T>(topic: string, partitionKey: string, payload: T): SystemEvent<T> {
    const partitionId = this.hashKey(partitionKey);
    const offset = this.currentOffsets.get(partitionId) || 0;
    const event: SystemEvent<T> = {
      id: `evt-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
      partitionKey,
      topic,
      payload,
      timestamp: Date.now(),
      offset,
    };

    const pQueue = this.partitions.get(partitionId) || [];
    pQueue.push(event);
    if (pQueue.length > 500) pQueue.shift(); // Evict oldest
    this.currentOffsets.set(partitionId, offset + 1);

    return event;
  }

  public getPartitionStats() {
    return Array.from(this.partitions.entries()).map(([pId, events]) => ({
      partitionId: pId,
      queueDepth: events.length,
      latestOffset: this.currentOffsets.get(pId) || 0,
    }));
  }
}
