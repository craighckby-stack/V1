/**
 * Synthetic Gene Regulatory Circuit Kinetics Engine
 * Computes Hill transcription equations and mutual-inhibition toggle switch cycles.
 */

export interface GeneKineticsState {
  promoterActivity: number;
  mrnaConcentration: number;
  proteinConcentration: number;
  degradationRate: number;
}

export function computeHillKinetics(
  inducerConcentration: number,
  kHalf: number = 0.5,
  cooperativityCoeff: number = 2.4
): number {
  const top = Math.pow(Math.max(0, inducerConcentration), cooperativityCoeff);
  const bottom = Math.pow(kHalf, cooperativityCoeff) + top;
  return top / (bottom || 1);
}

export function simulateToggleSwitchCycle(
  stateA: GeneKineticsState,
  stateB: GeneKineticsState,
  dt: number = 0.05
): { nextA: GeneKineticsState; nextB: GeneKineticsState } {
  const repressionA = 1 / (1 + Math.pow(stateB.proteinConcentration / 0.8, 2.2));
  const repressionB = 1 / (1 + Math.pow(stateA.proteinConcentration / 0.8, 2.2));

  const dProteinA = (repressionA - stateA.degradationRate * stateA.proteinConcentration) * dt;
  const dProteinB = (repressionB - stateB.degradationRate * stateB.proteinConcentration) * dt;

  return {
    nextA: {
      ...stateA,
      proteinConcentration: Math.max(0, stateA.proteinConcentration + dProteinA),
    },
    nextB: {
      ...stateB,
      proteinConcentration: Math.max(0, stateB.proteinConcentration + dProteinB),
    },
  };
}
