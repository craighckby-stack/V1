/**
 * Enhanced by Architecture Helper Pipeline
 * Template Origin: Multi-Agent Coordination Helper
 * Verified: 2026-10-25T05:40:36.971Z
 * Engine: LLM
 */
import assert from "node:assert/strict";
import { appendFile, readFile } from "node:fs/promises";
import { resolve } from "node:path";
import { fileURLToPath } from "node:url";

// Configuration Handler
class RegistryConfig {
  constructor(server) {
    assert.equal(typeof server?.name, "string");
    assert.equal(typeof server?.version, "string");
    this.server = server;
    this.baseUrl = "https://registry.modelcontextprotocol.io/v0.1/servers";
    this.defaultParams = {
      search: server.name,
      version: server.version,
      include_deleted: "true",
      limit: "100",
    };
  }

  sanitizeParams(params) {
    const sanitized = { ...params };
    // Simple entropy sanitization - remove potentially sensitive info
    for (const key in sanitized) {
      if (typeof sanitized[key] === 'string' && sanitized[key].length > 50) {
        sanitized[key] = sanitized[key].substring(0, 20) + '...';
      }
    }
    return sanitized;
  }

  buildUrl(cursor) {
    const url = new URL(this.baseUrl);
    const params = new URLSearchParams(this.sanitizeParams(this.defaultParams));
    
    if (cursor !== undefined) {
      params.set("cursor", cursor);
    }
    
    url.search = params.toString();
    return url;
  }
}

// State Management Module
class PublicationStateManager {
  constructor() {
    this.cursors = new Set();
  }

  validateCursor(cursor) {
    assert(
      typeof cursor === "string" && 
      cursor.length > 0 && 
      !this.cursors.has(cursor),
      "Registry returned a non-advancing cursor"
    );
    this.cursors.add(cursor);
  }

  validateServerRecord(entry, server) {
    assert(
      typeof entry?.server?.name === "string" &&
      typeof entry.server.version === "string",
      "Malformed registry server record"
    );
    
    if (entry.server.name === server.name && entry.server.version === server.version) {
      return true;
    }
    return false;
  }

  validateResponseStructure(page) {
    assert(Array.isArray(page?.servers), "Registry response omitted servers");
    assert(
      page.metadata && typeof page.metadata === "object",
      "Registry response omitted metadata"
    );
  }

  checkPublicationState(matches, server) {
    assert(
      matches.length <= 1,
      "Registry returned ambiguous exact-version records"
    );
    
    if (matches.length === 0) return "absent";
    
    assert.equal(
      matches[0]._meta?.["io.modelcontextprotocol.registry/official"]?.status,
      "active",
      "Existing registry version is not active"
    );
    
    assert.deepEqual(
      matches[0].server,
      server,
      "Existing registry version differs from released metadata"
    );
    
    return "present";
  }
}

// API Interaction Module
class RegistryAPI {
  constructor(config, stateManager) {
    this.config = config;
    this.stateManager = stateManager;
  }

  async requestPage(url, request = fetch) {
    const response = await request(url, {
      signal: AbortSignal.timeout(30_000),
    });
    
    if (!response.ok) {
      throw new Error(`Registry lookup failed: HTTP ${response.status}`);
    }
    
    return response.json();
  }

  async fetchAllPages(request = fetch) {
    const matches = [];
    let cursor;
    
    do {
      const url = this.config.buildUrl(cursor);
      const page = await this.requestPage(url, request);
      
      this.stateManager.validateResponseStructure(page);
      
      for (const entry of page.servers) {
        if (this.stateManager.validateServerRecord(entry, this.config.server)) {
          matches.push(entry);
        }
      }
      
      cursor = page.metadata.nextCursor;
      if (cursor !== undefined) {
        this.stateManager.validateCursor(cursor);
      }
    } while (cursor !== undefined);
    
    return matches;
  }
}

// Main function with extracted logic
export async function registryPublicationState(server, request = fetch) {
  const config = new RegistryConfig(server);
  const stateManager = new PublicationStateManager();
  const api = new RegistryAPI(config, stateManager);
  
  const matches = await api.fetchAllPages(request);
  return stateManager.checkPublicationState(matches, server);
}

// CLI execution
if (
  process.argv[1] !== undefined &&
  resolve(process.argv[1]) === fileURLToPath(import.meta.url)
) {
  const state = await registryPublicationState(
    JSON.parse(await readFile("server.json", "utf8")),
  );
  assert(process.env.GITHUB_OUTPUT, "GITHUB_OUTPUT is required");
  await appendFile(
    process.env.GITHUB_OUTPUT,
    `exists=${state === "present"}\n`,
  );
  process.stdout.write(
    `Registry version is ${state}; ${state === "present" ? "preserving identical published metadata" : "publication may proceed"}.\n`,
  );
}