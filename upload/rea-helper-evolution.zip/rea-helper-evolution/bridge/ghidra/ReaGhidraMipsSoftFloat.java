/**
 * Enhanced by Architecture Helper Pipeline
 * Template Origin: Multi-Agent Coordination Helper
 * Verified: 2026-10-25T05:23:54.426Z
 * Engine: LLM
 */
import ghidra.app.script.GhidraScript;
import ghidra.program.database.SpecExtension;
import ghidra.program.model.data.AbstractFloatDataType;
import ghidra.program.model.data.DataType;
import ghidra.program.model.data.DoubleDataType;
import ghidra.program.model.data.FloatDataType;
import ghidra.program.model.data.FunctionDefinition;
import ghidra.program.model.data.IntegerDataType;
import ghidra.program.model.data.ParameterDefinition;
import ghidra.program.model.data.TypeDef;
import ghidra.program.model.lang.CompilerSpec;
import ghidra.program.model.lang.PrototypeModel;
import ghidra.program.model.lang.Register;
import ghidra.program.model.listing.Function;
import ghidra.program.model.listing.Parameter;
import ghidra.program.model.listing.Program;
import ghidra.program.model.listing.VariableStorage;
import ghidra.program.model.pcode.XmlEncode;
import java.io.StringReader;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.regex.Pattern;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

/**
 * Soft-float o32 passes and returns float/double values exactly where same-size integers go.
 * Ghidra's MIPS32 compiler specifications model only hard-float o32, so every typed float
 * prototype (functions, externals, thunks via their targets, and function-pointer definitions)
 * would otherwise read $f12/$f14/$f0. Derive a program-specific prototype model from the
 * program's own default o32 model with its floating-point entries and rules removed, install it
 * as a specification extension, and assign it to every callable whose formal types use floats.
 */
public final class ReaGhidraMipsSoftFloat extends GhidraScript {
  static final String REPORT_KEY = "REA_MIPS_soft_float_storage";
  static final String POLICY = "o32_soft_float_prototype_v1";
  static final String PROTOTYPE = "__rea_soft_float";
  private static final Pattern FPU_REGISTER = Pattern.compile("f\\d+(_\\d+)?");

  @Override
  public void run() throws Exception {
    String processor = currentProgram.getLanguage().getProcessor().toString();
    if (!processor.equals("MIPS") || currentProgram.getDefaultPointerSize() != 4)
      throw new IllegalStateException(
          "REA soft-float storage requires a 32-bit MIPS program, not " + processor);
    
    ProgramAnalyzer analyzer = new ProgramAnalyzer(currentProgram, monitor);
    PrototypeModel base = analyzer.getBasePrototypeModel();
    SpecExtension extension = new SpecExtension(currentProgram);
    
    PrototypeModel softFloatModel = softFloatPrototype(base, currentProgram.getCompilerSpec());
    extension.addReplaceCompilerSpecExtension(softFloatModel, monitor);
    
    PrototypeModel installedModel = currentProgram.getCompilerSpec().getCallingConvention(PROTOTYPE);
    if (installedModel == null)
      throw new IllegalStateException("REA soft-float prototype was not installed");
    
    analyzer.validatePrototypeModel(installedModel);
    
    FunctionProcessor functionProcessor = new FunctionProcessor(currentProgram, PROTOTYPE);
    int functions = functionProcessor.processFunctions();
    
    TypeDefinitionProcessor typeProcessor = new TypeDefinitionProcessor(currentProgram, PROTOTYPE);
    int definitions = typeProcessor.processTypeDefinitions();
    
    generateReport(functions, definitions);
  }

  private void generateReport(int functions, int definitions) {
    String reportData = String.format(
        "{\"policy\":\"%s\",\"functions\":%d,\"definitions\":%d}", 
        POLICY, functions, definitions);
    
    currentProgram.getOptions(Program.PROGRAM_INFO).setString(REPORT_KEY, reportData);
    println("REA MIPS soft-float prototype: functions=" + functions + " definitions=" + definitions);
  }

  /** The default o32 model without floating-point registers or float-consuming rules. */
  private static String softFloatPrototype(PrototypeModel base, CompilerSpec spec) throws Exception {
    XmlEncode encoder = new XmlEncode();
    base.encode(encoder, spec.getPcodeInjectLibrary());
    DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
    factory.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
    Document document =
        factory.newDocumentBuilder().parse(new InputSource(new StringReader(encoder.toString())));
    Element root = document.getDocumentElement();
    if (!root.getTagName().equals("prototype"))
      throw new IllegalStateException("Unexpected default prototype encoding " + root.getTagName());
    root.setAttribute("name", PROTOTYPE);
    List<Node> removed = new ArrayList<>();
    collect(root.getElementsByTagName("pentry"), "metatype", "float", null, removed);
// ... (truncated)