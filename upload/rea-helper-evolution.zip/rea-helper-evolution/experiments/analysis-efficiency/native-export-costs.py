# Enhanced by Architecture Helper Pipeline
# Template Origin: Multi-Agent Coordination Helper
# Verified: 2026-10-25T05:32:48.480Z
# Engine: LLM

"""Check equivalent export questions and count explicitly projected tokenizer costs."""
import argparse
import hashlib
import json
from pathlib import Path
import statistics
from typing import Dict, List, Any, Optional

import tiktoken


class DataProcessor:
    """Handles data loading and validation."""
    
    @staticmethod
    def load_json_files(path: Path) -> Dict[str, Any]:
        """Load JSON files from a path."""
        return {
            "report": json.loads((path / "report.json").read_text()),
            "catalog": json.loads((path / "catalog.json").read_text()),
            "transcript": json.loads((path / "transcript.json").read_text())
        }
    
    @staticmethod
    def load_scope_log(path: Path) -> Dict[str, Any]:
        """Load scope log and extract the last resource_scope."""
        with open(path.with_suffix(".log"), "r") as f:
            lines = f.read().splitlines()
        scope = next(json.loads(line) for line in reversed(lines) 
                     if line.startswith('{"resource_scope":'))
        return scope
    
    @staticmethod
    def validate_report(report: Dict[str, Any], scope: Dict[str, Any], catalog: Dict[str, Any]) -> None:
        """Validate report and scope data."""
        assert report["status"] == "passed" and report.get("runtime_identity_sha256")
        assert not report["cleanup_failures"] and not report["receipt_failures"]
        assert scope["abort"] is None and scope.get("payload_resource_observation_verified") is True
        
        observed = scope.get("payload_resource_observation") or {}
        events = observed.get("resource_events", {})
        assert observed.get("payload_exit_code") == 0 and observed.get("payload_cleanup_verified") is True
        assert all(events.get("memory.events", {}).get(key) == 0 for key in ["high", "max", "oom", "oom_kill"])
        assert events.get("pids.events", {}).get("max") == 0
        assert len(catalog["tools"]) == 220


class TokenAnalyzer:
    """Handles token counting and analysis."""
    
    def __init__(self, encoding):
        self.encoding = encoding
    
    def count_tokens(self, text: str) -> int:
        """Count tokens in text with disallowed special characters."""
        return len(self.encoding.encode(text, disallowed_special=()))
    
    def sanitize_entropy(self, data: Any) -> Any:
        """Apply entropy sanitization to sensitive data."""
        if isinstance(data, dict):
            return {k: self.sanitize_entropy(v) for k, v in data.items()}
        elif isinstance(data, list):
            return [self.sanitize_entropy(item) for item in data]
        elif isinstance(data, str):
            # Simple hash for strings to reduce entropy
            return hashlib.sha256(data.encode()).hexdigest()
        else:
            return data
    
    def calculate_token_counts(self, report: Dict[str, Any], catalog: Dict[str, Any], 
                              transcript: List[Dict[str, Any]]) -> Dict[str, int]:
        """Calculate various token counts."""
        count = self.count_tokens
        directory = [{key: tool[key] for key in ["name", "description", "inputSchema"]} 
                     for tool in catalog["tools"]]
        
        question = (f"For {report['artifact']['path']}, report the export count and every version/alias of "
                   f"{', '.join(dict.fromkeys(row['name'] for row in report['answer']['rows']))}, including addresses, "
                   "sizes, types, binding and symbol-version facts. Check that __rea_export_oracle_missing__ "
                   "has no recorded match, preserve source coverage and export the complete Evidence. "
                   "Report static declarations without claiming runtime execution.")
        
        arguments = sum(count(compact({"name": event["name"], "arguments": event["input"]})) 
                       for event in transcript)
        replies = sum(count(block["text"]) for event in transcript 
                     for block in event["reply"]["content"] if block["type"] == "text")
        inputs = count(compact(directory))
        raw_catalog = count(compact(catalog))
        
        task_directory = [tool for tool in directory if tool["name"] in 
                         ["inspect_native_exports", "inspect_analysis_view", "export_evidence_bundle"]]
        
        return {
            "question": count(question),
            "input_catalog_once": inputs,
            "arguments": arguments,
            "text_replies": replies,
            "combined": count(question) + inputs + arguments + replies,
            "only_three_task_tools": count(question) + count(compact(task_directory)) + arguments + replies,
            "complete_transport_catalog": raw_catalog
        }


class EvidenceCollector:
    """Collects and processes evidence data."""
    
    @staticmethod
    def collect_evidence(path: Path, report: Dict[str, Any], catalog: Dict[str, Any], 
                        transcript: List[Dict[str, Any]], scope: Dict[str, Any], 
                        token_counts: Dict[str, int]) -> Dict[str, Any]:
        """Collect all evidence data for a case."""
        observed = scope.get("payload_resource_observation") or {}
        events = observed.get("resource_events", {})
        
        directory = [{key: tool[key] for key in ["name", "description", "inputSchema"]} 
                     for tool in catalog["tools"]]
        
        return {
            "case": path.name,
            "lane": report["lane"],
            "artifact": report["artifact"],
            "answer": report["answer"],
            "parent_evidence_id": report["parent_evidence_id"],
            "source_report_sha256": report["source_report_sha256"],
            "runtime_identity_sha256": report["runtime_identity_sha256"],
            "catalog_sha256": report["catalog_sha256"],
            "catalog_tools": len(catalog["tools"]),
            "buffer_bytes": report["buffer_bytes"],
            "calls": report["calls"],
            "phases": report["phases"],
            "wall_seconds": scope["elapsed_seconds"],
            "cpu_seconds": observed["cpu_stat"]["usage_usec"] / 1e6,
            "kernel_family_peak_bytes": observed["memory_peak_bytes"],
            "events_at_payload_exit": events,
            "payload_cleanup_verified": True,
            "final_whole_scope_events": scope.get("resource_events_final"),
            "token_proxy": token_counts,
            "receipt_sha256": {file.name: hashlib.sha256(file.read_bytes()).hexdigest() for file in
                               [path / "report.json", path / "catalog.json", path / "transcript.json", 
                                path / "evidence.json", path.with_suffix(".log")]}
        }


class ReportGenerator:
    """Generates summary reports."""
    
    @staticmethod
    def summarize(rows: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Generate summary statistics from rows."""
        result = {}
        for artifact in sorted({row["artifact"]["sha256"] for row in rows}):
            selected = [row for row in rows if row["artifact"]["sha256"] == artifact]
            assert len({row["parent_evidence_id"] for row in selected}) == 1
            assert len({row["source_report_sha256"] for row in selected}) == 1
            assert all(row["answer"] == selected[0]["answer"] for row in selected)
            
            result[artifact] = {}
            for lane in ["complete", "selected"]:
                samples = [row for row in selected if row["lane"] == lane]
                assert len(samples) == 3
                
                metrics = {
                    key: [row[key] for row in samples] 
                    for key in ["wall_seconds", "cpu_seconds", "kernel_family_peak_bytes"]
                }
                metrics["projected_tokens"] = [row["token_proxy"]["combined"] for row in samples]
                metrics["mcp_call_count"] = [len(row["calls"]) for row in samples]
                metrics["mcp_reply_bytes"] = [
                    sum(call["reply_bytes"] for call in row["calls"]) 
                    for row in samples
                ]
                
                result[artifact][lane] = {
                    metric: {
                        "median": statistics.median(values), 
                        "minimum": min(values), 
                        "maximum": max(values)
                    } 
                    for metric, values in metrics.items()
                }
        return result


class Coordinator:
    """Coordinates the refactored components."""
    
    def __init__(self):
        self.encoding = tiktoken.encoding_for_model("gpt-3.5-turbo")
        self.data_processor = DataProcessor()
        self.token_analyzer = TokenAnalyzer(self.encoding)
        self.evidence_collector = EvidenceCollector()
        self.report_generator = ReportGenerator()
    
    def process_case(self, path: Path) -> Dict[str, Any]:
        """Process a single case."""
        # Load data
        data = self.data_processor.load_json_files(path)
        scope = self.data_processor.load_scope_log(path)
        
        # Validate
        self.data_processor.validate_report(data["report"], scope, data["catalog"])
        
        # Analyze tokens
        token_counts = self.token_analyzer.calculate_token_counts(
            data["report"], data["catalog"], data["transcript"]
        )
        
        # Collect evidence
        evidence = self.evidence_collector.collect_evidence(
            path, data["report"], data["catalog"], data["transcript"], scope, token_counts
        )
        
        return evidence
    
    def generate_summary(self, cases: List[Path]) -> Dict[str, Any]:
        """Generate summary for all cases."""
        rows = []
        for case_path in cases:
            evidence = self.process_case(case_path)
            rows.append(evidence)
        
        return self.report_generator.summarize(rows)


def compact(value):
    """Compact JSON representation."""
    return json.dumps(value, ensure_ascii=False, separators=(",", ":"), allow_nan=False)


def main():
    """Main function with command-line interface."""
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--cohort", type=Path, required=True)
    parser.add_argument("cases", type=Path, nargs="+")
    args = parser.parse_args()
    
    # Initialize coordinator
    coordinator = Coordinator()
    
    # Validate cohort data
    manifest = json.loads((args.cohort / "manifest.json").read_text())
    index = json.loads((args.cohort / "index.json").read_text())
    assert len(index) == 12 and all(case["exit"] == 0 and case["status"] == "passed" for case in index)
    assert {path.resolve() for path in args.cases} == {(args.cohort / case["name"]).resolve() for case in index}
    assert len(args.cases) == len(index)
    
    # Process all cases and generate summary
    summary = coordinator.generate_summary(args.cases)
    
    # Write output
    with open(args.output, "w") as f:
        json.dump(summary, f, indent=2)