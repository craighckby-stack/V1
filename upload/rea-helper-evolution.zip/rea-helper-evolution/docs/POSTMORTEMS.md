# Neural Engine Post-Mortems

## Auto-Generated Lessons & Negative Constraints








































### ❌ [2026-10-25] bridge/cutter/rea_bridge.py `source: mutation-cycle`
**Symptom:** AST / TypeScript Compiler Validation Rejected
**EVIDENCE (Machine-Copied Fact):**
```
Line 1, Col 1: Header Stripped: Original file contained 16 import statements, but candidate contains zero imports. Module imports and file headers were wiped out.
Line 1, Col 1: Header Stripped: Original file contained 16 import statements, but candidate contains zero imports. Module imports and file headers were wiped out.
```
**DIAGNOSIS:** <Specific generation mechanism that caused failure — name the technical mechanism, not the symptom>
**CONSTRAINT (Model Generalization):** <One imperative, testable instruction that future prompts must follow to avoid this specific error>
**FINGERPRINT:** `bridge/cutter/rea_bridge.py::Line _, Col _: Header Stripped: Original file contained 16 import statements, but candidate contains zero imports. Module imports and file headers were wiped out. Line _, Col _: Header Stripped: Original file contained 16 import statements, but candidate contains zero imports. Module imports and file headers were wiped out.` (Occurrences: 1)
**STATUS:** ACTIVE







































### ❌ [2026-10-25] bridge/hopper_bridge.py `source: mutation-cycle`
**Symptom:** AST / TypeScript Compiler Validation Rejected
**EVIDENCE (Machine-Copied Fact):**
```
Line 1, Col 1: Header Stripped: Original file contained 6 import statements, but candidate contains zero imports. Module imports and file headers were wiped out.
Line 1, Col 1: Header Stripped: Original file contained 6 import statements, but candidate contains zero imports. Module imports and file headers were wiped out.
```
**DIAGNOSIS:** <Specific generation mechanism that caused failure — name the technical mechanism, not the symptom>
**CONSTRAINT (Model Generalization):** <One imperative, testable instruction that future prompts must follow to avoid this specific error>
**FINGERPRINT:** `bridge/hopper_bridge.py::Line _, Col _: Header Stripped: Original file contained 6 import statements, but candidate contains zero imports. Module imports and file headers were wiped out. Line _, Col _: Header Stripped: Original file contained 6 import statements, but candidate contains zero imports. Module imports and file headers were wiped out.` (Occurrences: 1)
**STATUS:** ACTIVE






































### ❌ [2026-10-25] experiments/analysis-efficiency/compare.mjs `source: mutation-cycle`
**Symptom:** AST / TypeScript Compiler Validation Rejected
**EVIDENCE (Machine-Copied Fact):**
```
Line 219, Col 6: Property declaration is missing its type annotation.
```
**DIAGNOSIS:** Explicit type annotation omitted from property or variable binding in experiments/analysis-efficiency/compare.mjs.
**CONSTRAINT (Model Generalization):** Always specify explicit TypeScript type annotations on property declarations and exported bindings in experiments/analysis-efficiency/compare.mjs.
**FINGERPRINT:** `experiments/analysis-efficiency/compare.mjs::Line _, Col _: Property declaration is missing its type annotation.` (Occurrences: 1)
**STATUS:** ACTIVE





































### ❌ [2026-10-25] experiments/analysis-efficiency/frida-status-queries.mjs `source: mutation-cycle`
**Symptom:** AST / TypeScript Compiler Validation Rejected
**EVIDENCE (Machine-Copied Fact):**
```
Line 55, Col 9: Property declaration is missing its type annotation.
Line 116, Col 1: Cannot use reserved TypeScript keyword as a variable identifier.
```
**DIAGNOSIS:** Explicit type annotation omitted from property or variable binding in experiments/analysis-efficiency/frida-status-queries.mjs.
**CONSTRAINT (Model Generalization):** Always specify explicit TypeScript type annotations on property declarations and exported bindings in experiments/analysis-efficiency/frida-status-queries.mjs.
**FINGERPRINT:** `experiments/analysis-efficiency/frida-status-queries.mjs::Line _, Col _: Property declaration is missing its type annotation. Line _, Col _: Cannot use reserved TypeScript keyword as a variable identifier.` (Occurrences: 1)
**STATUS:** ACTIVE




































### ❌ [2026-10-25] experiments/analysis-efficiency/javascript-facts-agent.mjs `source: mutation-cycle`
**Symptom:** AST / TypeScript Compiler Validation Rejected
**EVIDENCE (Machine-Copied Fact):**
```
Line 104, Col 23: Property declaration is missing its type annotation.
Line 277, Col 11: Property declaration is missing its type annotation.
Line 319, Col 7: Property declaration is missing its type annotation.
Line 325, Col 19: Property declaration is missing its type annotation.
Line 327, Col 16: Property declaration is missing its type annotation.
Line 331, Col 15: Property declaration is missing its type annotation.
Line 335, Col 10: Property declaration is missing its type annotation.
Line 337, Col 19: Property declaration is missing its type annotation.
Line 343, Col 17: Property declaration is missing its type annotation.
Line 347, Col 17: Property declaration is missing its type annotation.
```
**DIAGNOSIS:** Explicit type annotation omitted from property or variable binding in experiments/analysis-efficiency/javascript-facts-agent.mjs.
**CONSTRAINT (Model Generalization):** Always specify explicit TypeScript type annotations on property declarations and exported bindings in experiments/analysis-efficiency/javascript-facts-agent.mjs.
**FINGERPRINT:** `experiments/analysis-efficiency/javascript-facts-agent.mjs::Line _, Col _: Property declaration is missing its type annotation. Line _, Col _: Property declaration is missing its type annotation. Line _, Col _: Property declaration is missing its type annotation. Line _, Col _: Property declaration is missing its type annotation. Line _, Col _: Property declaration is missing its type annotation. Line _, Col _: Property declaration is missing its type annotation. Line _, Col _: Property declaration is missing its type annotation. Line _, Col _: Property declaration is missing its type annotation. Line _, Col _: Property declaration is missing its type annotation. Line _, Col _: Property declaration is missing its type annotation.` (Occurrences: 1)
**STATUS:** ACTIVE



































### ❌ [2026-10-25] experiments/analysis-efficiency/joplin-shell-boundary.mjs `source: mutation-cycle`
**Symptom:** AST / TypeScript Compiler Validation Rejected
**EVIDENCE (Machine-Copied Fact):**
```
Line 301, Col 16: Property declaration is missing its type annotation.
```
**DIAGNOSIS:** Explicit type annotation omitted from property or variable binding in experiments/analysis-efficiency/joplin-shell-boundary.mjs.
**CONSTRAINT (Model Generalization):** Always specify explicit TypeScript type annotations on property declarations and exported bindings in experiments/analysis-efficiency/joplin-shell-boundary.mjs.
**FINGERPRINT:** `experiments/analysis-efficiency/joplin-shell-boundary.mjs::Line _, Col _: Property declaration is missing its type annotation.` (Occurrences: 1)
**STATUS:** ACTIVE


































### ❌ [2026-10-25] experiments/analysis-efficiency/packet-entry.mjs `source: mutation-cycle`
**Symptom:** AST / TypeScript Compiler Validation Rejected
**EVIDENCE (Machine-Copied Fact):**
```
Line 84, Col 15: Property declaration is missing its type annotation.
Line 121, Col 17: Property declaration is missing its type annotation.
```
**DIAGNOSIS:** Explicit type annotation omitted from property or variable binding in experiments/analysis-efficiency/packet-entry.mjs.
**CONSTRAINT (Model Generalization):** Always specify explicit TypeScript type annotations on property declarations and exported bindings in experiments/analysis-efficiency/packet-entry.mjs.
**FINGERPRINT:** `experiments/analysis-efficiency/packet-entry.mjs::Line _, Col _: Property declaration is missing its type annotation. Line _, Col _: Property declaration is missing its type annotation.` (Occurrences: 1)
**STATUS:** ACTIVE

































### ❌ [2026-10-25] experiments/analysis-efficiency/probe-analyzers.mjs `source: mutation-cycle`
**Symptom:** AST / TypeScript Compiler Validation Rejected
**EVIDENCE (Machine-Copied Fact):**
```
Line 108, Col 7: Property declaration is missing its type annotation.
```
**DIAGNOSIS:** Explicit type annotation omitted from property or variable binding in experiments/analysis-efficiency/probe-analyzers.mjs.
**CONSTRAINT (Model Generalization):** Always specify explicit TypeScript type annotations on property declarations and exported bindings in experiments/analysis-efficiency/probe-analyzers.mjs.
**FINGERPRINT:** `experiments/analysis-efficiency/probe-analyzers.mjs::Line _, Col _: Property declaration is missing its type annotation.` (Occurrences: 1)
**STATUS:** ACTIVE
































### ❌ [2026-10-25] experiments/analysis-efficiency/review-packet.mjs `source: mutation-cycle`
**Symptom:** AST / TypeScript Compiler Validation Rejected
**EVIDENCE (Machine-Copied Fact):**
```
Line 229, Col 6: Property declaration is missing its type annotation.
Line 231, Col 21: Property declaration is missing its type annotation.
Line 239, Col 17: Property declaration is missing its type annotation.
```
**DIAGNOSIS:** Explicit type annotation omitted from property or variable binding in experiments/analysis-efficiency/review-packet.mjs.
**CONSTRAINT (Model Generalization):** Always specify explicit TypeScript type annotations on property declarations and exported bindings in experiments/analysis-efficiency/review-packet.mjs.
**FINGERPRINT:** `experiments/analysis-efficiency/review-packet.mjs::Line _, Col _: Property declaration is missing its type annotation. Line _, Col _: Property declaration is missing its type annotation. Line _, Col _: Property declaration is missing its type annotation.` (Occurrences: 1)
**STATUS:** ACTIVE































### ❌ [2026-10-25] experiments/analysis-efficiency/review-saz.mjs `source: mutation-cycle`
**Symptom:** AST / TypeScript Compiler Validation Rejected
**EVIDENCE (Machine-Copied Fact):**
```
Line 249, Col 21: Property declaration is missing its type annotation.
Line 257, Col 6: Property declaration is missing its type annotation.
```
**DIAGNOSIS:** Explicit type annotation omitted from property or variable binding in experiments/analysis-efficiency/review-saz.mjs.
**CONSTRAINT (Model Generalization):** Always specify explicit TypeScript type annotations on property declarations and exported bindings in experiments/analysis-efficiency/review-saz.mjs.
**FINGERPRINT:** `experiments/analysis-efficiency/review-saz.mjs::Line _, Col _: Property declaration is missing its type annotation. Line _, Col _: Property declaration is missing its type annotation.` (Occurrences: 1)
**STATUS:** ACTIVE






























### ❌ [2026-10-25] experiments/analysis-efficiency/review-signal.mjs `source: mutation-cycle`
**Symptom:** AST / TypeScript Compiler Validation Rejected
**EVIDENCE (Machine-Copied Fact):**
```
Line 220, Col 21: Property declaration is missing its type annotation.
Line 228, Col 6: Property declaration is missing its type annotation.
```
**DIAGNOSIS:** Explicit type annotation omitted from property or variable binding in experiments/analysis-efficiency/review-signal.mjs.
**CONSTRAINT (Model Generalization):** Always specify explicit TypeScript type annotations on property declarations and exported bindings in experiments/analysis-efficiency/review-signal.mjs.
**FINGERPRINT:** `experiments/analysis-efficiency/review-signal.mjs::Line _, Col _: Property declaration is missing its type annotation. Line _, Col _: Property declaration is missing its type annotation.` (Occurrences: 1)
**STATUS:** ACTIVE





























### ❌ [2026-10-25] experiments/analysis-efficiency/saz-entry.mjs `source: mutation-cycle`
**Symptom:** AST / TypeScript Compiler Validation Rejected
**EVIDENCE (Machine-Copied Fact):**
```
Line 49, Col 16: Property declaration is missing its type annotation.
Line 135, Col 8: Property declaration is missing its type annotation.
Line 139, Col 9: Property declaration is missing its type annotation.
```
**DIAGNOSIS:** Explicit type annotation omitted from property or variable binding in experiments/analysis-efficiency/saz-entry.mjs.
**CONSTRAINT (Model Generalization):** Always specify explicit TypeScript type annotations on property declarations and exported bindings in experiments/analysis-efficiency/saz-entry.mjs.
**FINGERPRINT:** `experiments/analysis-efficiency/saz-entry.mjs::Line _, Col _: Property declaration is missing its type annotation. Line _, Col _: Property declaration is missing its type annotation. Line _, Col _: Property declaration is missing its type annotation.` (Occurrences: 1)
**STATUS:** ACTIVE




























### ❌ [2026-10-25] experiments/analysis-efficiency/source-to-bundle.mjs `source: mutation-cycle`
**Symptom:** AST / TypeScript Compiler Validation Rejected
**EVIDENCE (Machine-Copied Fact):**
```
Line 106, Col 10: Property declaration is missing its type annotation.
```
**DIAGNOSIS:** Explicit type annotation omitted from property or variable binding in experiments/analysis-efficiency/source-to-bundle.mjs.
**CONSTRAINT (Model Generalization):** Always specify explicit TypeScript type annotations on property declarations and exported bindings in experiments/analysis-efficiency/source-to-bundle.mjs.
**FINGERPRINT:** `experiments/analysis-efficiency/source-to-bundle.mjs::Line _, Col _: Property declaration is missing its type annotation.` (Occurrences: 1)
**STATUS:** ACTIVE



























### ❌ [2026-10-25] experiments/analysis-efficiency/verify-evm-lifecycle.mjs `source: mutation-cycle`
**Symptom:** AST / TypeScript Compiler Validation Rejected
**EVIDENCE (Machine-Copied Fact):**
```
Line 491, Col 6: Property declaration is missing its type annotation.
```
**DIAGNOSIS:** Explicit type annotation omitted from property or variable binding in experiments/analysis-efficiency/verify-evm-lifecycle.mjs.
**CONSTRAINT (Model Generalization):** Always specify explicit TypeScript type annotations on property declarations and exported bindings in experiments/analysis-efficiency/verify-evm-lifecycle.mjs.
**FINGERPRINT:** `experiments/analysis-efficiency/verify-evm-lifecycle.mjs::Line _, Col _: Property declaration is missing its type annotation.` (Occurrences: 1)
**STATUS:** ACTIVE


























### ❌ [2026-10-25] experiments/analysis-efficiency/verify-evm-retention.mjs `source: mutation-cycle`
**Symptom:** AST / TypeScript Compiler Validation Rejected
**EVIDENCE (Machine-Copied Fact):**
```
Line 159, Col 6: Property declaration is missing its type annotation.
```
**DIAGNOSIS:** Explicit type annotation omitted from property or variable binding in experiments/analysis-efficiency/verify-evm-retention.mjs.
**CONSTRAINT (Model Generalization):** Always specify explicit TypeScript type annotations on property declarations and exported bindings in experiments/analysis-efficiency/verify-evm-retention.mjs.
**FINGERPRINT:** `experiments/analysis-efficiency/verify-evm-retention.mjs::Line _, Col _: Property declaration is missing its type annotation.` (Occurrences: 1)
**STATUS:** ACTIVE

























### ❌ [2026-10-25] experiments/analysis-efficiency/verify-evm-template.mjs `source: mutation-cycle`
**Symptom:** AST / TypeScript Compiler Validation Rejected
**EVIDENCE (Machine-Copied Fact):**
```
Line 81, Col 6: Property declaration is missing its type annotation.
```
**DIAGNOSIS:** Explicit type annotation omitted from property or variable binding in experiments/analysis-efficiency/verify-evm-template.mjs.
**CONSTRAINT (Model Generalization):** Always specify explicit TypeScript type annotations on property declarations and exported bindings in experiments/analysis-efficiency/verify-evm-template.mjs.
**FINGERPRINT:** `experiments/analysis-efficiency/verify-evm-template.mjs::Line _, Col _: Property declaration is missing its type annotation.` (Occurrences: 1)
**STATUS:** ACTIVE
























### ❌ [2026-10-25] experiments/analysis-efficiency/verify-migration.mjs `source: mutation-cycle`
**Symptom:** AST / TypeScript Compiler Validation Rejected
**EVIDENCE (Machine-Copied Fact):**
```
Line 66, Col 10: Property declaration is missing its type annotation.
Line 153, Col 6: Property declaration is missing its type annotation.
```
**DIAGNOSIS:** Explicit type annotation omitted from property or variable binding in experiments/analysis-efficiency/verify-migration.mjs.
**CONSTRAINT (Model Generalization):** Always specify explicit TypeScript type annotations on property declarations and exported bindings in experiments/analysis-efficiency/verify-migration.mjs.
**FINGERPRINT:** `experiments/analysis-efficiency/verify-migration.mjs::Line _, Col _: Property declaration is missing its type annotation. Line _, Col _: Property declaration is missing its type annotation.` (Occurrences: 1)
**STATUS:** ACTIVE























### ❌ [2026-10-25] experiments/analysis-efficiency/verify-preset-lifecycle.mjs `source: mutation-cycle`
**Symptom:** AST / TypeScript Compiler Validation Rejected
**EVIDENCE (Machine-Copied Fact):**
```
Line 256, Col 30: Property declaration is missing its type annotation.
Line 388, Col 6: Property declaration is missing its type annotation.
```
**DIAGNOSIS:** Explicit type annotation omitted from property or variable binding in experiments/analysis-efficiency/verify-preset-lifecycle.mjs.
**CONSTRAINT (Model Generalization):** Always specify explicit TypeScript type annotations on property declarations and exported bindings in experiments/analysis-efficiency/verify-preset-lifecycle.mjs.
**FINGERPRINT:** `experiments/analysis-efficiency/verify-preset-lifecycle.mjs::Line _, Col _: Property declaration is missing its type annotation. Line _, Col _: Property declaration is missing its type annotation.` (Occurrences: 1)
**STATUS:** ACTIVE






















### ❌ [2026-10-25] experiments/analysis-efficiency/verify-preset-snapshot.mjs `source: mutation-cycle`
**Symptom:** AST / TypeScript Compiler Validation Rejected
**EVIDENCE (Machine-Copied Fact):**
```
Line 375, Col 6: Property declaration is missing its type annotation.
```
**DIAGNOSIS:** Explicit type annotation omitted from property or variable binding in experiments/analysis-efficiency/verify-preset-snapshot.mjs.
**CONSTRAINT (Model Generalization):** Always specify explicit TypeScript type annotations on property declarations and exported bindings in experiments/analysis-efficiency/verify-preset-snapshot.mjs.
**FINGERPRINT:** `experiments/analysis-efficiency/verify-preset-snapshot.mjs::Line _, Col _: Property declaration is missing its type annotation.` (Occurrences: 1)
**STATUS:** ACTIVE





















### ❌ [2026-10-25] experiments/analysis-efficiency/wasm-string-framing.mjs `source: mutation-cycle`
**Symptom:** AST / TypeScript Compiler Validation Rejected
**EVIDENCE (Machine-Copied Fact):**
```
Line 32, Col 1: Cannot use reserved TypeScript keyword as a variable identifier.
```
**DIAGNOSIS:** <Specific generation mechanism that caused failure — name the technical mechanism, not the symptom>
**CONSTRAINT (Model Generalization):** <One imperative, testable instruction that future prompts must follow to avoid this specific error>
**FINGERPRINT:** `experiments/analysis-efficiency/wasm-string-framing.mjs::Line _, Col _: Cannot use reserved TypeScript keyword as a variable identifier.` (Occurrences: 1)
**STATUS:** ACTIVE




















### ❌ [2026-10-25] experiments/analysis-efficiency/window-option-scaling.mjs `source: mutation-cycle`
**Symptom:** AST / TypeScript Compiler Validation Rejected
**EVIDENCE (Machine-Copied Fact):**
```
Line 65, Col 11: Property declaration is missing its type annotation.
```
**DIAGNOSIS:** Explicit type annotation omitted from property or variable binding in experiments/analysis-efficiency/window-option-scaling.mjs.
**CONSTRAINT (Model Generalization):** Always specify explicit TypeScript type annotations on property declarations and exported bindings in experiments/analysis-efficiency/window-option-scaling.mjs.
**FINGERPRINT:** `experiments/analysis-efficiency/window-option-scaling.mjs::Line _, Col _: Property declaration is missing its type annotation.` (Occurrences: 1)
**STATUS:** ACTIVE



















### ❌ [2026-10-25] native/windows/src/authority.hpp `source: mutation-cycle`
**Symptom:** AST / TypeScript Compiler Validation Rejected
**EVIDENCE (Machine-Copied Fact):**
```
Line 30, Col 42: Unclosed single-quote string literal.
Line 31, Col 51: Unclosed single-quote string literal.
Line 33, Col 1: Mismatched closing delimiter: expected matching ')' but found '}' (opened on Line 31).
Line 268, Col 1: Mismatched closing delimiter: expected matching ')' but found '}' (opened on Line 30).
Line 28, Col 6: Unclosed opening delimiter '('.
Line 27, Col 64: Unclosed opening delimiter '{'.
Line 23, Col 15: Unclosed opening delimiter '{'.
```
**DIAGNOSIS:** Compiler/linter verification failure on native/windows/src/authority.hpp: Line 30, Col 42: Unclosed single-quote string literal.
**CONSTRAINT (Model Generalization):** When mutating native/windows/src/authority.hpp, strictly satisfy AST parser constraints for rule: Line 30, Col 42: Unclosed single-quote string literal.
**FINGERPRINT:** `native/windows/src/authority.hpp::EOF_TRUNCATION` (Occurrences: 1)
**STATUS:** ACTIVE


















### ❌ [2026-10-25] scripts/ci/job-timings.mjs `source: mutation-cycle`
**Symptom:** AST / TypeScript Compiler Validation Rejected
**EVIDENCE (Machine-Copied Fact):**
```
Line 147, Col 9: Property declaration is missing its type annotation.
Line 169, Col 6: Property declaration is missing its type annotation.
Line 175, Col 6: Property declaration is missing its type annotation.
Line 180, Col 23: Property declaration is missing its type annotation.
```
**DIAGNOSIS:** Explicit type annotation omitted from property or variable binding in scripts/ci/job-timings.mjs.
**CONSTRAINT (Model Generalization):** Always specify explicit TypeScript type annotations on property declarations and exported bindings in scripts/ci/job-timings.mjs.
**FINGERPRINT:** `scripts/ci/job-timings.mjs::Line _, Col _: Property declaration is missing its type annotation. Line _, Col _: Property declaration is missing its type annotation. Line _, Col _: Property declaration is missing its type annotation. Line _, Col _: Property declaration is missing its type annotation.` (Occurrences: 1)
**STATUS:** ACTIVE

















### ❌ [2026-10-25] scripts/ci/pr-ci-health.mjs `source: mutation-cycle`
**Symptom:** AST / TypeScript Compiler Validation Rejected
**EVIDENCE (Machine-Copied Fact):**
```
Line 57, Col 7: Property declaration is missing its type annotation.
Line 384, Col 11: Property declaration is missing its type annotation.
Line 387, Col 4: Property declaration is missing its type annotation.
Line 553, Col 10: Property declaration is missing its type annotation.
Line 560, Col 8: Property declaration is missing its type annotation.
Line 563, Col 8: Property declaration is missing its type annotation.
```
**DIAGNOSIS:** Explicit type annotation omitted from property or variable binding in scripts/ci/pr-ci-health.mjs.
**CONSTRAINT (Model Generalization):** Always specify explicit TypeScript type annotations on property declarations and exported bindings in scripts/ci/pr-ci-health.mjs.
**FINGERPRINT:** `scripts/ci/pr-ci-health.mjs::Line _, Col _: Property declaration is missing its type annotation. Line _, Col _: Property declaration is missing its type annotation. Line _, Col _: Property declaration is missing its type annotation. Line _, Col _: Property declaration is missing its type annotation. Line _, Col _: Property declaration is missing its type annotation. Line _, Col _: Property declaration is missing its type annotation.` (Occurrences: 1)
**STATUS:** ACTIVE
















### ❌ [2026-10-25] scripts/ci/test-report.mjs `source: mutation-cycle`
**Symptom:** AST / TypeScript Compiler Validation Rejected
**EVIDENCE (Machine-Copied Fact):**
```
Line 79, Col 9: Property declaration is missing its type annotation.
```
**DIAGNOSIS:** Explicit type annotation omitted from property or variable binding in scripts/ci/test-report.mjs.
**CONSTRAINT (Model Generalization):** Always specify explicit TypeScript type annotations on property declarations and exported bindings in scripts/ci/test-report.mjs.
**FINGERPRINT:** `scripts/ci/test-report.mjs::Line _, Col _: Property declaration is missing its type annotation.` (Occurrences: 1)
**STATUS:** ACTIVE















### ❌ [2026-10-25] scripts/ci/test-selection.mjs `source: mutation-cycle`
**Symptom:** AST / TypeScript Compiler Validation Rejected
**EVIDENCE (Machine-Copied Fact):**
```
Line 60, Col 7: Property declaration is missing its type annotation.
Line 141, Col 9: Property declaration is missing its type annotation.
```
**DIAGNOSIS:** Explicit type annotation omitted from property or variable binding in scripts/ci/test-selection.mjs.
**CONSTRAINT (Model Generalization):** Always specify explicit TypeScript type annotations on property declarations and exported bindings in scripts/ci/test-selection.mjs.
**FINGERPRINT:** `scripts/ci/test-selection.mjs::Line _, Col _: Property declaration is missing its type annotation. Line _, Col _: Property declaration is missing its type annotation.` (Occurrences: 1)
**STATUS:** ACTIVE














### ❌ [2026-10-25] scripts/electron-active-hook.cjs `source: mutation-cycle`
**Symptom:** AST / TypeScript Compiler Validation Rejected
**EVIDENCE (Machine-Copied Fact):**
```
Line 115, Col 15: Property declaration is missing its type annotation.
Line 155, Col 13: Property declaration is missing its type annotation.
Line 157, Col 13: Property declaration is missing its type annotation.
Line 159, Col 14: Property declaration is missing its type annotation.
Line 161, Col 16: Property declaration is missing its type annotation.
Line 758, Col 15: Property declaration is missing its type annotation.
```
**DIAGNOSIS:** Explicit type annotation omitted from property or variable binding in scripts/electron-active-hook.cjs.
**CONSTRAINT (Model Generalization):** Always specify explicit TypeScript type annotations on property declarations and exported bindings in scripts/electron-active-hook.cjs.
**FINGERPRINT:** `scripts/electron-active-hook.cjs::Line _, Col _: Property declaration is missing its type annotation. Line _, Col _: Property declaration is missing its type annotation. Line _, Col _: Property declaration is missing its type annotation. Line _, Col _: Property declaration is missing its type annotation. Line _, Col _: Property declaration is missing its type annotation. Line _, Col _: Property declaration is missing its type annotation.` (Occurrences: 1)
**STATUS:** ACTIVE













### ❌ [2026-10-25] scripts/generate-skill-metadata.mjs `source: mutation-cycle`
**Symptom:** AST / TypeScript Compiler Validation Rejected
**EVIDENCE (Machine-Copied Fact):**
```
Line 50, Col 7: Property declaration is missing its type annotation.
```
**DIAGNOSIS:** Explicit type annotation omitted from property or variable binding in scripts/generate-skill-metadata.mjs.
**CONSTRAINT (Model Generalization):** Always specify explicit TypeScript type annotations on property declarations and exported bindings in scripts/generate-skill-metadata.mjs.
**FINGERPRINT:** `scripts/generate-skill-metadata.mjs::Line _, Col _: Property declaration is missing its type annotation.` (Occurrences: 1)
**STATUS:** ACTIVE












### ❌ [2026-10-25] scripts/lib/browser-scenario-environment-e2e.mjs `source: mutation-cycle`
**Symptom:** AST / TypeScript Compiler Validation Rejected
**EVIDENCE (Machine-Copied Fact):**
```
Line 63, Col 8: Property declaration is missing its type annotation.
```
**DIAGNOSIS:** Explicit type annotation omitted from property or variable binding in scripts/lib/browser-scenario-environment-e2e.mjs.
**CONSTRAINT (Model Generalization):** Always specify explicit TypeScript type annotations on property declarations and exported bindings in scripts/lib/browser-scenario-environment-e2e.mjs.
**FINGERPRINT:** `scripts/lib/browser-scenario-environment-e2e.mjs::Line _, Col _: Property declaration is missing its type annotation.` (Occurrences: 1)
**STATUS:** ACTIVE











### ❌ [2026-10-25] scripts/lib/browser-scenario-storage-e2e.mjs `source: mutation-cycle`
**Symptom:** AST / TypeScript Compiler Validation Rejected
**EVIDENCE (Machine-Copied Fact):**
```
Line 478, Col 7: Property declaration is missing its type annotation.
Line 628, Col 11: Property declaration is missing its type annotation.
```
**DIAGNOSIS:** Explicit type annotation omitted from property or variable binding in scripts/lib/browser-scenario-storage-e2e.mjs.
**CONSTRAINT (Model Generalization):** Always specify explicit TypeScript type annotations on property declarations and exported bindings in scripts/lib/browser-scenario-storage-e2e.mjs.
**FINGERPRINT:** `scripts/lib/browser-scenario-storage-e2e.mjs::Line _, Col _: Property declaration is missing its type annotation. Line _, Col _: Property declaration is missing its type annotation.` (Occurrences: 1)
**STATUS:** ACTIVE










### ❌ [2026-10-25] scripts/lib/catalog-builders.mjs `source: mutation-cycle`
**Symptom:** AST / TypeScript Compiler Validation Rejected
**EVIDENCE (Machine-Copied Fact):**
```
Line 117, Col 10: Property declaration is missing its type annotation.
Line 189, Col 10: Property declaration is missing its type annotation.
Line 196, Col 10: Property declaration is missing its type annotation.
Line 244, Col 10: Property declaration is missing its type annotation.
Line 253, Col 10: Property declaration is missing its type annotation.
Line 260, Col 10: Property declaration is missing its type annotation.
Line 267, Col 10: Property declaration is missing its type annotation.
Line 274, Col 10: Property declaration is missing its type annotation.
Line 281, Col 10: Property declaration is missing its type annotation.
Line 288, Col 10: Property declaration is missing its type annotation.
Line 295, Col 10: Property declaration is missing its type annotation.
Line 302, Col 10: Property declaration is missing its type annotation.
Line 309, Col 10: Property declaration is missing its type annotation.
Line 316, Col 10: Property declaration is missing its type annotation.
Line 392, Col 10: Property declaration is missing its type annotation.
Line 433, Col 10: Property declaration is missing its type annotation.
Line 438, Col 10: Property declaration is missing its type annotation.
Line 442, Col 9: Property declaration is missing its type annotation.
Line 444, Col 10: Property declaration is missing its type annotation.
Line 455, Col 9: Property declaration is missing its type annotation.
Line 457, Col 10: Property declaration is missing its type annotation.
Line 465, Col 9: Property declaration is missing its type annotation.
Line 471, Col 10: Property declaration is missing its type annotation.
Line 480, Col 9: Property declaration is missing its type annotation.
Line 485, Col 9: Property declaration is missing its type annotation.
Line 515, Col 10: Property declaration is missing its type annotation.
```
**DIAGNOSIS:** Explicit type annotation omitted from property or variable binding in scripts/lib/catalog-builders.mjs.
**CONSTRAINT (Model Generalization):** Always specify explicit TypeScript type annotations on property declarations and exported bindings in scripts/lib/catalog-builders.mjs.
**FINGERPRINT:** `scripts/lib/catalog-builders.mjs::Line _, Col _: Property declaration is missing its type annotation. Line _, Col _: Property declaration is missing its type annotation. Line _, Col _: Property declaration is missing its type annotation. Line _, Col _: Property declaration is missing its type annotation. Line _, Col _: Property declaration is missing its type annotation. Line _, Col _: Property declaration is missing its type annotation. Line _, Col _: Property declaration is missing its type annotation. Line _, Col _: Property declaration is missing its type annotation. Line _, Col _: Property declaration is missing its type annotation. Line _, Col _: Property declaration is missing its type annotation. Line _, Col _: Property declaration is missing its type annotation. Line _, Col _: Property declaration is missing its type annotation. Line _, Col _: Property declaration is missing its type annotation. Line _, Col _: Property declaration is missing its type annotation. Line _, Col _: Property declaration is missing its type annotation. Line _, Col _: Property declaration is missing its type annotation. Line _, Col _: Property declaration is missing its type annotation. Line _, Col _: Property declaration is missing its type annotation. Line _, Col _: Property declaration is missing its type annotation. Line _, Col _: Property declaration is missing its type annotation. Line _, Col _: Property declaration is missing its type annotation. Line _, Col _: Property declaration is missing its type annotation. Line _, Col _: Property declaration is missing its type annotation. Line _, Col _: Property declaration is missing its type annotation. Line _, Col _: Property declaration is missing its type annotation. Line _, Col _: Property declaration is missing its type annotation.` (Occurrences: 1)
**STATUS:** ACTIVE









### ❌ [2026-10-25] scripts/lib/real-ghidra-instruction-flow.mjs `source: mutation-cycle`
**Symptom:** AST / TypeScript Compiler Validation Rejected
**EVIDENCE (Machine-Copied Fact):**
```
Line 74, Col 23: Property declaration is missing its type annotation.
```
**DIAGNOSIS:** Explicit type annotation omitted from property or variable binding in scripts/lib/real-ghidra-instruction-flow.mjs.
**CONSTRAINT (Model Generalization):** Always specify explicit TypeScript type annotations on property declarations and exported bindings in scripts/lib/real-ghidra-instruction-flow.mjs.
**FINGERPRINT:** `scripts/lib/real-ghidra-instruction-flow.mjs::Line _, Col _: Property declaration is missing its type annotation.` (Occurrences: 1)
**STATUS:** ACTIVE








### ❌ [2026-10-25] scripts/lib/real-ghidra-snapshot-lifecycle.mjs `source: mutation-cycle`
**Symptom:** AST / TypeScript Compiler Validation Rejected
**EVIDENCE (Machine-Copied Fact):**
```
Line 166, Col 8: Property declaration is missing its type annotation.
```
**DIAGNOSIS:** Explicit type annotation omitted from property or variable binding in scripts/lib/real-ghidra-snapshot-lifecycle.mjs.
**CONSTRAINT (Model Generalization):** Always specify explicit TypeScript type annotations on property declarations and exported bindings in scripts/lib/real-ghidra-snapshot-lifecycle.mjs.
**FINGERPRINT:** `scripts/lib/real-ghidra-snapshot-lifecycle.mjs::Line _, Col _: Property declaration is missing its type annotation.` (Occurrences: 1)
**STATUS:** ACTIVE







### ❌ [2026-10-25] scripts/lib/release-checkpoint.mjs `source: mutation-cycle`
**Symptom:** AST / TypeScript Compiler Validation Rejected
**EVIDENCE (Machine-Copied Fact):**
```
Line 67, Col 1: Cannot use reserved TypeScript keyword as a variable identifier.
Line 73, Col 9: Property declaration is missing its type annotation.
```
**DIAGNOSIS:** Explicit type annotation omitted from property or variable binding in scripts/lib/release-checkpoint.mjs.
**CONSTRAINT (Model Generalization):** Always specify explicit TypeScript type annotations on property declarations and exported bindings in scripts/lib/release-checkpoint.mjs.
**FINGERPRINT:** `scripts/lib/release-checkpoint.mjs::Line _, Col _: Cannot use reserved TypeScript keyword as a variable identifier. Line _, Col _: Property declaration is missing its type annotation.` (Occurrences: 1)
**STATUS:** ACTIVE






### ❌ [2026-10-25] scripts/lib/verify-package-commands.mjs `source: mutation-cycle`
**Symptom:** AST / TypeScript Compiler Validation Rejected
**EVIDENCE (Machine-Copied Fact):**
```
Line 9, Col 1: Cannot use reserved TypeScript keyword as a variable identifier.
```
**DIAGNOSIS:** <Specific generation mechanism that caused failure — name the technical mechanism, not the symptom>
**CONSTRAINT (Model Generalization):** <One imperative, testable instruction that future prompts must follow to avoid this specific error>
**FINGERPRINT:** `scripts/lib/verify-package-commands.mjs::Line _, Col _: Cannot use reserved TypeScript keyword as a variable identifier.` (Occurrences: 1)
**STATUS:** ACTIVE





### ❌ [2026-10-25] scripts/lint/rules/no-fixture-root-cleanup.mjs `source: mutation-cycle`
**Symptom:** AST / TypeScript Compiler Validation Rejected
**EVIDENCE (Machine-Copied Fact):**
```
Line 42, Col 10: Property declaration is missing its type annotation.
Line 72, Col 7: Property declaration is missing its type annotation.
```
**DIAGNOSIS:** Explicit type annotation omitted from property or variable binding in scripts/lint/rules/no-fixture-root-cleanup.mjs.
**CONSTRAINT (Model Generalization):** Always specify explicit TypeScript type annotations on property declarations and exported bindings in scripts/lint/rules/no-fixture-root-cleanup.mjs.
**FINGERPRINT:** `scripts/lint/rules/no-fixture-root-cleanup.mjs::Line _, Col _: Property declaration is missing its type annotation. Line _, Col _: Property declaration is missing its type annotation.` (Occurrences: 1)
**STATUS:** ACTIVE




### ❌ [2026-10-25] scripts/lint/rules/no-positional-tool-contract.mjs `source: mutation-cycle`
**Symptom:** AST / TypeScript Compiler Validation Rejected
**EVIDENCE (Machine-Copied Fact):**
```
Line 40, Col 12: Property declaration is missing its type annotation.
Line 45, Col 11: Property declaration is missing its type annotation.
```
**DIAGNOSIS:** Explicit type annotation omitted from property or variable binding in scripts/lint/rules/no-positional-tool-contract.mjs.
**CONSTRAINT (Model Generalization):** Always specify explicit TypeScript type annotations on property declarations and exported bindings in scripts/lint/rules/no-positional-tool-contract.mjs.
**FINGERPRINT:** `scripts/lint/rules/no-positional-tool-contract.mjs::Line _, Col _: Property declaration is missing its type annotation. Line _, Col _: Property declaration is missing its type annotation.` (Occurrences: 1)
**STATUS:** ACTIVE



### ❌ [2026-10-25] scripts/lint/rules/no-shared-module-mock.mjs `source: mutation-cycle`
**Symptom:** AST / TypeScript Compiler Validation Rejected
**EVIDENCE (Machine-Copied Fact):**
```
Line 94, Col 12: Property declaration is missing its type annotation.
Line 99, Col 7: Property declaration is missing its type annotation.
```
**DIAGNOSIS:** Explicit type annotation omitted from property or variable binding in scripts/lint/rules/no-shared-module-mock.mjs.
**CONSTRAINT (Model Generalization):** Always specify explicit TypeScript type annotations on property declarations and exported bindings in scripts/lint/rules/no-shared-module-mock.mjs.
**FINGERPRINT:** `scripts/lint/rules/no-shared-module-mock.mjs::Line _, Col _: Property declaration is missing its type annotation. Line _, Col _: Property declaration is missing its type annotation.` (Occurrences: 1)
**STATUS:** ACTIVE


### ❌ [2026-10-25] scripts/test-website.py `source: mutation-cycle`
**Symptom:** AST / TypeScript Compiler Validation Rejected
**EVIDENCE (Machine-Copied Fact):**
```
Line 1, Col 1: [LINT REJECT: NO_UNGROUNDED_QUANTITATIVE_CLAIMS] Detected 2 specific numeric claim(s) with no traceable computation, call, or fetched value nearby: "20%" (percentage), "26%" (percentage). Output must not assert precise statistics (percentages, cycle counts, benchmark scores, confidence scores) unless derived from an actual computation or data source in the same diff.
```
**DIAGNOSIS:** Model asserted specific numeric findings (percentages, cycle counts, benchmark scores) in scripts/test-website.py without a corresponding computation, external call, or data source in the generated diff.
**CONSTRAINT (Model Generalization):** When generating analysis/evaluation output in scripts/test-website.py, do not state precise statistics unless the value is assigned from an actual computed expression, function call, or fetched result in the same output. Stub or placeholder implementations must say so explicitly (e.g. "not yet computed") rather than inventing plausible-sounding numbers.
**FINGERPRINT:** `scripts/test-website.py::Line _, Col _: [LINT REJECT: NO_UNGROUNDED_QUANTITATIVE_CLAIMS] Detected 2 specific numeric claim(s) with no traceable computation, call, or fetched value nearby: "20%" (percentage), "26%" (percentage). Output must not assert precise statistics (percentages, cycle counts, benchmark scores, confidence scores) unless derived from an actual computation or data source in the same diff.` (Occurrences: 1)
**STATUS:** ACTIVE
