# langfuse

> Clean-room architectural extraction of the runtime engine powering [langfuse/langfuse](langfuse/langfuse).
> **License**: MIT (MIT License)

## Quickstart

```bash
# 1. Install dependencies
npm install

# 2. Run automated test suite
npm test

# 3. Build TypeScript to JavaScript
npm run build
```

## Architecture & Components

See [`specification.md`](./specification.md) for full architectural blueprints, dataflow diagrams, and implementation details.
