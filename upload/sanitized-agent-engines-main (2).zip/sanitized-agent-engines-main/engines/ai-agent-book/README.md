/* GLM-Engine-Harvester [2026-10-09T04:30:53.096Z] */
# ai-agent-book

> Clean-room architectural extraction of the runtime engine powering [bojieli/ai-agent-book](https://github.com/bojieli/ai-agent-book).
> **License**: Apache-2.0 (Apache License 2.0)

## Quickstart

```bash
# 1. Install dependencies
npm install

# 2. Run automated test suite
npm test

# 3. Build TypeScript to JavaScript
npm run build
```

## Architecture & Components

See [`specification.md`](./specification.md) for full architectural blueprints, dataflow diagrams, and implementation details.

## Sanitization Notice

All proprietary company branding and vendor-specific identifiers have been sanitized into decoupled clean-room architectural components. This engine is a research-grade clean-room reimplementation, not affiliated with the original project.
