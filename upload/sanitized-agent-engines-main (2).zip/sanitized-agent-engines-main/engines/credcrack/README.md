# CredCrack

> Clean-room architectural extraction of the runtime engine powering [jobroche/CredCrack](jobroche/CredCrack).
> **License**: GPL-3.0 (GNU General Public License v3.0)

## Quickstart

```bash
# 1. Install dependencies
npm install

# 2. Run automated test suite
npm test

# 3. Build TypeScript to JavaScript
npm run build
```

## Architecture & Components

See [`specification.md`](./specification.md) for full architectural blueprints, dataflow diagrams, and implementation details.
