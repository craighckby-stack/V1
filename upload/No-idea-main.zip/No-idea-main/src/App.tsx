/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Sparkles, Code2, Layers } from 'lucide-react';

export default function App() {
  return (
    <div id="app-root" className="min-h-screen bg-neutral-900 text-neutral-100 flex flex-col items-center justify-center p-6 font-sans">
      <div id="welcome-card" className="max-w-md w-full bg-neutral-800/80 border border-neutral-700/60 rounded-2xl p-8 shadow-xl backdrop-blur-sm text-center">
        <div className="inline-flex items-center justify-center w-14 h-14 rounded-xl bg-neutral-700/60 text-amber-400 mb-6 border border-neutral-600/40">
          <Sparkles className="w-7 h-7" />
        </div>
        
        <h1 className="text-2xl font-semibold tracking-tight text-white mb-2">
          Ready to Build
        </h1>
        
        <p className="text-neutral-400 text-sm leading-relaxed mb-6">
          The workspace is initialized and ready. Tell me what you would like to build or customize!
        </p>

        <div className="grid grid-cols-2 gap-3 text-left">
          <div className="p-3.5 rounded-xl bg-neutral-900/60 border border-neutral-700/40">
            <div className="flex items-center gap-2 text-neutral-300 text-xs font-medium mb-1">
              <Code2 className="w-4 h-4 text-emerald-400" />
              <span>Full-Stack</span>
            </div>
            <p className="text-neutral-500 text-xs">React, Vite & Tailwind</p>
          </div>
          
          <div className="p-3.5 rounded-xl bg-neutral-900/60 border border-neutral-700/40">
            <div className="flex items-center gap-2 text-neutral-300 text-xs font-medium mb-1">
              <Layers className="w-4 h-4 text-sky-400" />
              <span>AI Ready</span>
            </div>
            <p className="text-neutral-500 text-xs">Gemini & API support</p>
          </div>
        </div>
      </div>
    </div>
  );
}
