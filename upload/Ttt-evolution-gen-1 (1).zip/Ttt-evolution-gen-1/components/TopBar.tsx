'use client';

import React from 'react';
import { DomainCategory } from '@/lib/types';
import { DOMAIN_CONFIGS } from '@/lib/presetGoals';
import { Sparkles, RefreshCw, Layers, Cpu, Code2, Server, Dna, TrendingUp, Rocket, Gamepad2, Shield } from 'lucide-react';

interface TopBarProps {
  activeTab: 'engine' | 'graph' | 'history' | 'metrics';
  setActiveTab: (tab: 'engine' | 'graph' | 'history' | 'metrics') => void;
  isRunning: boolean;
  generationCount: number;
  onReset: () => void;
  isSimulationMode?: boolean;
  selectedDomain: DomainCategory;
  onSelectDomain: (d: DomainCategory) => void;
}

const DOMAIN_ICONS: Record<DomainCategory, React.ElementType> = {
  'codebase-meta': Code2,
  'software-architecture': Server,
  'biological-ai': Dna,
  'quant-trading': TrendingUp,
  'aerospace-physics': Rocket,
  'game-balancer': Gamepad2,
  'governance-tokenomics': Shield,
};

export const TopBar: React.FC<TopBarProps> = ({
  activeTab,
  setActiveTab,
  isRunning,
  generationCount,
  onReset,
  isSimulationMode,
  selectedDomain,
  onSelectDomain,
}) => {
  const currentConfig = DOMAIN_CONFIGS[selectedDomain] || DOMAIN_CONFIGS['biological-ai'];
  const DomainIcon = DOMAIN_ICONS[selectedDomain] || Sparkles;

  return (
    <header className="sticky top-0 z-40 flex items-center justify-between gap-8 px-6 py-3.5 bg-slate-950/90 backdrop-blur-md border-b border-slate-800/80">
      {/* Zone 1: Wordmark & Domain Dropdown */}
      <div className="flex items-center gap-3 shrink-0">
        <div className="w-8 h-8 rounded-lg bg-teal-500/10 border border-teal-500/30 flex items-center justify-center text-teal-400 shadow-sm shadow-teal-500/10">
          <DomainIcon className="w-4 h-4" />
        </div>

        <div className="flex items-center gap-2">
          <select
            value={selectedDomain}
            onChange={(e) => onSelectDomain(e.target.value as DomainCategory)}
            disabled={isRunning}
            className="bg-slate-900 border border-slate-700/80 rounded-lg px-2.5 py-1 text-xs font-bold text-white tracking-tight cursor-pointer focus:outline-none focus:ring-1 focus:ring-teal-400 disabled:opacity-50"
          >
            {Object.values(DOMAIN_CONFIGS).map((cfg) => (
              <option key={cfg.id} value={cfg.id}>
                {cfg.name}
              </option>
            ))}
          </select>

          {isSimulationMode ? (
            <span className="hidden sm:inline-flex items-center gap-1 text-[10px] font-mono font-medium px-2 py-0.5 rounded bg-indigo-950 text-indigo-300 border border-indigo-500/30">
              <Cpu className="w-3 h-3 text-indigo-400" />
              <span>SIMULATION</span>
            </span>
          ) : (
            <span className="hidden sm:inline-block text-[10px] font-mono font-medium px-2 py-0.5 rounded bg-slate-800 text-teal-400 border border-teal-500/20">
              RECURSIVE
            </span>
          )}
        </div>
      </div>

      {/* Zone 2: Navigation Links */}
      <nav className="hidden md:flex items-center gap-1 bg-slate-900/60 p-1 rounded-lg border border-slate-800">
        <button
          onClick={() => setActiveTab('engine')}
          className={`px-3.5 py-1.5 text-xs font-medium rounded-md transition-all whitespace-nowrap shrink-0 flex items-center gap-1.5 ${
            activeTab === 'engine'
              ? 'bg-slate-800 text-teal-300 shadow-sm border border-teal-500/20'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <Sparkles className="w-3.5 h-3.5" />
          <span>Recursive Engine</span>
        </button>
        <button
          onClick={() => setActiveTab('graph')}
          className={`px-3.5 py-1.5 text-xs font-medium rounded-md transition-all whitespace-nowrap shrink-0 flex items-center gap-1.5 ${
            activeTab === 'graph'
              ? 'bg-slate-800 text-teal-300 shadow-sm border border-teal-500/20'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <Layers className="w-3.5 h-3.5" />
          <span>Topology Graph</span>
        </button>
        <button
          onClick={() => setActiveTab('history')}
          className={`px-3.5 py-1.5 text-xs font-medium rounded-md transition-all whitespace-nowrap shrink-0 flex items-center gap-1.5 ${
            activeTab === 'history'
              ? 'bg-slate-800 text-teal-300 shadow-sm border border-teal-500/20'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <span>Lineage Log</span>
          {generationCount > 0 && (
            <span className="px-1.5 py-0.2 rounded-full text-[10px] font-mono bg-teal-500/20 text-teal-300">
              {generationCount}
            </span>
          )}
        </button>
        <button
          onClick={() => setActiveTab('metrics')}
          className={`px-3.5 py-1.5 text-xs font-medium rounded-md transition-all whitespace-nowrap shrink-0 ${
            activeTab === 'metrics'
              ? 'bg-slate-800 text-teal-300 shadow-sm border border-teal-500/20'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          Invariants & Metrics
        </button>
      </nav>

      {/* Zone 3: Primary Action */}
      <div className="flex items-center gap-3 shrink-0">
        {generationCount > 0 && (
          <button
            onClick={onReset}
            disabled={isRunning}
            className="px-3 py-1.5 text-xs font-medium text-slate-300 hover:text-white bg-slate-900 hover:bg-slate-800 rounded-lg border border-slate-700 transition-colors whitespace-nowrap shrink-0 flex items-center gap-1.5 disabled:opacity-50"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>New Loop</span>
          </button>
        )}
      </div>
    </header>
  );
};
