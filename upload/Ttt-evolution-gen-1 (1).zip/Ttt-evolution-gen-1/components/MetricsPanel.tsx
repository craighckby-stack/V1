'use client';

import React from 'react';
import { KeyMetrics, DomainCategory } from '@/lib/types';
import { DOMAIN_CONFIGS } from '@/lib/presetGoals';
import { Gauge, Activity, Cpu, Layers } from 'lucide-react';

interface MetricsPanelProps {
  metrics: KeyMetrics;
  generation: number;
  domain?: DomainCategory;
}

export const MetricsPanel: React.FC<MetricsPanelProps> = ({
  metrics,
  generation,
  domain = 'biological-ai',
}) => {
  const config = DOMAIN_CONFIGS[domain] || DOMAIN_CONFIGS['biological-ai'];
  const labels = config.metricLabels;

  return (
    <div className="w-full bg-slate-900/80 border border-slate-800 rounded-2xl p-6 backdrop-blur-sm space-y-6">
      <div className="flex items-center justify-between border-b border-slate-800 pb-4">
        <div className="flex items-center gap-2">
          <Gauge className="w-4 h-4 text-teal-400" />
          <h3 className="text-sm font-bold text-white tracking-tight">
            Architectural & Physical Invariants ({config.name})
          </h3>
        </div>
        <span className="text-xs font-mono text-slate-400 bg-slate-950 px-2.5 py-1 rounded-lg border border-slate-800">
          Generation {generation} Model
        </span>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Metric 1: Coherence */}
        <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 flex flex-col justify-between gap-3">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-xs font-semibold uppercase tracking-wider">{labels.m1Title}</span>
            <Gauge className="w-4 h-4 text-teal-400" />
          </div>
          <div>
            <div className="text-2xl font-bold font-mono text-white mb-1">
              {metrics.coherenceScore} <span className="text-xs text-slate-400 font-normal">/ 100</span>
            </div>
            <div className="w-full bg-slate-900 h-1.5 rounded-full overflow-hidden">
              <div
                className="bg-teal-400 h-full rounded-full transition-all duration-500"
                style={{ width: `${Math.min(100, Math.max(0, metrics.coherenceScore))}%` }}
              />
            </div>
          </div>
          <p className="text-[11px] text-slate-400 leading-tight">
            {labels.m1Desc}
          </p>
        </div>

        {/* Metric 2 */}
        <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 flex flex-col justify-between gap-3">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-xs font-semibold uppercase tracking-wider">{labels.m2Title}</span>
            <Layers className="w-4 h-4 text-cyan-400" />
          </div>
          <div>
            <div className="text-lg font-bold font-mono text-cyan-300 truncate mb-1">
              {metrics.metricTwoValue}
            </div>
            <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-cyan-950 text-cyan-400 border border-cyan-800">
              Evaluated
            </span>
          </div>
          <p className="text-[11px] text-slate-400 leading-tight">
            {labels.m2Desc}
          </p>
        </div>

        {/* Metric 3 */}
        <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 flex flex-col justify-between gap-3">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-xs font-semibold uppercase tracking-wider">{labels.m3Title}</span>
            <Cpu className="w-4 h-4 text-indigo-400" />
          </div>
          <div>
            <div className="text-lg font-bold font-mono text-indigo-300 truncate mb-1">
              {metrics.metricThreeValue}
            </div>
            <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-indigo-950 text-indigo-400 border border-indigo-800">
              Measured
            </span>
          </div>
          <p className="text-[11px] text-slate-400 leading-tight">
            {labels.m3Desc}
          </p>
        </div>

        {/* Metric 4 */}
        <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 flex flex-col justify-between gap-3">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-xs font-semibold uppercase tracking-wider">{labels.m4Title}</span>
            <Activity className="w-4 h-4 text-amber-400" />
          </div>
          <div>
            <div className="text-lg font-bold font-mono text-amber-300 truncate mb-1">
              {metrics.metricFourValue}
            </div>
            <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-amber-950 text-amber-400 border border-amber-800">
              Target Margin
            </span>
          </div>
          <p className="text-[11px] text-slate-400 leading-tight">
            {labels.m4Desc}
          </p>
        </div>
      </div>
    </div>
  );
};
