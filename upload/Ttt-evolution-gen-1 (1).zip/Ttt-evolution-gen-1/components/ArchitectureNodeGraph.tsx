'use client';

import React, { useState } from 'react';
import { ArchitectureNode } from '@/lib/types';
import { Cpu, Dna, Activity, Zap, Database, ArrowRight, Info, CheckCircle, Network } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface NodeGraphProps {
  nodes: ArchitectureNode[];
  generation: number;
}

const TYPE_COLORS: Record<string, { bg: string; border: string; text: string; badge: string }> = {
  input: {
    bg: 'bg-cyan-950/60',
    border: 'border-cyan-500/50',
    text: 'text-cyan-300',
    badge: 'bg-cyan-500/20 text-cyan-300 border-cyan-500/30',
  },
  transducer: {
    bg: 'bg-indigo-950/60',
    border: 'border-indigo-500/50',
    text: 'text-indigo-300',
    badge: 'bg-indigo-500/20 text-indigo-300 border-indigo-500/30',
  },
  processor: {
    bg: 'bg-teal-950/60',
    border: 'border-teal-500/50',
    text: 'text-teal-300',
    badge: 'bg-teal-500/20 text-teal-300 border-teal-500/30',
  },
  memory: {
    bg: 'bg-purple-950/60',
    border: 'border-purple-500/50',
    text: 'text-purple-300',
    badge: 'bg-purple-500/20 text-purple-300 border-purple-500/30',
  },
  output: {
    bg: 'bg-emerald-950/60',
    border: 'border-emerald-500/50',
    text: 'text-emerald-300',
    badge: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30',
  },
  feedback: {
    bg: 'bg-amber-950/60',
    border: 'border-amber-500/50',
    text: 'text-amber-300',
    badge: 'bg-amber-500/20 text-amber-300 border-amber-500/30',
  },
};

const TYPE_ICONS: Record<string, React.ElementType> = {
  input: Zap,
  transducer: Activity,
  processor: Cpu,
  memory: Database,
  output: ArrowRight,
  feedback: Dna,
};

export const ArchitectureNodeGraph: React.FC<NodeGraphProps> = ({ nodes, generation }) => {
  const [selectedNodeId, setSelectedNodeId] = useState<string | null>(nodes[0]?.id || null);

  if (!nodes || nodes.length === 0) {
    return (
      <div className="p-8 text-center bg-slate-900/50 border border-slate-800 rounded-xl text-slate-400 text-xs font-mono">
        No graph nodes mapped for Generation {generation}.
      </div>
    );
  }

  const selectedNode = nodes.find((n) => n.id === selectedNodeId) || nodes[0];

  return (
    <div className="w-full bg-slate-900/90 border border-slate-800 rounded-2xl overflow-hidden">
      {/* Header */}
      <div className="px-6 py-4 bg-slate-950/80 border-b border-slate-800 flex items-center justify-between gap-4">
        <div className="flex items-center gap-2">
          <Network className="w-4 h-4 text-teal-400" />
          <h3 className="text-sm font-bold text-white tracking-tight">
            Bio-Computing Network Topology
          </h3>
          <span className="text-[11px] font-mono text-teal-300 bg-teal-500/10 px-2 py-0.5 rounded border border-teal-500/20">
            {nodes.length} Active Primitives
          </span>
        </div>
        <span className="text-xs text-slate-400 font-mono">Gen {generation} Architecture</span>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-0 divide-y lg:divide-y-0 lg:divide-x divide-slate-800">
        {/* Node Grid View */}
        <div className="lg:col-span-2 p-6 bg-slate-950/40 min-h-[380px] flex flex-col justify-between">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {nodes.map((node) => {
              const isSelected = selectedNode?.id === node.id;
              const typeStyle = TYPE_COLORS[node.type] || TYPE_COLORS.processor;
              const IconComponent = TYPE_ICONS[node.type] || Cpu;

              return (
                <button
                  key={node.id}
                  onClick={() => setSelectedNodeId(node.id)}
                  className={`p-4 rounded-xl border text-left transition-all relative overflow-hidden flex flex-col justify-between gap-3 ${
                    typeStyle.bg
                  } ${typeStyle.border} ${
                    isSelected
                      ? 'ring-2 ring-teal-400/60 shadow-lg shadow-teal-950/30 scale-[1.01]'
                      : 'hover:border-slate-600 hover:bg-slate-900/60'
                  }`}
                >
                  <div className="flex items-center justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <div className={`p-1.5 rounded-lg border ${typeStyle.badge}`}>
                        <IconComponent className="w-3.5 h-3.5" />
                      </div>
                      <span className="font-mono text-xs font-bold text-white">{node.label}</span>
                    </div>
                    <span className={`text-[10px] uppercase font-mono px-2 py-0.5 rounded border font-semibold ${typeStyle.badge}`}>
                      {node.type}
                    </span>
                  </div>

                  <p className="text-[11px] text-slate-300 line-clamp-2 leading-relaxed">
                    {node.description}
                  </p>

                  <div className="flex items-center justify-between pt-2 border-t border-slate-800/60 text-[10px] font-mono text-slate-400">
                    <span className="truncate max-w-[140px]">Substrate: {node.substrate}</span>
                    <span className="text-teal-400 flex items-center gap-1 shrink-0">
                      <span>{node.connections.length} links</span>
                      <ArrowRight className="w-3 h-3" />
                    </span>
                  </div>
                </button>
              );
            })}
          </div>

          <div className="mt-4 pt-4 border-t border-slate-800/80 flex items-center justify-between text-[11px] text-slate-400 font-mono">
            <span>Tip: Click any primitive node to inspect signal flow & substrate specs.</span>
            <span className="text-teal-400">Generation {generation} Topology</span>
          </div>
        </div>

        {/* Selected Node Inspector Sidepanel */}
        <div className="p-6 bg-slate-900/60">
          <AnimatePresence mode="wait">
            {selectedNode && (
              <motion.div
                key={selectedNode.id}
                initial={{ opacity: 0, x: 10 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -10 }}
                transition={{ duration: 0.2 }}
                className="space-y-4"
              >
                <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                  <span className="text-xs font-semibold uppercase tracking-wider text-slate-400">
                    Node Inspector
                  </span>
                  <span className={`text-[10px] font-mono px-2 py-0.5 rounded border ${TYPE_COLORS[selectedNode.type]?.badge}`}>
                    {selectedNode.type.toUpperCase()}
                  </span>
                </div>

                <div>
                  <h4 className="text-base font-bold text-white mb-1">{selectedNode.label}</h4>
                  <p className="text-xs font-mono text-teal-400 mb-3">ID: #{selectedNode.id}</p>
                  <p className="text-xs text-slate-300 leading-relaxed bg-slate-950 p-3 rounded-xl border border-slate-800">
                    {selectedNode.description}
                  </p>
                </div>

                <div className="space-y-2">
                  <span className="text-xs font-semibold text-slate-300 block">Biological Substrate:</span>
                  <div className="p-2.5 rounded-lg bg-slate-950 border border-slate-800 text-xs font-mono text-teal-300 flex items-center gap-2">
                    <Info className="w-3.5 h-3.5 text-teal-400 shrink-0" />
                    <span className="truncate">{selectedNode.substrate}</span>
                  </div>
                </div>

                <div className="space-y-2">
                  <span className="text-xs font-semibold text-slate-300 block">Downstream Signal Links:</span>
                  {selectedNode.connections.length === 0 ? (
                    <span className="text-xs font-mono text-slate-500 italic block">Terminal node (No downstream links)</span>
                  ) : (
                    <div className="space-y-1.5">
                      {selectedNode.connections.map((targetId) => {
                        const targetNode = nodes.find((n) => n.id === targetId);
                        return (
                          <div
                            key={targetId}
                            onClick={() => setSelectedNodeId(targetId)}
                            className="p-2 rounded-lg bg-slate-950 hover:bg-slate-800 border border-slate-800/80 text-xs text-slate-300 flex items-center justify-between cursor-pointer transition-colors"
                          >
                            <span className="font-mono text-teal-300">
                              → {targetNode?.label || targetId}
                            </span>
                            <span className="text-[10px] font-mono text-slate-500 uppercase">
                              {targetNode?.type || 'node'}
                            </span>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>

                <div className="pt-3 border-t border-slate-800 text-[11px] text-slate-400 flex items-center gap-1.5">
                  <CheckCircle className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                  <span>Verified signal transduction protocol in concept frame</span>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
};
