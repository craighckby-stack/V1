'use client';

import React, { useState } from 'react';
import { GenerationResult } from '@/lib/types';
import { GitCommit, ArrowRight, Layers, Sparkles, CheckCircle2, ChevronRight, Scale } from 'lucide-react';
import { motion } from 'motion/react';

interface TimelineHistoryProps {
  history: GenerationResult[];
  selectedGeneration: number;
  onSelectGeneration: (gen: number) => void;
}

export const TimelineHistory: React.FC<TimelineHistoryProps> = ({
  history,
  selectedGeneration,
  onSelectGeneration,
}) => {
  const [compareGenA, setCompareGenA] = useState<number>(history[0]?.generation || 1);
  const [compareGenB, setCompareGenB] = useState<number>(history[history.length - 1]?.generation || 1);
  const [isCompareMode, setIsCompareMode] = useState<boolean>(false);

  if (!history || history.length === 0) {
    return (
      <div className="w-full max-w-5xl mx-auto p-8 text-center bg-slate-900/50 border border-slate-800 rounded-2xl text-slate-400 text-xs font-mono">
        No generation history available yet. Start the evolution engine above!
      </div>
    );
  }

  const genAData = history.find((h) => h.generation === compareGenA) || history[0];
  const genBData = history.find((h) => h.generation === compareGenB) || history[history.length - 1];

  return (
    <div className="w-full max-w-5xl mx-auto space-y-6">
      {/* Header & Mode Switch */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-6 backdrop-blur-md flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-lg font-bold text-white flex items-center gap-2">
            <Layers className="w-4 h-4 text-teal-400" />
            <span>Recursive Lineage History</span>
          </h2>
          <p className="text-xs text-slate-400">
            Recorded {history.length} generation cycles of architectural self-improvement.
          </p>
        </div>

        <button
          onClick={() => setIsCompareMode(!isCompareMode)}
          className={`px-3.5 py-1.5 text-xs font-semibold rounded-xl border transition-all flex items-center gap-2 ${
            isCompareMode
              ? 'bg-teal-500 text-slate-950 border-teal-400 font-bold'
              : 'bg-slate-950 text-slate-300 hover:text-white border-slate-700'
          }`}
        >
          <Scale className="w-3.5 h-3.5" />
          <span>{isCompareMode ? 'Exit Diff View' : 'Compare Generations (Side-by-Side)'}</span>
        </button>
      </div>

      {!isCompareMode ? (
        /* Timeline View */
        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-6 backdrop-blur-md">
          <div className="relative pl-6 sm:pl-8 space-y-8 before:absolute before:left-3 sm:before:left-4 before:top-3 before:bottom-3 before:w-0.5 before:bg-slate-800">
            {history.map((item) => {
              const isSelected = item.generation === selectedGeneration;
              return (
                <div key={item.generation} className="relative group">
                  {/* Timeline Dot */}
                  <div
                    onClick={() => onSelectGeneration(item.generation)}
                    className={`absolute -left-[30px] sm:-left-[35px] top-1 w-6 h-6 rounded-full border-2 flex items-center justify-center cursor-pointer transition-all ${
                      isSelected
                        ? 'bg-teal-400 border-teal-300 ring-4 ring-teal-500/20 text-slate-950'
                        : 'bg-slate-950 border-slate-700 text-slate-500 hover:border-teal-400'
                    }`}
                  >
                    <GitCommit className="w-3.5 h-3.5" />
                  </div>

                  <div
                    onClick={() => onSelectGeneration(item.generation)}
                    className={`p-5 rounded-2xl border transition-all cursor-pointer ${
                      isSelected
                        ? 'bg-slate-800/90 border-teal-500/50 ring-1 ring-teal-500/30 shadow-lg shadow-teal-950/20'
                        : 'bg-slate-950/60 border-slate-800 hover:border-slate-700 hover:bg-slate-900/50'
                    }`}
                  >
                    <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 mb-2">
                      <div className="flex items-center gap-2">
                        <span className="font-mono text-xs font-bold text-teal-400 bg-teal-500/10 px-2.5 py-0.5 rounded border border-teal-500/20">
                          GEN {item.generation}
                        </span>
                        <span className="text-xs text-slate-400 font-mono">
                          {new Date(item.timestamp).toLocaleTimeString()}
                        </span>
                      </div>

                      <div className="flex items-center gap-2 text-xs font-mono">
                        <span className="text-slate-400">Coherence:</span>
                        <span className="text-teal-300 font-bold">{item.key_metrics?.coherenceScore ?? 75}/100</span>
                        <span className="text-slate-600">|</span>
                        <span className="uppercase text-[10px] font-bold px-2 py-0.5 rounded bg-slate-900 border border-slate-700 text-slate-300">
                          {item.decision}
                        </span>
                      </div>
                    </div>

                    <p className="text-xs text-slate-300 line-clamp-2 leading-relaxed mb-3">
                      {item.analysis}
                    </p>

                    <div className="flex items-center justify-between text-[11px] font-mono text-slate-400 pt-2 border-t border-slate-800/60">
                      <span>{item.graph_nodes?.length || 0} Primitive Nodes</span>
                      <span className="text-teal-400 flex items-center gap-1 group-hover:translate-x-1 transition-transform">
                        <span>Inspect Frame</span>
                        <ChevronRight className="w-3.5 h-3.5" />
                      </span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      ) : (
        /* Side by Side Diff View */
        <div className="space-y-4">
          <div className="p-4 bg-slate-950 border border-slate-800 rounded-2xl flex flex-col sm:flex-row items-center justify-center gap-4 text-xs">
            <div className="flex items-center gap-2">
              <span className="text-slate-400 font-semibold">Generation A:</span>
              <select
                value={compareGenA}
                onChange={(e) => setCompareGenA(Number(e.target.value))}
                className="bg-slate-900 border border-slate-700 rounded-lg px-3 py-1.5 text-white font-mono"
              >
                {history.map((h) => (
                  <option key={h.generation} value={h.generation}>
                    Gen {h.generation} ({h.decision})
                  </option>
                ))}
              </select>
            </div>

            <ArrowRight className="w-4 h-4 text-teal-400 shrink-0" />

            <div className="flex items-center gap-2">
              <span className="text-slate-400 font-semibold">Generation B:</span>
              <select
                value={compareGenB}
                onChange={(e) => setCompareGenB(Number(e.target.value))}
                className="bg-slate-900 border border-slate-700 rounded-lg px-3 py-1.5 text-white font-mono"
              >
                {history.map((h) => (
                  <option key={h.generation} value={h.generation}>
                    Gen {h.generation} ({h.decision})
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Gen A Column */}
            <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 space-y-4">
              <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                <span className="font-mono font-bold text-teal-400 text-sm">Generation {genAData.generation}</span>
                <span className="text-xs font-mono text-slate-300 px-2 py-0.5 rounded bg-slate-950 border border-slate-800">
                  Score: {genAData.key_metrics?.coherenceScore}/100
                </span>
              </div>
              <div className="space-y-3">
                <span className="text-xs font-semibold text-slate-400 block uppercase">Analysis & Strategy</span>
                <p className="text-xs text-slate-300 leading-relaxed bg-slate-950 p-3 rounded-xl border border-slate-800 font-mono">
                  {genAData.analysis}
                </p>
                <span className="text-xs font-semibold text-slate-400 block uppercase">Architecture Design</span>
                <div className="text-xs text-slate-300 leading-relaxed bg-slate-950 p-3 rounded-xl border border-slate-800 max-h-80 overflow-y-auto whitespace-pre-wrap font-sans">
                  {genAData.mutated_design}
                </div>
              </div>
            </div>

            {/* Gen B Column */}
            <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 space-y-4">
              <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                <span className="font-mono font-bold text-teal-400 text-sm">Generation {genBData.generation}</span>
                <span className="text-xs font-mono text-slate-300 px-2 py-0.5 rounded bg-slate-950 border border-slate-800">
                  Score: {genBData.key_metrics?.coherenceScore}/100
                </span>
              </div>
              <div className="space-y-3">
                <span className="text-xs font-semibold text-slate-400 block uppercase">Analysis & Strategy</span>
                <p className="text-xs text-slate-300 leading-relaxed bg-slate-950 p-3 rounded-xl border border-slate-800 font-mono">
                  {genBData.analysis}
                </p>
                <span className="text-xs font-semibold text-slate-400 block uppercase">Architecture Design</span>
                <div className="text-xs text-slate-300 leading-relaxed bg-slate-950 p-3 rounded-xl border border-slate-800 max-h-80 overflow-y-auto whitespace-pre-wrap font-sans">
                  {genBData.mutated_design}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
