'use client';

import React, { useState } from 'react';
import { GenerationResult, DomainCategory } from '@/lib/types';
import { ArchitectureNodeGraph } from './ArchitectureNodeGraph';
import { MetricsPanel } from './MetricsPanel';
import { Sparkles, HelpCircle, ShieldCheck, FileText, Network, BarChart2, AlertCircle, ArrowUpRight } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface GenerationViewerProps {
  result: GenerationResult;
  totalGenerations: number;
  domain?: DomainCategory;
  onStepNext?: () => void;
  onForkGen?: () => void;
  isRunning?: boolean;
}

export const GenerationViewer: React.FC<GenerationViewerProps> = ({
  result,
  totalGenerations,
  domain = 'codebase-meta',
  onStepNext,
  onForkGen,
  isRunning,
}) => {
  const [activeTab, setActiveTab] = useState<'design' | 'graph' | 'analysis' | 'verification' | 'questions'>('design');

  const getDecisionBadge = (decision: string) => {
    switch (decision) {
      case 'stop':
        return {
          label: 'Sufficiently Developed (Optimal Stop)',
          bg: 'bg-emerald-950/80 border-emerald-500/40 text-emerald-300',
          dot: 'bg-emerald-400',
        };
      case 'pivot':
        return {
          label: 'Architectural Pivot Recommended',
          bg: 'bg-amber-950/80 border-amber-500/40 text-amber-300',
          dot: 'bg-amber-400',
        };
      case 'continue':
      default:
        return {
          label: 'Active Refinement Loop (Continue)',
          bg: 'bg-teal-950/80 border-teal-500/40 text-teal-300',
          dot: 'bg-teal-400',
        };
    }
  };

  const decisionBadge = getDecisionBadge(result.decision);

  return (
    <div className="w-full max-w-5xl mx-auto space-y-6">
      {/* Top Generation Banner */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-6 backdrop-blur-md shadow-xl">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-4 border-b border-slate-800">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="text-xs font-mono uppercase text-teal-400 font-bold bg-teal-500/10 px-2.5 py-0.5 rounded border border-teal-500/20">
                Generation {result.generation} of {totalGenerations}
              </span>
              <span className="text-xs font-mono text-slate-500">
                {new Date(result.timestamp).toLocaleTimeString()}
              </span>
            </div>
            <h2 className="text-xl font-bold text-white tracking-tight">
              Evolved Architectural Frame #{result.generation}
            </h2>
          </div>

          <div className="flex items-center gap-3">
            <div className={`px-3 py-1.5 rounded-xl border text-xs font-semibold flex items-center gap-2 ${decisionBadge.bg}`}>
              <span className={`w-2 h-2 rounded-full ${decisionBadge.dot} animate-pulse`} />
              <span>{decisionBadge.label}</span>
            </div>

            {onForkGen && (
              <button
                onClick={onForkGen}
                className="px-3 py-1.5 text-xs font-medium bg-slate-950 hover:bg-slate-800 text-slate-300 hover:text-white rounded-xl border border-slate-700 transition-colors flex items-center gap-1.5"
                title="Fork this generation as baseline for new evolution line"
              >
                <ArrowUpRight className="w-3.5 h-3.5" />
                <span>Fork Gen</span>
              </button>
            )}
          </div>
        </div>

        {/* Reason summary */}
        {result.reason && (
          <div className="mt-4 p-3 rounded-xl bg-slate-950/60 border border-slate-800/80 text-xs text-slate-300 flex items-start gap-2">
            <Sparkles className="w-4 h-4 text-teal-400 shrink-0 mt-0.5" />
            <div>
              <span className="font-semibold text-teal-300">Agent Rationalization: </span>
              <span className="text-slate-300">{result.reason}</span>
            </div>
          </div>
        )}
      </div>

      {/* Dynamic Metrics Row */}
      <MetricsPanel metrics={result.key_metrics} generation={result.generation} domain={domain} />

      {/* View Tabs */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-2xl overflow-hidden shadow-xl">
        <div className="flex items-center gap-1 p-2 bg-slate-950 border-b border-slate-800 overflow-x-auto no-scrollbar">
          <button
            onClick={() => setActiveTab('design')}
            className={`px-4 py-2 text-xs font-semibold rounded-xl transition-all whitespace-nowrap shrink-0 flex items-center gap-2 ${
              activeTab === 'design'
                ? 'bg-slate-800 text-teal-300 border border-teal-500/30 shadow-sm'
                : 'text-slate-400 hover:text-white hover:bg-slate-900'
            }`}
          >
            <FileText className="w-3.5 h-3.5" />
            <span>Evolved Specification</span>
          </button>
          <button
            onClick={() => setActiveTab('graph')}
            className={`px-4 py-2 text-xs font-semibold rounded-xl transition-all whitespace-nowrap shrink-0 flex items-center gap-2 ${
              activeTab === 'graph'
                ? 'bg-slate-800 text-teal-300 border border-teal-500/30 shadow-sm'
                : 'text-slate-400 hover:text-white hover:bg-slate-900'
            }`}
          >
            <Network className="w-3.5 h-3.5" />
            <span>System Node Topology</span>
          </button>
          <button
            onClick={() => setActiveTab('analysis')}
            className={`px-4 py-2 text-xs font-semibold rounded-xl transition-all whitespace-nowrap shrink-0 flex items-center gap-2 ${
              activeTab === 'analysis'
                ? 'bg-slate-800 text-teal-300 border border-teal-500/30 shadow-sm'
                : 'text-slate-400 hover:text-white hover:bg-slate-900'
            }`}
          >
            <BarChart2 className="w-3.5 h-3.5" />
            <span>Scan & Bottleneck Analysis</span>
          </button>
          <button
            onClick={() => setActiveTab('verification')}
            className={`px-4 py-2 text-xs font-semibold rounded-xl transition-all whitespace-nowrap shrink-0 flex items-center gap-2 ${
              activeTab === 'verification'
                ? 'bg-slate-800 text-teal-300 border border-teal-500/30 shadow-sm'
                : 'text-slate-400 hover:text-white hover:bg-slate-900'
            }`}
          >
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>Feasibility & Invariants</span>
          </button>
          <button
            onClick={() => setActiveTab('questions')}
            className={`px-4 py-2 text-xs font-semibold rounded-xl transition-all whitespace-nowrap shrink-0 flex items-center gap-2 ${
              activeTab === 'questions'
                ? 'bg-slate-800 text-teal-300 border border-teal-500/30 shadow-sm'
                : 'text-slate-400 hover:text-white hover:bg-slate-900'
            }`}
          >
            <HelpCircle className="w-3.5 h-3.5" />
            <span>Open Questions ({result.open_questions.length})</span>
          </button>
        </div>

        {/* Tab Contents */}
        <div className="p-6">
          <AnimatePresence mode="wait">
            {activeTab === 'design' && (
              <motion.div
                key="design"
                initial={{ opacity: 0, y: 5 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -5 }}
                className="space-y-4"
              >
                <div className="flex items-center justify-between">
                  <h3 className="text-base font-bold text-white flex items-center gap-2">
                    <span>Evolved Architectural Blueprint</span>
                    <span className="text-xs text-teal-400 font-mono font-normal">(Mutated Baseline)</span>
                  </h3>
                </div>

                <div className="prose prose-invert max-w-none bg-slate-950 p-6 rounded-xl border border-slate-800 text-xs sm:text-sm text-slate-300 leading-relaxed font-sans overflow-x-auto whitespace-pre-wrap">
                  {result.mutated_design}
                </div>
              </motion.div>
            )}

            {activeTab === 'graph' && (
              <motion.div
                key="graph"
                initial={{ opacity: 0, y: 5 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -5 }}
              >
                <ArchitectureNodeGraph nodes={result.graph_nodes} generation={result.generation} />
              </motion.div>
            )}

            {activeTab === 'analysis' && (
              <motion.div
                key="analysis"
                initial={{ opacity: 0, y: 5 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -5 }}
                className="space-y-4"
              >
                <h3 className="text-base font-bold text-white">Baseline Scan & Comparative Analysis</h3>
                <div className="bg-slate-950 p-6 rounded-xl border border-slate-800 text-xs sm:text-sm text-slate-300 leading-relaxed whitespace-pre-wrap">
                  {result.analysis}
                </div>
              </motion.div>
            )}

            {activeTab === 'verification' && (
              <motion.div
                key="verification"
                initial={{ opacity: 0, y: 5 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -5 }}
                className="space-y-4"
              >
                <h3 className="text-base font-bold text-white flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-emerald-400" />
                  <span>Theoretical Coherence & Constraint Verification</span>
                </h3>
                <div className="bg-slate-950 p-6 rounded-xl border border-slate-800 text-xs sm:text-sm text-slate-300 leading-relaxed whitespace-pre-wrap">
                  {result.verification}
                </div>
              </motion.div>
            )}

            {activeTab === 'questions' && (
              <motion.div
                key="questions"
                initial={{ opacity: 0, y: 5 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -5 }}
                className="space-y-4"
              >
                <h3 className="text-base font-bold text-white flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 text-amber-400" />
                  <span>Key Open Research & System Challenges</span>
                </h3>
                <div className="space-y-2.5">
                  {result.open_questions.map((q, idx) => (
                    <div
                      key={idx}
                      className="p-4 rounded-xl bg-slate-950 border border-slate-800/90 text-xs sm:text-sm text-slate-200 flex items-start gap-3"
                    >
                      <span className="font-mono text-teal-400 font-bold bg-teal-500/10 px-2 py-0.5 rounded border border-teal-500/20 shrink-0">
                        Q{idx + 1}
                      </span>
                      <p className="leading-relaxed">{q}</p>
                    </div>
                  ))}
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
};
