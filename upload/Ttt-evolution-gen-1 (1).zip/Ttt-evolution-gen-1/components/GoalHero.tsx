'use client';

import React, { useState, useEffect } from 'react';
import { PRESET_GOALS, DOMAIN_CONFIGS } from '@/lib/presetGoals';
import { PresetGoal, DomainCategory } from '@/lib/types';
import { Play, Sparkles, CheckCircle2, ChevronDown, Code2, Server, Dna, TrendingUp, Rocket, Gamepad2, Shield } from 'lucide-react';
import { motion } from 'motion/react';

interface GoalHeroProps {
  onStartLoop: (goal: string, maxGen: number, substrate: string, domain: DomainCategory) => void;
  isRunning: boolean;
  selectedDomain: DomainCategory;
  onSelectDomain: (domain: DomainCategory) => void;
}

const DOMAIN_ICONS: Record<DomainCategory, React.ElementType> = {
  'codebase-meta': Code2,
  'software-architecture': Server,
  'biological-ai': Dna,
  'quant-trading': TrendingUp,
  'aerospace-physics': Rocket,
  'game-balancer': Gamepad2,
  'governance-tokenomics': Shield,
};

export const GoalHero: React.FC<GoalHeroProps> = ({
  onStartLoop,
  isRunning,
  selectedDomain,
  onSelectDomain,
}) => {
  const currentDomainConfig = DOMAIN_CONFIGS[selectedDomain];
  const domainPresets = PRESET_GOALS.filter((p) => p.domain === selectedDomain);

  const [goalText, setGoalText] = useState(domainPresets[0]?.goalPrompt || '');
  const [selectedPresetId, setSelectedPresetId] = useState<string>(domainPresets[0]?.id || '');
  const [substrateFocus, setSubstrateFocus] = useState<string>(
    currentDomainConfig.subFocusOptions[0]?.id || ''
  );
  const [maxGenerations, setMaxGenerations] = useState<number>(6);

  // Sync state whenever selected domain changes
  useEffect(() => {
    const presets = PRESET_GOALS.filter((p) => p.domain === selectedDomain);
    const firstPreset = presets[0];
    if (firstPreset) {
      setSelectedPresetId(firstPreset.id);
      setGoalText(firstPreset.goalPrompt);
    } else {
      setSelectedPresetId('');
      setGoalText('');
    }
    const defaultSub = DOMAIN_CONFIGS[selectedDomain]?.subFocusOptions[0]?.id || '';
    setSubstrateFocus(defaultSub);
  }, [selectedDomain]);

  const handleSelectPreset = (preset: PresetGoal) => {
    setSelectedPresetId(preset.id);
    setGoalText(preset.goalPrompt);
    setSubstrateFocus(preset.substrate);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!goalText.trim() || isRunning) return;
    onStartLoop(goalText.trim(), maxGenerations, substrateFocus, selectedDomain);
  };

  const DomainIcon = DOMAIN_ICONS[selectedDomain] || Sparkles;

  return (
    <div className="w-full max-w-5xl mx-auto px-4 py-8">
      {/* Title & Domain Dropdown Bar */}
      <div className="text-center max-w-3xl mx-auto mb-8 space-y-4">
        {/* Domain Selector Dropdown Header */}
        <div className="inline-flex items-center gap-2 p-1.5 bg-slate-900 border border-slate-700/80 rounded-2xl shadow-lg">
          <div className="w-7 h-7 rounded-xl bg-teal-500/20 text-teal-300 flex items-center justify-center shrink-0">
            <DomainIcon className="w-4 h-4" />
          </div>

          <div className="relative">
            <select
              value={selectedDomain}
              onChange={(e) => onSelectDomain(e.target.value as DomainCategory)}
              className="appearance-none bg-transparent pl-2 pr-8 py-1 text-xs font-bold text-white uppercase tracking-wider cursor-pointer focus:outline-none"
            >
              {Object.values(DOMAIN_CONFIGS).map((cfg) => (
                <option key={cfg.id} value={cfg.id} className="bg-slate-900 text-slate-100 normal-case">
                  {cfg.name}
                </option>
              ))}
            </select>
            <ChevronDown className="w-3.5 h-3.5 text-slate-400 absolute right-2 top-2 pointer-events-none" />
          </div>

          <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-800 text-teal-400 border border-teal-500/20 uppercase font-semibold">
            {currentDomainConfig.badge}
          </span>
        </div>

        <h1 className="text-3xl sm:text-4xl md:text-5xl font-bold tracking-tight text-white leading-tight">
          Recursive Design Engine <br />
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-teal-400 via-emerald-300 to-cyan-400">
            {currentDomainConfig.name}
          </span>
        </h1>

        <p className="text-sm sm:text-base text-slate-400 max-w-2xl mx-auto leading-relaxed">
          {currentDomainConfig.description}
        </p>
      </div>

      {/* Main Configuration Card */}
      <motion.div
        key={selectedDomain}
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3 }}
        className="bg-slate-900/80 border border-slate-800 rounded-2xl p-6 sm:p-8 backdrop-blur-sm shadow-xl shadow-slate-950/50"
      >
        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Domain-specific Preset Buttons */}
          <div>
            <div className="flex items-center justify-between mb-3">
              <label className="text-xs font-semibold uppercase tracking-wider text-slate-400">
                1. Select an Ingested Research / Architecture Objective
              </label>
              <span className="text-[11px] font-mono text-teal-400">
                {domainPresets.length} Presets Available
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {domainPresets.map((preset) => {
                const isSelected = selectedPresetId === preset.id;
                return (
                  <button
                    key={preset.id}
                    type="button"
                    onClick={() => handleSelectPreset(preset)}
                    className={`text-left p-3.5 rounded-xl border transition-all text-xs flex flex-col justify-between ${
                      isSelected
                        ? 'bg-slate-800 border-teal-500/60 ring-1 ring-teal-500/40 text-white shadow-md shadow-teal-950/20'
                        : 'bg-slate-950/50 border-slate-800/80 text-slate-300 hover:border-slate-700 hover:bg-slate-900'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-2 mb-1.5">
                      <span className="font-semibold text-teal-300 line-clamp-1">{preset.title}</span>
                      {isSelected && <CheckCircle2 className="w-3.5 h-3.5 text-teal-400 shrink-0 mt-0.5" />}
                    </div>
                    <p className="text-[11px] text-slate-400 line-clamp-2 leading-relaxed">
                      {preset.description}
                    </p>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Prompt / Directive Input */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <label htmlFor="goalText" className="text-xs font-semibold uppercase tracking-wider text-slate-400">
                Target Architecture Directive
              </label>
              <span className="text-[11px] text-slate-500 font-mono">
                {selectedDomain === 'codebase-meta' ? 'Self-Inspection Lens' : 'High-Level Goal Specification'}
              </span>
            </div>
            <textarea
              id="goalText"
              rows={4}
              value={goalText}
              onChange={(e) => {
                setGoalText(e.target.value);
                setSelectedPresetId('');
              }}
              placeholder={`Specify the objective for ${currentDomainConfig.name}...`}
              className="w-full bg-slate-950 border border-slate-800 rounded-xl p-4 text-xs sm:text-sm text-slate-100 placeholder-slate-600 focus:outline-none focus:border-teal-500/60 focus:ring-1 focus:ring-teal-500/40 font-mono leading-relaxed resize-none shadow-inner"
            />
          </div>

          {/* Sub-Focus Options */}
          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-3">
              2. {currentDomainConfig.subFocusLabel}
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
              {currentDomainConfig.subFocusOptions.map((opt) => {
                const isSelected = substrateFocus === opt.id;
                return (
                  <button
                    key={opt.id}
                    type="button"
                    onClick={() => setSubstrateFocus(opt.id)}
                    className={`p-3 rounded-xl border text-left transition-all ${
                      isSelected
                        ? 'bg-teal-950/40 border-teal-500/60 text-teal-200 ring-1 ring-teal-500/30'
                        : 'bg-slate-950/40 border-slate-800 text-slate-400 hover:border-slate-700 hover:text-slate-200'
                    }`}
                  >
                    <span className="text-xs font-semibold block mb-1 text-white">{opt.label}</span>
                    <p className="text-[11px] text-slate-500 line-clamp-2 leading-relaxed">{opt.desc}</p>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Launch Controls Row */}
          <div className="pt-2 flex flex-col sm:flex-row items-center justify-between gap-4 border-t border-slate-800/80">
            <div className="flex items-center gap-3 w-full sm:w-auto">
              <span className="text-xs text-slate-400 font-medium">Max Generations:</span>
              <div className="flex items-center gap-1.5 p-1 bg-slate-950 rounded-lg border border-slate-800">
                {[3, 6, 8, 12].map((num) => (
                  <button
                    key={num}
                    type="button"
                    onClick={() => setMaxGenerations(num)}
                    className={`px-3 py-1 text-xs font-mono rounded-md transition-colors ${
                      maxGenerations === num
                        ? 'bg-teal-500 text-slate-950 font-bold'
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    {num}
                  </button>
                ))}
              </div>
            </div>

            <button
              type="submit"
              disabled={isRunning || !goalText.trim()}
              className="w-full sm:w-auto px-6 py-3 rounded-xl bg-gradient-to-r from-teal-500 to-emerald-500 text-slate-950 font-bold text-xs uppercase tracking-wider hover:from-teal-400 hover:to-emerald-400 transition-all shadow-lg shadow-teal-500/20 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2 shrink-0"
            >
              <Play className="w-4 h-4 fill-slate-950" />
              <span>Launch Recursive Evolution Loop</span>
            </button>
          </div>
        </form>
      </motion.div>
    </div>
  );
};
