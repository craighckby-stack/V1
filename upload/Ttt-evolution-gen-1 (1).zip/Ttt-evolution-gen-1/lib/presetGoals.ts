import { DomainCategory, DomainConfig, PresetGoal } from "./types";

export const DOMAIN_CONFIGS: Record<DomainCategory, DomainConfig> = {
  "codebase-meta": {
    id: "codebase-meta",
    name: "Self-Reflective Codebase Architecture",
    tagline: "Scans, profiles, and recurses on its own Next.js / TypeScript codebase files",
    badge: "SELF-ANALYSIS",
    iconName: "Code2",
    description: "The recursive loop ingests the application's actual files (/app, /components, /lib), analyzing cyclomatic complexity, component decoupling, state redundancy, and architectural cohesion.",
    subFocusLabel: "Inspection & Refactoring Lens",
    subFocusOptions: [
      { id: "Full Application Stack", label: "Full Stack Topology", desc: "Holistic review across /app, /components, and /lib APIs" },
      { id: "State Management & Reactivity", label: "Reactivity & State Flow", desc: "Audit re-renders, useEffects, and state synchronization" },
      { id: "API Fault-Tolerance & Resilience", label: "Network & Resilience", desc: "Examine error handling, abort controllers, and fallback tiers" },
      { id: "Type Safety & Domain Invariants", label: "Type Contract Rigor", desc: "Inspect schema coverage, interfaces, and invariant boundaries" },
    ],
    metricLabels: {
      m1Title: "Coherence Score",
      m1Desc: "Overall structural cohesion and lack of architectural anti-patterns.",
      m2Title: "Decoupling Ratio",
      m2Desc: "Degree of loose coupling between state, UI, and backend services.",
      m3Title: "Cyclomatic Index",
      m3Desc: "Complexity and branching density across component functions.",
      m4Title: "Resilience Factor",
      m4Desc: "Fault-tolerance against unexpected API latency and network crashes.",
    },
    systemPrompt: `You are a Principal Software Architect running a recursive self-improvement audit on this very application codebase.
The application is a Next.js 15 App Router TypeScript system with server routes in /app/api, UI in /components, and engine helpers in /lib.
Your operating loop is:
1. Scan current codebase architecture baseline, files, and modular boundaries.
2. Analyze coupling, component responsibilities, error boundaries, memory safety, and technical debt.
3. Mutate / Refactor the architectural specification into an optimized design pattern with improved separation of concerns.
4. Verify consistency with Next.js App Router rules, React 19 hooks, and resilience invariants.
5. Decide whether to continue refining, declare the architecture optimal, or recommend a structural pivot.
Output node graph mapping the key software modules, their contracts, and dependencies.`,
  },

  "software-architecture": {
    id: "software-architecture",
    name: "Distributed Systems & Cloud Architecture",
    tagline: "Scalable microservices, event streaming, and low-latency cloud infrastructure",
    badge: "DISTRIBUTED SYSTEMS",
    iconName: "Server",
    description: "Architect high-throughput, fault-tolerant distributed platforms (event brokers, consensus engines, distributed databases, geo-redundant caches).",
    subFocusLabel: "System Archetype",
    subFocusOptions: [
      { id: "Event-Driven CQRS", label: "Event-Driven CQRS", desc: "Asynchronous pub/sub with partitioned event log persistence" },
      { id: "Zero-Trust Mesh", label: "Service Mesh & Gateway", desc: "mTLS proxy topology with localized circuit breakers" },
      { id: "Distributed Consensus", label: "Raft/Paxos Consensus", desc: "Leader-elected state machines with monotonic log replication" },
      { id: "Edge Compute Cache", label: "Multi-Region Cache", desc: "Conflict-free replicated data types (CRDTs) with sub-5ms lookups" },
    ],
    metricLabels: {
      m1Title: "Coherence Score",
      m1Desc: "Systemic stability and consistency across partitions (CAP theorem).",
      m2Title: "Throughput Capacity",
      m2Desc: "Estimated peak sustained transactions or events per second.",
      m3Title: "P99 Service Latency",
      m3Desc: "Round-trip processing delay under 99th percentile load.",
      m4Title: "Fault Tolerance",
      m4Desc: "Maximum node dropouts tolerated without consistency breach.",
    },
    systemPrompt: `You are a Distributed Systems Architect designing high-throughput cloud platforms.
Operating loop:
1. Scan system topology and latency/throughput targets.
2. Analyze bottlenecks, network boundaries, backpressure mechanisms, and data consistency models.
3. Mutate architecture to enhance modularity, partition tolerance, and horizontal scalability.
4. Verify physical latency budgets, serialized state costs, and network I/O limits.
5. Decide whether to continue, stop, or pivot.
Map system nodes as Microservices, Gateways, Queues, Caches, or Event Stores.`,
  },

  "biological-ai": {
    id: "biological-ai",
    name: "Biological AI & Synthetic Bio-Computing",
    tagline: "Organoid neural processors, gene circuit computing, and molecular memory",
    badge: "BIO-COMPUTING",
    iconName: "Dna",
    description: "Recursive design of engineered living or hybrid computing substrates (neural organoids, optogenetic networks, enzymatic Turing machines).",
    subFocusLabel: "Bio-Substrate Architecture Focus",
    subFocusOptions: [
      { id: "Neural Organoid Assembly", label: "Neural Organoids", desc: "Cerebral organoid matrices with optogenetic channels" },
      { id: "Synthetic Gene Circuits", label: "Synthetic Gene Circuits", desc: "TF cascades & morphogen intercellular networks" },
      { id: "Metabolic Logic States", label: "Metabolic Logic", desc: "Compartmentalized enzyme state automatons" },
      { id: "Bio-Hybrid Photonics", label: "Bio-Hybrid Photonics", desc: "Cultured neurons integrated with optical micro-waveguides" },
    ],
    metricLabels: {
      m1Title: "Coherence Score",
      m1Desc: "Theoretical conceptual stability and functional feasibility score.",
      m2Title: "Information Density",
      m2Desc: "Volumetric storage and computation capacity (bits/cm³).",
      m3Title: "Transduction Latency",
      m3Desc: "Signal delay across optogenetic and enzymatic processing layers.",
      m4Title: "Energy Efficiency",
      m4Desc: "Thermodynamic energetic cost per operation near ATP limits.",
    },
    systemPrompt: `You are an expert Biological AI Architecture Agent specializing in recursive design of bio-computing systems.
Operating loop: Scan -> Analyze -> Mutate -> Verify -> Decide -> Map Nodes.
Safety: Work strictly at the high-level computational architecture, mathematical signal routing, and software modeling level. Never output wet-lab physical recipes.`,
  },

  "quant-trading": {
    id: "quant-trading",
    name: "Quantitative Trading & Alpha Architecture",
    tagline: "Statistical arbitrage, market making, and algorithmic risk engines",
    badge: "QUANTITATIVE FINANCE",
    iconName: "TrendingUp",
    description: "Design systematic trading frameworks, volatility arbitrage engines, cross-asset signal extractors, and risk-managed execution pipelines.",
    subFocusLabel: "Strategy & Market Regime",
    subFocusOptions: [
      { id: "Statistical Arbitrage", label: "Statistical Arbitrage", desc: "Co-integration mean reversion across synthetic asset baskets" },
      { id: "Orderbook Market Making", label: "HFT Market Making", desc: "Avellaneda-Stoikov inventory skewing with microstructure queues" },
      { id: "Cross-Market Momentum", label: "Multi-Horizon Trend", desc: "Kalman-filtered momentum with adaptive volatility scaling" },
      { id: "Derivatives Gamma Hedging", label: "Volatility Surface Engine", desc: "Dynamic smile interpolation and automated delta-gamma hedging" },
    ],
    metricLabels: {
      m1Title: "Coherence Score",
      m1Desc: "Mathematical rigor and robustness against overfitting/survivorship bias.",
      m2Title: "Projected Sharpe",
      m2Desc: "Expected annualized risk-adjusted return ratio.",
      m3Title: "Max Drawdown Cap",
      m3Desc: "Tail-risk portfolio impairment under 3-sigma liquidation events.",
      m4Title: "Turnover & Slippage",
      m4Desc: "Execution friction drag per volume traded across exchange books.",
    },
    systemPrompt: `You are a Quantitative Portfolio Architect and Mathematical Strategist.
Operating loop:
1. Scan current mathematical signal formulation and alpha hypothesis.
2. Analyze capacity, slippage degradation, regime sensitivity, and tail risks.
3. Mutate mathematical rules, filters, position-sizing vectors, and execution models.
4. Verify no lookahead bias, realistic transaction costs, and portfolio risk bounds.
5. Decide whether to continue, stop, or pivot.
Map nodes as Signal Generators, Risk Invariants, Order Routers, and Inventory Managers.`,
  },

  "aerospace-physics": {
    id: "aerospace-physics",
    name: "Aerospace & Physics Structural Engineering",
    tagline: "Orbital mechanics, passive thermal chassis, and hypersonics",
    badge: "AEROSPACE & PROPULSION",
    iconName: "Rocket",
    description: "System engineering for cubesats, orbital transfer stages, passive thermal management, and composite structural airframes.",
    subFocusLabel: "Subsystem & Operating Regime",
    subFocusOptions: [
      { id: "Cubesat Passive Thermal", label: "LEO Thermal Chassis", desc: "Loop heat pipes, multi-layer insulation, and radiator sizing" },
      { id: "Staged Ion Propulsion", label: "Electric Propulsion", desc: "Hall-effect thruster power processing units and xenon feed lines" },
      { id: "Composite Aerostructure", label: "Ultra-Light Aerostructure", desc: "Carbon fiber truss matrices with vibrational modal dampening" },
      { id: "Entry Aeroshell Guidance", label: "Atmospheric Entry Guidance", desc: "Bank-angle steering with aerodynamic heating stagnation bounds" },
    ],
    metricLabels: {
      m1Title: "Coherence Score",
      m1Desc: "Structural integrity and compliance with orbital physics constraints.",
      m2Title: "Mass Fraction Ratio",
      m2Desc: "Payload-to-dry-mass efficiency percentage.",
      m3Title: "Thermal Delta-T",
      m3Desc: "Temperature stability range under direct solar vs eclipse periods.",
      m4Title: "Specific Impulse (Isp)",
      m4Desc: "Propulsion/energy efficiency (seconds or equivalent power ratio).",
    },
    systemPrompt: `You are an Aerospace Systems Architect and Applied Physicist.
Operating loop:
1. Scan structural mass budgets, thermal margins, and orbital duty cycles.
2. Analyze stress concentrations, radiative dissipation limits, and power constraints.
3. Mutate structural layout, material choices, sensor locations, and heat transfer paths.
4. Verify first principles physics (conservation of energy, launch mass, structural yield).
5. Decide whether to continue, stop, or pivot.
Map nodes as Thermal Radiators, Thrusters, Structural Bulkheads, and Power Buses.`,
  },

  "game-balancer": {
    id: "game-balancer",
    name: "Game Systems & Mechanics Balancer",
    tagline: "Asymmetric combat, economy loops, and meta-game balance",
    badge: "GAME DESIGN & META",
    iconName: "Gamepad2",
    description: "Model and iteratively simulate game mechanics, unit counters, tech trees, and resource economies to prevent dominant strategies.",
    subFocusLabel: "Game Genre & Economy Archetype",
    subFocusOptions: [
      { id: "Asymmetric RTS Factions", label: "Asymmetric RTS Factions", desc: "Distinct faction mechanics with balanced counter-play curves" },
      { id: "CCG Mana Curve & Archetypes", label: "Card Battler Meta", desc: "Aggro/Midrange/Control win-rate symmetry and resource pacing" },
      { id: "Roguelike Synergy Matrix", label: "Item Synergy Matrix", desc: "Multiplicative relic scaling without exponential infinite loops" },
      { id: "MMO Virtual Economy", label: "Sink & Faucet Economy", desc: "Gold drain systems and deflationary market equilibrium" },
    ],
    metricLabels: {
      m1Title: "Coherence Score",
      m1Desc: "Meta-game diversity and absence of degenerate dominant strategies.",
      m2Title: "Win-Rate Symmetry",
      m2Desc: "Theoretical win-rate parity across competing player archetypes.",
      m3Title: "Counterplay Depth",
      m3Desc: "Number of viable tactical responses per high-tier unit or card.",
      m4Title: "Economy Velocity",
      m4Desc: "Resource faucet vs sink equilibrium ratio over 30-minute play sessions.",
    },
    systemPrompt: `You are a Principal Game Systems Designer and Economy Balancer.
Operating loop:
1. Scan current unit roster, tech tree, and resource costs.
2. Analyze power spikes, dominant strategies, snowball mechanics, and non-viable options.
3. Mutate unit attributes, cooldowns, synergy tags, and resource curves.
4. Verify gameplay pacing, counterplay agency, and mathematical symmetry.
5. Decide whether to continue, stop, or pivot.
Map nodes as Resource Faucets, Tech Gates, Combat Units, Counters, and Win Conditions.`,
  },

  "governance-tokenomics": {
    id: "governance-tokenomics",
    name: "Governance & Economic Incentive Design",
    tagline: "Collusion-resistant DAOs, staking curves, and decentralized incentive systems",
    badge: "TOKENOMICS & MECHANISM DESIGN",
    iconName: "Shield",
    description: "Design decentralized governance frameworks, quadratic funding mechanisms, vote-escrow lockups, and attack-resistant treasuries.",
    subFocusLabel: "Mechanism Design Focus",
    subFocusOptions: [
      { id: "Quadratic & Conviction Voting", label: "Conviction Governance", desc: "Time-weighted vote accumulation resistant to flash loans" },
      { id: "Vote-Escrowed (ve) Staking", label: "ve-Tokenomics & Gauges", desc: "Long-term lockup emissions directed by community gauges" },
      { id: "Optimistic Treasury Execution", label: "Optimistic Security", desc: "Timelock delays with veto council veto safeguards" },
      { id: "Public Goods Funding", label: "Retroactive Public Goods", desc: "Impact-weighted capital distribution with reputation scoring" },
    ],
    metricLabels: {
      m1Title: "Coherence Score",
      m1Desc: "Game-theoretic equilibrium and Sybil resistance score.",
      m2Title: "51% Attack Cost",
      m2Desc: "Capital requirement necessary to corrupt voting quorum.",
      m3Title: "Gini Inequality Index",
      m3Desc: "Voting power concentration across participant cohorts.",
      m4Title: "Staking Lockup Rate",
      m4Desc: "Circulating supply percentage committed to long-term alignment.",
    },
    systemPrompt: `You are a Mechanism Design Theorist and Cryptoeconomic Architect.
Operating loop:
1. Scan current staking mechanisms, governance proposals, and token emissions.
2. Analyze bribery attack vectors, voter apathy, whale dominance, and treasury drain risks.
3. Mutate governance rules, voting weights, slashing penalties, and lockup tiers.
4. Verify Nash equilibria, incentive compatibility, and Sybil resistance.
5. Decide whether to continue, stop, or pivot.
Map nodes as Staking Pools, Voting Gauges, Veto Councils, Treasuries, and Emission Sinks.`,
  },
};

export const PRESET_GOALS: PresetGoal[] = [
  // Codebase Self-Analysis
  {
    id: "codebase-audit-meta",
    domain: "codebase-meta",
    title: "Full-Stack Codebase Audit & Modularity Evolution",
    substrate: "Full Application Stack",
    description: "Deep scan of this application's Next.js App Router files (/app, /components, /lib) to optimize decoupling, reduce cyclomatic complexity, and ensure robust error boundaries.",
    goalPrompt: `Perform a full architectural audit of this Biological & Multi-Domain AI Design Studio. Analyze the code organization across /app/api/biological-ai/generate/route.ts, /app/page.tsx, /components/ArchitectureNodeGraph.tsx, and /lib/simulationSynthesizer.ts. Identify tightly-coupled state, opportunities for modular refactoring, and fault-tolerance improvements.`
  },
  {
    id: "codebase-resilience-meta",
    domain: "codebase-meta",
    title: "Zero-Crash Client/Server Network Resilience Pattern",
    substrate: "API Fault-Tolerance & Resilience",
    description: "Evolve a resilient communication protocol between the Next.js frontend and Gemini API with exponential backoff, seamless local fallback, and abort timers.",
    goalPrompt: `Analyze the API resilience layer of this application. Propose a hardened architectural framework for handling Gemini quota limits (429), unexpected network drops, non-JSON proxy responses, and model degradation with multi-tiered fallback strategies.`
  },

  // Distributed Systems & Cloud
  {
    id: "cloud-cqrs-broker",
    domain: "software-architecture",
    title: "10M Events/Sec Distributed Event-Sourcing Broker",
    substrate: "Event-Driven CQRS",
    description: "High-throughput distributed event log with partitioned consumer groups, zero-copy socket transfers, and sub-millisecond end-to-end latency.",
    goalPrompt: `Design a high-throughput, low-latency distributed event broker supporting 10M writes/second. The architecture must feature partitioned append-only commit logs, Raft-based metadata consensus, write-ahead memory caches, and backpressure-resilient consumer push streams.`
  },
  {
    id: "cloud-zero-trust",
    domain: "software-architecture",
    title: "Zero-Trust Global Service Mesh with Ephemeral mTLS",
    substrate: "Zero-Trust Mesh",
    description: "Multi-cluster mesh topology with short-lived cryptographic identities, localized Envoy sidecars, and automated traffic canaries.",
    goalPrompt: `Construct an enterprise-scale Zero-Trust service mesh across hybrid multi-cloud environments. Define SPIFFE/SPIRE identity attestation, eBPF-accelerated sidecar routing, dynamic rate-limiting policies, and automated fault injection verification.`
  },

  // Biological AI
  {
    id: "organoid-processor",
    domain: "biological-ai",
    title: "Organoid Neural Processor with Optogenetic Interconnects",
    substrate: "Neural Organoid Assembly",
    description: "Multi-region cerebral organoid matrix connected via light-driven optogenetic channels for high-density spatial vector computation and adaptive synaptic weight storage.",
    goalPrompt: `Design a research architecture for a biological AI computing system using multi-region neural organoid assemblies connected via optogenetic light-guide arrays. The system must support real-time vector matrix multiplication, adaptive synaptic plasticity learning rules, and optogenetic signal transduction with minimal cross-talk.`
  },
  {
    id: "gene-circuit-neural-net",
    domain: "biological-ai",
    title: "Cellular Gene-Circuit Deep Neural Network",
    substrate: "Synthetic Gene Circuits",
    description: "Distributed cellular ensemble expressing orthogonal transcription factor cascades that execute multi-layer artificial neural network activation functions.",
    goalPrompt: `Design a high-level architectural framework for a synthetic cellular gene circuit deep neural network. Cells should act as computational processing elements using orthogonal transcription factor networks as artificial neurons, with intercellular diffusible morphogen signaling mediating layer-to-layer activation transfer.`
  },

  // Quantitative Trading
  {
    id: "quant-stat-arb",
    domain: "quant-trading",
    title: "Multi-Asset Statistical Arbitrage & Kalman Spread Engine",
    substrate: "Statistical Arbitrage",
    description: "Cointegration testing across 500+ equity and crypto pairs, calculating instantaneous mean-reversion deviations with Ornstein-Uhlenbeck stochastic modeling.",
    goalPrompt: `Design a statistical arbitrage quantitative engine that detects transient cointegration breakdown across liquid assets. Include Kalman-filtered hedge ratio adjustments, dynamic z-score thresholding, volume-weighted order routing, and a strict circuit-breaker max-drawdown risk controller.`
  },
  {
    id: "quant-hft-mm",
    domain: "quant-trading",
    title: "Avellaneda-Stoikov Microstructure Market Making Engine",
    substrate: "Orderbook Market Making",
    description: "Sub-millisecond limit order placement engine optimizing the bid-ask spread while dynamically skewing quotes to maintain neutral inventory risk.",
    goalPrompt: `Architect an ultra-low latency market making engine for central limit order books. Incorporate real-time order flow toxicity (VPIN) monitoring, stochastic inventory penalization, micro-price calculation from level-2 depth, and queue-position optimization.`
  },

  // Aerospace & Physics
  {
    id: "aero-cubesat-thermal",
    domain: "aerospace-physics",
    title: "Passive Thermal Management Chassis for Deep-Space CubeSat",
    substrate: "Cubesat Passive Thermal",
    description: "Dual-loop pulsating heat pipe integrated with variable-emittance electrochromic coatings to maintain payload between -10°C and +35°C across extreme solar flux.",
    goalPrompt: `Design a passive thermal control architecture for a 6U deep-space satellite operating from 0.8 AU to 1.5 AU. Incorporate pulsating heat pipes (PHPs), phase change material (PCM) heat sinks, multi-layer insulation (MLI) blankets, and radiative cooling surfaces.`
  },

  // Game Systems
  {
    id: "game-asymm-factions",
    domain: "game-balancer",
    title: "Three-Way Asymmetric RTS Balance & Counter-Play Matrix",
    substrate: "Asymmetric RTS Factions",
    description: "Bio-swarm vs Tech-fortress vs Psionic-mobile factions balanced around early-game harassment, mid-game expansion, and late-game super-weapons.",
    goalPrompt: `Design a mathematically balanced combat and tech system for 3 radically asymmetric RTS factions. Ensure that no dominant build order exists, win rates stay within 48-52% across skill tiers, and each faction possesses viable counterplay routes against early rushes.`
  },

  // Governance & Tokenomics
  {
    id: "gov-conviction-dao",
    domain: "governance-tokenomics",
    title: "Sybil-Resistant Quadratic Conviction Funding Architecture",
    substrate: "Quadratic & Conviction Voting",
    description: "Decentralized treasury allocation combining continuous conviction voting curves with Soulbound reputation credentials to nullify flash-loan governance takeovers.",
    goalPrompt: `Design a robust governance and tokenomics architecture for a $100M+ community treasury. Integrate continuous conviction voting where voter weight grows over time, quadratic match scaling for public grants, and optimistic timelock security with multi-sig veto safeguards.`
  }
];
