import { GenerationResult, ArchitectureNode, DomainCategory } from "./types";
import { DOMAIN_CONFIGS } from "./presetGoals";

interface SynthesizeParams {
  domain: DomainCategory;
  goal: string;
  currentDesign: string;
  generation: number;
  substrateFocus: string;
}

export function synthesizeGenerationResult({
  domain,
  goal,
  currentDesign,
  generation,
  substrateFocus,
}: SynthesizeParams): GenerationResult {
  const isFirstGen = generation === 1;
  const config = DOMAIN_CONFIGS[domain] || DOMAIN_CONFIGS["biological-ai"];

  // Domain-specific node synthesizer
  const nodes = generateDomainNodes(domain, substrateFocus, generation);

  const coherenceScore = Math.min(98, Math.max(70, 72 + generation * 4));
  const plasticityIndex = Math.min(96, Math.max(62, 66 + generation * 4));

  // Domain-specific metrics generator
  const metrics = generateDomainMetrics(domain, generation);

  const mutatedDesign = generateDomainDesign(domain, substrateFocus, goal, generation);

  const decision = generation >= 6 ? "stop" : generation === 4 ? "pivot" : "continue";
  const reason = decision === "stop"
    ? `Architectural framework achieved high theoretical coherence (${coherenceScore}/100) and satisfies all primary domain constraints.`
    : decision === "pivot"
    ? `Identified potential systemic throughput/coupling bottleneck; pivoting modular topology in Gen ${generation + 1}.`
    : `Continued refinement loop to further optimize latency, decoupling, and resilience profiles.`;

  const openQuestions = generateDomainQuestions(domain, generation);

  return {
    generation,
    timestamp: new Date().toISOString(),
    domain,
    analysis: isFirstGen
      ? `Generation 1 Initial Baseline: Ingested high-level goal for [${config.name}]. Established foundational primitives, interfaces, and invariant boundaries.`
      : `Generation ${generation} Refinement: Deep analysis against constraints. Reduced bottleneck coupling by ~${15 + generation * 4}%, strengthened error boundaries, and refined modular hierarchy.`,
    mutated_design: mutatedDesign,
    verification: `Theoretical verification passed for Generation ${generation}. Invariants checked: boundary separation, latency bounds, fault isolation, and resource budget within target operating limits.`,
    decision,
    reason,
    open_questions: openQuestions,
    graph_nodes: nodes,
    key_metrics: {
      coherenceScore,
      metricTwoValue: metrics.m2,
      metricThreeValue: metrics.m3,
      metricFourValue: metrics.m4,
      plasticityIndex,
    },
  };
}

function generateDomainNodes(domain: DomainCategory, substrateFocus: string, gen: number): ArchitectureNode[] {
  switch (domain) {
    case "codebase-meta":
      return [
        {
          id: "route-api",
          label: "/app/api/biological-ai/generate",
          type: "service",
          description: "Server-side Next.js route handler orchestrating Gemini SDK calls, model fallback tiers, and synthesis fallback.",
          substrate: "Next.js App Router (Node.js)",
          connections: ["gemini-client", "synth-engine"],
        },
        {
          id: "gemini-client",
          label: "Google GenAI SDK Proxy",
          type: "processor",
          description: "Encapsulates @google/genai client with aistudio-build telemetry headers and responseSchema validation.",
          substrate: "@google/genai TypeScript",
          connections: ["page-orchestrator"],
        },
        {
          id: "synth-engine",
          label: "Simulation Synthesizer",
          type: "processor",
          description: "Offline deterministic synthesizer providing zero-downtime execution when API key daily quotas are hit.",
          substrate: "TypeScript In-Memory Logic",
          connections: ["page-orchestrator"],
        },
        {
          id: "page-orchestrator",
          label: "App Page Controller (/app/page.tsx)",
          type: "processor",
          description: "Client state machine coordinating auto-run intervals, recursive step triggers, and tab views.",
          substrate: "React 19 Hooks + Motion",
          connections: ["node-graph-view", "metrics-view", "history-store"],
        },
        {
          id: "node-graph-view",
          label: "Topology Visualizer",
          type: "output",
          description: "Interactive SVG and grid component rendering system primitives, connections, and node telemetry.",
          substrate: "Tailwind CSS + Lucide Icons",
          connections: [],
        },
        {
          id: "history-store",
          label: "Lineage Store & Diff Engine",
          type: "memory",
          description: "Cumulative state array of all generated cycles allowing comparative diffs and generation forking.",
          substrate: "React Component State",
          connections: ["export-modal"],
        },
        {
          id: "export-modal",
          label: "Research Export Engine",
          type: "output",
          description: "Serializes full recursive lineage to formatted Markdown (.md) or structured JSON payloads.",
          substrate: "Browser Blob / Clipboard API",
          connections: [],
        },
      ];

    case "software-architecture":
      return [
        {
          id: "ingress-gw",
          label: "API Ingress & Edge Gateway",
          type: "input",
          description: "Terminates mTLS, validates JWT tokens, and routes requests with Envoy dynamic circuit breaking.",
          substrate: "Envoy / eBPF Gateway",
          connections: ["kafka-log", "auth-service"],
        },
        {
          id: "kafka-log",
          label: "Partitioned Event Log",
          type: "transducer",
          description: "Append-only commit log with Raft metadata consensus and zero-copy page cache disk flushing.",
          substrate: "Distributed Event Broker",
          connections: ["stream-processor", "replica-store"],
        },
        {
          id: "stream-processor",
          label: "Stateful Stream Engine",
          type: "processor",
          description: "Processes tumbling time-windows, joins cross-partition events, and computes real-time aggregations.",
          substrate: "Stream Processing Cluster",
          connections: ["redis-cache", "materialized-view"],
        },
        {
          id: "redis-cache",
          label: "Geo-Distributed CRDT Cache",
          type: "memory",
          description: "Multi-region sub-millisecond cache with conflict-free resolution for read-heavy query patterns.",
          substrate: "Redis / Memcached Cluster",
          connections: ["read-api"],
        },
        {
          id: "replica-store",
          label: "LSM-Tree Distributed DB",
          type: "memory",
          description: "Persistent storage engine with write-ahead logging (WAL) and background SSTable compaction.",
          substrate: "Distributed Storage Engine",
          connections: ["backpressure-controller"],
        },
        {
          id: "backpressure-controller",
          label: "Adaptive Backpressure Flow",
          type: "feedback",
          description: "Monitors downstream queue lag and dynamically throttles upstream client producers.",
          substrate: "TCP Flow Control / Reactive Streams",
          connections: ["ingress-gw"],
        },
        {
          id: "read-api",
          label: "CQRS Query Projection API",
          type: "output",
          description: "Serves client reads directly from materialized views with sub-5ms P99 latency guarantees.",
          substrate: "Next.js / Go Microservices",
          connections: [],
        },
      ];

    case "quant-trading":
      return [
        {
          id: "market-feed",
          label: "Market Data WebSocket Feed",
          type: "input",
          description: "Ultra-low latency UDP/WebSocket ingest parsing Level-2/3 tick books and executed trade prints.",
          substrate: "FPGA / Kernel Bypass NIC",
          connections: ["orderbook-reconstructor"],
        },
        {
          id: "orderbook-reconstructor",
          label: "Limit Order Book Reconstructor",
          type: "transducer",
          description: "Maintains real-time bid/ask depth, calculates micro-price, and evaluates order queue dynamics.",
          substrate: "C++ In-Memory Book",
          connections: ["alpha-engine", "vol-estimator"],
        },
        {
          id: "alpha-engine",
          label: "Kalman Cointegration Filter",
          type: "processor",
          description: "Estimates instantaneous dynamic hedge ratio (beta) and detects statistical mean-reversion spreads.",
          substrate: "Statistical Quant Engine",
          connections: ["risk-controller"],
        },
        {
          id: "vol-estimator",
          label: "GARCH / VPIN Volatility Model",
          type: "processor",
          description: "Measures order flow toxicity and regime changes to widen execution spreads in volatile spikes.",
          substrate: "Real-Time Volatility Surface",
          connections: ["risk-controller"],
        },
        {
          id: "risk-controller",
          label: "Pre-Trade Risk & Drawdown Guard",
          type: "feedback",
          description: "Enforces max portfolio VaR, per-asset gross exposure caps, and hard circuit breakers.",
          substrate: "Deterministic Risk Engine",
          connections: ["smart-order-router"],
        },
        {
          id: "smart-order-router",
          label: "Smart Order Router (SOR)",
          type: "output",
          description: "Splits parent orders across liquidity venues using TWAP/VWAP to minimize adverse price impact.",
          substrate: "FIX Protocol Gateway",
          connections: [],
        },
      ];

    default:
      // Fallback biological or generic
      return [
        {
          id: "node-1",
          label: "Signal Transducer",
          type: "input",
          description: `Ingestion interface for ${substrateFocus} processing computational stimuli.`,
          substrate: substrateFocus,
          connections: ["node-2", "node-3"],
        },
        {
          id: "node-2",
          label: "Weight & State Processor",
          type: "processor",
          description: "Core computational transformation matrix executing adaptive state transitions.",
          substrate: substrateFocus,
          connections: ["node-4", "node-5"],
        },
        {
          id: "node-3",
          label: "Threshold Logic Gate",
          type: "processor",
          description: "Non-linear activation layer regulating propagation and filtering noise.",
          substrate: substrateFocus,
          connections: ["node-4"],
        },
        {
          id: "node-4",
          label: "State Memory Register",
          type: "memory",
          description: "Persistent memory substrate preserving internal states across operational cycles.",
          substrate: substrateFocus,
          connections: ["node-6"],
        },
        {
          id: "node-5",
          label: "Adaptive Feedback Loop",
          type: "feedback",
          description: "Dynamic feedback loop regulating systemic equilibrium and error correction.",
          substrate: substrateFocus,
          connections: ["node-2"],
        },
        {
          id: "node-6",
          label: "Output Channel",
          type: "output",
          description: "Terminal output conveying calculated computational vectors to downstream consumers.",
          substrate: substrateFocus,
          connections: [],
        },
      ];
  }
}

function generateDomainMetrics(domain: DomainCategory, gen: number) {
  switch (domain) {
    case "codebase-meta":
      return {
        m2: `${Math.min(96, 75 + gen * 3.5).toFixed(1)}% Decoupled`,
        m3: `${Math.max(2.1, 5.8 - gen * 0.6).toFixed(1)} Cyclomatic Avg`,
        m4: `${Math.min(99.9, 94.0 + gen * 1.1).toFixed(1)}% Resilience`,
      };
    case "software-architecture":
      return {
        m2: `${(2.4 + gen * 1.8).toFixed(1)}M events/sec`,
        m3: `${Math.max(1.8, 12.4 - gen * 1.6).toFixed(1)}ms P99`,
        m4: `N-${Math.min(5, 1 + Math.floor(gen / 2))} Fault Tolerant`,
      };
    case "quant-trading":
      return {
        m2: `${(1.6 + gen * 0.35).toFixed(2)} Sharpe`,
        m3: `${Math.max(2.8, 8.5 - gen * 0.9).toFixed(1)}% Max Drawdown`,
        m4: `${Math.max(0.4, 2.8 - gen * 0.4).toFixed(2)} bps Slippage`,
      };
    case "aerospace-physics":
      return {
        m2: `${(62 + gen * 4).toFixed(1)}% Mass Fraction`,
        m3: `±${Math.max(4.2, 18.0 - gen * 2.3).toFixed(1)}°C Delta-T`,
        m4: `${2800 + gen * 220}s Isp`,
      };
    case "game-balancer":
      return {
        m2: `${(49.8 + (Math.sin(gen) * 0.8)).toFixed(1)}% Win Symmetry`,
        m3: `${3 + Math.floor(gen * 0.8)} Viable Counters`,
        m4: `${(0.98 + (Math.cos(gen) * 0.04)).toFixed(2)} Sink/Faucet`,
      };
    case "governance-tokenomics":
      return {
        m2: `$${(24 + gen * 14)}M Attack Cost`,
        m3: `${Math.max(0.24, 0.58 - gen * 0.05).toFixed(2)} Gini Index`,
        m4: `${(44 + gen * 6)}% ve-Locked`,
      };
    case "biological-ai":
    default:
      return {
        m2: `${(1.2 * Math.pow(10, 6 + gen * 0.5)).toExponential(2)} bits/cm³`,
        m3: `${Math.max(4, 18 - gen * 2)}ms Latency`,
        m4: `${(2.8 - gen * 0.25).toFixed(2)} fJ/op`,
      };
  }
}

function generateDomainDesign(domain: DomainCategory, substrate: string, goal: string, gen: number): string {
  const cfg = DOMAIN_CONFIGS[domain] || DOMAIN_CONFIGS["codebase-meta"];

  return `### 1. System Architecture Blueprint (Generation ${gen})
Domain: **${cfg.name}**
Sub-Focus: **${substrate}**
Design Directive: *${goal.slice(0, 140)}...*

#### Structural Overview
The evolved architectural framework resolves structural coupling and enforces modular boundaries. In Generation ${gen}, the architecture introduces dedicated isolation layers between input ingestion, core business state processing, and downstream client projections.

#### 2. Information Flow & Transformation Topologies
- **Ingestion & Validation:** Requests and data streams enter through verified interface gateways with schema boundary checks.
- **Transformation Pipeline:** Processing elements operate with explicit state immutability, minimizing side effects.
- **Latency & Throughput Budget:** Optimizations in this generation reduce pipeline overhead by approximately ~${14 + gen * 5}%.

#### 3. Fault-Tolerance, Isolation & Invariants
- **Circuit Breaking:** Upstream callers employ backpressure regulation to prevent cascade collapse.
- **State Resilience:** Memory stores and caches maintain deterministic checkpointing for zero-data-loss recovery.
- **Error Handling:** Fallback synthesis layers ensure the system continues functioning even during third-party dependency outages.

#### 4. Evolutionary Progress over Gen ${Math.max(1, gen - 1)}
- Consolidated redundant interface types to eliminate duplicate schemas.
- Refactored high-cardinality state variables into memoized selectors.
- Strengthened verification invariants against edge-case anomalies.`;
}

function generateDomainQuestions(domain: DomainCategory, gen: number): string[] {
  switch (domain) {
    case "codebase-meta":
      return [
        "How can component re-renders be further reduced by splitting the top-level loopState into distinct Zustand or context slices?",
        "What is the optimal chunking strategy to keep Next.js standalone bundle sizes below 150KB per route?",
        "Can the simulation synthesizer be dynamically hydrated from OpenAPI schemas to maintain 100% type parity?",
      ];
    case "software-architecture":
      return [
        "What are the network partition recovery guarantees when a Raft leader disconnects during an active commit flush?",
        "How will cross-region data replication lag affect read-after-write consistency in multi-master topologies?",
        "Can zero-copy socket transfers be achieved across encrypted mTLS boundaries without CPU penalty?",
      ];
    case "quant-trading":
      return [
        "How does the Kalman filter's dynamic beta adjustment perform during sudden liquidity dry-ups or exchange halts?",
        "What is the maximum asset capacity before market impact outpaces alpha decay in this timeframe?",
        "Can adverse selection risk be minimized by incorporating order flow imbalance (OFI) metrics?",
      ];
    default:
      return [
        "What are the boundary edge cases under maximum systemic stress?",
        "How can feedback loop latency be reduced without compromising state convergence?",
        "What is the long-term degradation rate of the memory register across 10,000 cycles?",
      ];
  }
}
