import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'Biological AI Design Studio | Recursive Bio-Computing Engine',
  description: 'Recursive self-improving biological AI design engine powered by Gemini. Architectural modeling of synthetic biological computing systems, organoid processors, and cellular gene networks.',
  openGraph: {
    title: 'Biological AI Design Studio | Recursive Bio-Computing Engine',
    description: 'Recursive self-improving biological AI design engine powered by Gemini. Architectural modeling of synthetic biological computing systems, organoid processors, and cellular gene networks.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Biological AI Design Studio | Recursive Bio-Computing Engine',
    description: 'Recursive self-improving biological AI design engine powered by Gemini.',
  },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className="dark">
      <body className="bg-slate-950 text-slate-100 min-h-screen antialiased font-sans selection:bg-teal-500/30 selection:text-teal-200" suppressHydrationWarning>
        {children}
      </body>
    </html>
  );
}
