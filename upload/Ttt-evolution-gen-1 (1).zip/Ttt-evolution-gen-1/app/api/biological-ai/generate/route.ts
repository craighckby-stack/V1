import { NextRequest, NextResponse } from "next/server";
import { getGeminiClient } from "@/lib/gemini";
import { synthesizeGenerationResult } from "@/lib/simulationSynthesizer";
import { DOMAIN_CONFIGS } from "@/lib/presetGoals";
import { DomainCategory } from "@/lib/types";
import { Type } from "@google/genai";

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const {
      domain = "biological-ai" as DomainCategory,
      goal,
      currentDesign,
      generation = 1,
      substrateFocus = "Default Substrate",
      model: requestedModel = "gemini-3.8-flash",
      forceSimulation = false,
    } = body;

    if (!goal || typeof goal !== "string") {
      return NextResponse.json(
        { error: "A valid high-level goal prompt is required." },
        { status: 400 }
      );
    }

    const domainConfig = DOMAIN_CONFIGS[domain as DomainCategory] || DOMAIN_CONFIGS["biological-ai"];

    // Direct simulation mode request
    if (forceSimulation) {
      const synthesized = synthesizeGenerationResult({
        domain: domain as DomainCategory,
        goal,
        currentDesign,
        generation: Number(generation),
        substrateFocus,
      });
      return NextResponse.json({
        ...synthesized,
        usedModel: "simulated-engine",
        isSimulationFallback: true,
      });
    }

    let responseText: string | undefined = undefined;
    let usedModel = requestedModel;

    // Check if API key is present
    if (process.env.GEMINI_API_KEY) {
      const ai = getGeminiClient();
      const userMessage = `Current Generation Cycle: ${generation}
Domain Category: ${domainConfig.name}
Sub-Focus Archetype: ${substrateFocus}

OVERALL GOAL / PROMPT:
${goal}

CURRENT ARCHITECTURAL DESIGN BASELINE:
${currentDesign || "No design baseline yet. This is Generation 1 initialization."}

Perform a full cycle of the recursive optimization loop (Scan -> Analyze -> Mutate -> Verify -> Decide -> Map Nodes).
Respond strictly in JSON matching the required schema.`;

      const candidateModels = Array.from(
        new Set([requestedModel, "gemini-flash-latest", "gemini-3.1-flash-lite"])
      );

      for (const candidateModel of candidateModels) {
        try {
          const response = await ai.models.generateContent({
            model: candidateModel,
            contents: [
              { text: domainConfig.systemPrompt },
              { text: userMessage }
            ],
            config: {
              responseMimeType: "application/json",
              responseSchema: {
                type: Type.OBJECT,
                properties: {
                  analysis: {
                    type: Type.STRING,
                    description: "Clear analysis of current design against goal.",
                  },
                  mutated_design: {
                    type: Type.STRING,
                    description: "Full evolved architectural specification in Markdown format.",
                  },
                  verification: {
                    type: Type.STRING,
                    description: "Assessment of theoretical coherence and constraints.",
                  },
                  decision: {
                    type: Type.STRING,
                    description: "Must be 'continue', 'stop', or 'pivot'.",
                  },
                  reason: {
                    type: Type.STRING,
                    description: "Concise justification for decision.",
                  },
                  open_questions: {
                    type: Type.ARRAY,
                    items: { type: Type.STRING },
                    description: "List of 3 to 5 crucial open research & engineering questions.",
                  },
                  key_metrics: {
                    type: Type.OBJECT,
                    properties: {
                      coherenceScore: { type: Type.NUMBER },
                      metricTwoValue: { type: Type.STRING, description: "Dynamic metric 2 value" },
                      metricThreeValue: { type: Type.STRING, description: "Dynamic metric 3 value" },
                      metricFourValue: { type: Type.STRING, description: "Dynamic metric 4 value" },
                      plasticityIndex: { type: Type.NUMBER },
                    },
                    required: [
                      "coherenceScore",
                      "metricTwoValue",
                      "metricThreeValue",
                      "metricFourValue",
                      "plasticityIndex",
                    ],
                  },
                  graph_nodes: {
                    type: Type.ARRAY,
                    items: {
                      type: Type.OBJECT,
                      properties: {
                        id: { type: Type.STRING },
                        label: { type: Type.STRING },
                        type: {
                          type: Type.STRING,
                          description: "One of: 'input', 'transducer', 'processor', 'memory', 'output', 'feedback', 'service', 'module'",
                        },
                        description: { type: Type.STRING },
                        substrate: { type: Type.STRING },
                        connections: {
                          type: Type.ARRAY,
                          items: { type: Type.STRING },
                        },
                      },
                      required: ["id", "label", "type", "description", "substrate", "connections"],
                    },
                  },
                },
                required: [
                  "analysis",
                  "mutated_design",
                  "verification",
                  "decision",
                  "reason",
                  "open_questions",
                  "key_metrics",
                  "graph_nodes",
                ],
              },
            },
          });

          if (response.text) {
            responseText = response.text;
            usedModel = candidateModel;
            break;
          }
        } catch (err: any) {
          console.warn(`Live model ${candidateModel} call failed:`, err?.message || err);
        }
      }
    }

    if (responseText) {
      try {
        const data = JSON.parse(responseText);
        let decision = (data.decision || "continue").toLowerCase();
        if (!["continue", "stop", "pivot"].includes(decision)) {
          decision = "continue";
        }

        return NextResponse.json({
          generation: Number(generation),
          timestamp: new Date().toISOString(),
          domain: domain as DomainCategory,
          usedModel,
          isSimulationFallback: false,
          analysis: data.analysis || "Analysis completed.",
          mutated_design: data.mutated_design || "No design updated.",
          verification: data.verification || "Verification complete.",
          decision: decision as "continue" | "stop" | "pivot",
          reason: data.reason || "",
          open_questions: Array.isArray(data.open_questions) ? data.open_questions : [],
          graph_nodes: Array.isArray(data.graph_nodes) ? data.graph_nodes : [],
          key_metrics: {
            coherenceScore: data.key_metrics?.coherenceScore ?? 75,
            metricTwoValue: data.key_metrics?.metricTwoValue ?? "Stable",
            metricThreeValue: data.key_metrics?.metricThreeValue ?? "Low",
            metricFourValue: data.key_metrics?.metricFourValue ?? "Optimal",
            plasticityIndex: data.key_metrics?.plasticityIndex ?? 80,
          },
        });
      } catch (e) {
        console.warn("Error parsing Gemini JSON response, falling back to synthesizer.");
      }
    }

    // High-fidelity domain-aware synthesis fallback
    const synthesized = synthesizeGenerationResult({
      domain: domain as DomainCategory,
      goal,
      currentDesign,
      generation: Number(generation),
      substrateFocus,
    });

    return NextResponse.json({
      ...synthesized,
      usedModel: "simulated-engine-fallback",
      isSimulationFallback: true,
    });
  } catch (error: any) {
    console.error("Error in Recursive Design generation API:", error);
    return NextResponse.json(
      { error: error?.message || "Failed to execute evolution step." },
      { status: 500 }
    );
  }
}
