const TOKEN = process.env.GITHUB_TOKEN || "";
const REPO = "craighckby-stack/Test-1";

async function checkRepo(path = "") {
  try {
    const res = await fetch(`https://api.github.com/repos/${REPO}/contents/${path}`, {
      headers: { Authorization: `token ${TOKEN}` }
    });
    
    if (!res.ok) {
      console.error(`Failed to fetch ${path}:`, await res.text());
      return;
    }

    const data = await res.json();
    if (Array.isArray(data)) {
      console.log(`\n--- DIRECTORY: ${path || 'root'} ---`);
      for (const item of data) {
        console.log(`${item.type === 'dir' ? '[DIR]' : '[FILE]'} ${item.path}`);
        if (item.type === 'dir' && (path === "" || path === "GACR")) {
           // Recursively check some dirs
           await checkRepo(item.path);
        }
      }
    } else {
      console.log(`\n--- FILE: ${data.path} ---`);
      const content = Buffer.from(data.content, 'base64').toString('utf-8');
      console.log(`Content Length: ${content.length}`);
      console.log(`First 200 chars: ${content.substring(0, 200)}...`);
      
      // Check for generic template
      if (content.includes("class Config") && content.includes("static get staticConfig()")) {
        console.log("⚠️ WARNING: This file looks like the generic NEXUS_CORE_TEMPLATE.");
      }
      
      // Check for markdown blocks
      if (content.includes("```")) {
        console.log("⚠️ WARNING: This file contains markdown code blocks.");
      }
    }
  } catch (err) {
    console.error(err);
  }
}

// Check root and some specific files from the logs
async function run() {
  await checkRepo("");
  await checkRepo("GACR/verification/HETM_Verifier.py");
  await checkRepo("GACR/schemas/cmrSchema.json");
}

run();
