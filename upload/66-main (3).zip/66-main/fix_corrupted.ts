const TOKEN = process.env.GITHUB_TOKEN || "";
const REPO = "craighckby-stack/Test-1";
const FILE = "GACR/verification/HETM_Verifier.py";

function sanitizeMutation(text) {
  let cleaned = text.replace(/```[a-z]*\n|```/gi, "").trim();
  
  // Remove common AI headers if they leaked
  const headers = [
    "VOTE:",
    "SOURCE DNA SIGNATURE:",
    "CHAINED CONTEXT:",
    "TARGET FILE:",
    "ROUND:",
    "SATURATION GUIDELINES:",
    "CURRENT CODE:",
    "MUTATED CODE:"
  ];
  
  for (const header of headers) {
    if (cleaned.includes(header)) {
      const parts = cleaned.split(header);
      cleaned = parts[parts.length - 1].trim();
    }
  }

  const fillerPatterns = [
    /^To execute the mutation protocol,.*?\n/is,
    /^Below is the adapted code,.*?\n/is,
    /^Here is the mutated code.*?\n/is,
    /^I have updated the file.*?\n/is,
    /^Based on the provided context.*?\n/is,
    /^integrated the DALEK CAAN architecture.*?\n/is
  ];
  for (const pattern of fillerPatterns) {
    cleaned = cleaned.replace(pattern, "").trim();
  }
  return cleaned;
}

async function fixFile(path) {
  const res = await fetch(`https://api.github.com/repos/${REPO}/contents/${path}`, {
    headers: { Authorization: `token ${TOKEN}` }
  });
  if (res.ok) {
    const data = await res.json();
    const content = Buffer.from(data.content, 'base64').toString('utf-8');
    const sha = data.sha;
    
    const sanitized = sanitizeMutation(content);
    
    if (sanitized !== content) {
      console.log(`Sanitizing ${path}...`);
      const pushRes = await fetch(`https://api.github.com/repos/${REPO}/contents/${path}`, {
        method: "PUT",
        headers: {
          Authorization: `token ${TOKEN}`,
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          message: "SYSTEM: Purging AI conversational filler from corrupted file",
          content: Buffer.from(sanitized).toString('base64'),
          sha
        })
      });
      if (pushRes.ok) {
        console.log(`✅ ${path} fixed successfully.`);
      } else {
        console.error(`Failed to fix ${path}:`, await pushRes.text());
      }
    } else {
      console.log(`File ${path} is already clean.`);
    }
  }
}

async function run() {
  await fixFile("GACR/verification/HETM_Verifier.py");
  await fixFile("config/ErrorCodes.js");
}

run();
