const TOKEN = process.env.GITHUB_TOKEN || "";
const REPO = "craighckby-stack/Test-1";

async function fetchAllFiles(path = "") {
  const res = await fetch(`https://api.github.com/repos/${REPO}/contents/${path}`, {
    headers: { Authorization: `token ${TOKEN}` }
  });
  if (!res.ok) return [];
  const items = await res.json();
  let files = [];
  for (const item of items) {
    if (item.type === 'dir') {
      files = files.concat(await fetchAllFiles(item.path));
    } else if (item.type === 'file' && !item.path.startsWith('meta_') && !item.path.endsWith('.json')) {
      files.push(item);
    }
  }
  return files;
}

async function scanForCorruption() {
  console.log("Scanning Test-1 for AI conversational corruption...");
  const files = await fetchAllFiles("");
  console.log(`Found ${files.length} non-meta, non-json files to check.`);

  const corruptedFiles = [];
  
  // Check a sample or all if not too many
  const limit = 100; 
  const sample = files.slice(0, limit);

  for (const file of sample) {
    const res = await fetch(`https://api.github.com/repos/${REPO}/contents/${file.path}`, {
      headers: { Authorization: `token ${TOKEN}` }
    });
    if (res.ok) {
      const data = await res.json();
      const content = Buffer.from(data.content, 'base64').toString('utf-8');
      
      const fillerPatterns = [
        "To execute the mutation protocol",
        "Below is the adapted code",
        "Here is the mutated code",
        "I have updated the file",
        "Based on the provided context",
        "integrated the DALEK CAAN architecture"
      ];

      const found = fillerPatterns.find(p => content.includes(p));
      if (found) {
        console.log(`❌ CORRUPTED: ${file.path} (Found: "${found}")`);
        corruptedFiles.push(file.path);
      } else {
        // console.log(`✅ CLEAN: ${file.path}`);
      }
    }
  }

  console.log(`\nScan complete. Corrupted files found in sample: ${corruptedFiles.length}/${sample.length}`);
  if (corruptedFiles.length > 0) {
    console.log("Corrupted files list:", corruptedFiles);
  }
}

scanForCorruption();
