# Architecture Helper Pipeline — Comprehensive System Audit & Rectification Plan

Fix and polish the Architecture Helper Pipeline to address all structural flaws, false positives, governor lockouts, and UI desynchronizations revealed in the empirical audit, while updating repository documentation and app branding.

## User Review & Critical Decisions

> [!IMPORTANT]
> The audit highlighted critical bottlenecks that prevent continuous repository refactoring and produce spurious rejections. This plan rectifies all root causes identified in the user's test suite while aligning metadata and adding an in-app Documentation viewer.

- **Confirmed Decision 1**: Apply the provided empirical documentation to `/README.md` and introduce an in-app "System Architecture & Audit" documentation tab for immediate in-session reference.
- **Confirmed Decision 2**: Rename app entry point (`index.html`), application header, and `metadata.json` from legacy `NEXUS README ENHANCER` to `Architecture Helper Pipeline`.
- **Confirmed Decision 3**: Fix the 15-cycle governor lockout by resetting cycle counts per batch session and introducing a manual "Reset Governor" trigger in the UI and runner.
- **Confirmed Decision 4**: Fix small-file AST structural drift by stripping cosmetic header comments from length delta calculations before applying drift thresholds.
- **Confirmed Decision 5**: Fix regex false positives in `debate.ts` and `server.ts` by checking for exact credential tokens (`\bsk-[A-Za-z0-9]{20,}\b`) and true dynamic code execution (`new\s+Function\(`, `\beval\(`) rather than ordinary `sk-` substrings and `function(...)` declarations.

---

## 1. Overview & Core Concept

- **What It Does**: A developer workbench and automated code mutation pipeline that ingests repository files, evaluates security sanitization (Shannon entropy & credential scrubbing), executes AST structural preservation checks, and dispatches verified batches to GitHub.
- **Target Audience**: Software engineers and system architects auditing and refactoring multi-file repositories with deterministic, rule-based verification.
- **Key Value**: Delivers transparent, reliable code refactoring without false rejections, arbitrary execution caps, or broken UI controls.

---

## 2. User Experience & Visual Design

- **Layout Structure**:
  - **Top Navigation Bar**: Brand identity (`Architecture Helper Pipeline v4.0`), active GitHub connection status badge, live Governor Cycle counter (`Cycles: N/15`), Sound Toggle, Terminal Modal, AST Diff Modal, and Documentation quick-launch.
  - **Repository & Batch Bar**: Target repository selector, branch inputs, "Scan" button, file filter input, and clear selection toggles (`Code Files Only`, `Select All`, `Deselect All`).
  - **Tabbed Dashboard**:
    1. *Single Pipeline Helper*: Side-by-side original vs. evolved code editor, stage progression cards (0 to 5), and detailed execution report.
    2. *Batch Mutated Files*: High-density data grid displaying per-file status, mutation diff sizes, AST scores, and "Batch Commit All" action.
    3. *System Architecture & Audit (NEW)*: Native, beautifully styled in-app viewer of the verified architectural documentation and pipeline specifications.
    4. *Code Review Helper*: Interactive dual-perspective review sandbox with refined regex checks.
    5. *Governance & Verification Helper*: Refactoring loop tied dynamically to the active file, entropy inspector, and memory index.
    6. *Modular Agent Engines Helper*: Catalog of 15 clean-room agent specifications.
    7. *Execution Logs Helper*: Session logs with copy and clear utilities.

- **Design Tokens & Aesthetic Direction**:
  - *Theme*: Dark developer workbench (`bg-[#09090b]`, flat single-elevation panels `bg-zinc-900/60`, borders `border-zinc-800/80`).
  - *Typography*: Monospace `JetBrains Mono` for code, counters, and hashes; clean `Plus Jakarta Sans` for labels and controls. Tabular numerals (`tabular-nums`) across all status grids.
  - *Zero-Pill Discipline*: Unboxed quiet text metadata separated by subtle typographical dividers (`·`). Functional segmented buttons for filter controls.

---

## 3. Key Product Decisions & Trade-Offs

- **Decision 1: Cycle Management & Governor Reset**
  - *Chosen Approach*: Automatically reset the `SelfStoppingGovernor` cycle counter at the start of each batch run and when switching active repositories. Additionally provide a manual "Reset Governor" button in the Governance tab and top bar.
  - *Why*: Eliminates the hard 15-file limit that causes batch operations on large repositories to halt after file 14.
  - *Alternatives Considered*: Removing the governor entirely was rejected because cycle limits protect against runaway infinite loops.

- **Decision 2: Comment-Agnostic AST Structural Drift Calculation**
  - *Chosen Approach*: In `evaluateAstDiff` (`src/core/ast-diff-gate.ts`), calculate structural length drift against code normalized without the prepended comment header and synthetic contract boilerplate.
  - *Why*: Small files (e.g. 70–400 characters) were automatically rejected because prepending a 300-character comment header represented a >60% length increase, falsely triggering `AST_STRUCTURAL_DRIFT`.

- **Decision 3: Targeted Credential & Eval Detection Regexes**
  - *Chosen Approach*: Replace substring check `includes('sk-')` with word-bounded token format `/\bsk-[A-Za-z0-9]{20,}\b/i`. Replace `includes('function(')` with specific dynamic execution patterns `/\bnew\s+Function\s*\(|\beval\s*\(/`.
  - *Why*: Harmless variable names, comments containing `// task-runner`, and standard JavaScript function declarations `arr.map(function(x){})` previously caused false `REQUIRES_REWRITE` verdicts.

- **Decision 4: Reactive AST Diff Modal**
  - *Chosen Approach*: Convert `AstDiffModal` state from one-time initial evaluation to reactive `useMemo` hooks driven by props (`originalCode`, `evolvedCode`).
  - *Why*: Previously, AST diff metrics froze to the initial file on mount and never updated when switching files or viewing fresh mutation outputs.

- **Decision 5: Language-Aware Headers & Code-Only Selection**
  - *Chosen Approach*: Default auto-selection after repository scan to files with recognized code extensions (`.ts`, `.tsx`, `.js`, `.jsx`, `.py`, `.go`, `.rs`, `.css`, `.html`, `.sql`, `.sh`, `.json`). Adapt comment format (e.g. `#` for Python/Bash/YAML, `/* */` for C-like, `<!-- -->` for HTML).
  - *Why*: Injects valid comments rather than invalid syntax into non-JavaScript languages.

---

## 4. Technical Architecture & System Flow

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                          React Client (Vite 6)                              │
│                                                                             │
│  ┌───────────────────────┐   ┌───────────────────┐   ┌───────────────────┐  │
│  │ Target Repo & Branch  │──▶│ File Selection    │──▶│ Unified Pipeline  │  │
│  │ (GitHub REST API)     │   │ (Code-Only Auto)  │   │ Runner (Stages 0-5│  │
│  └───────────────────────┘   └───────────────────┘   └─────────┬─────────┘  │
│                                                                │            │
│  ┌─────────────────────────────────────────────────────────────▼─────────┐  │
│  │                        6-Stage Client Pipeline                        │  │
│  │  Stage 0: Pattern Ingestion (Keyword Scoring)                         │  │
│  │  Stage 1: Shannon Entropy Pre-Screen & Key Redaction                  │  │
│  │  Stage 2: 5-Pillar Clean-Room Reasoning Step Simulation               │  │
│  │  Stage 3: AST Diff Gate (Normalized Drift & Symbol Preservation)      │  │
│  │  Stage 4: Code Review (Accurate Secret & Dynamic Eval Regexes)        │  │
│  │  Stage 5: Convergence & Proof Hash (Governor with Batch Reset)        │  │
│  └─────────────────────────────────────────────────────────────┬─────────┘  │
│                                                                │            │
│  ┌───────────────────────┐   ┌───────────────────┐             │            │
│  │ Reactive AST Diff     │◀──│ In-App Docs Tab   │◀────────────┘            │
│  │ & Terminal Console    │   │ & Batch Committer │                          │
│  └───────────────────────┘   └─────────┬─────────┘                          │
└────────────────────────────────────────┼────────────────────────────────────┘
                                         ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                         Express Backend Server (server.ts)                  │
│                                                                             │
│  ┌───────────────────────────────┐        ┌──────────────────────────────┐  │
│  │ /api/github/batch-commit-files│───────▶│ GitHub REST API              │  │
│  │ (50MB Body Parser Limit)      │        │ (PUT /repos/:owner/:repo/    │  │
│  │ /api/github/repo-tree         │        │  contents/:path)             │  │
│  └───────────────────────────────┘        └──────────────────────────────┘  │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## 5. Verification & Testing Protocol

1. **Governor Cycle Test**: Run batch mutation over 20+ files; verify no premature `MAX_CYCLES_REACHED` halt occurs.
2. **Small File Drift Test**: Mutate a 70-character snippet and `checksum.ts` (412 characters); verify AST drift does not trigger false rejection.
3. **Regex Accuracy Test**: Verify files containing `function calculate()` and `// task-runner` pass review without triggering false positive flags.
4. **AST Modal Reactivity Test**: Open AST Diff modal across multiple mutated files; verify metrics update dynamically per file.
5. **Terminal Command Test**: Execute `help`, `pipeline`, `review`, and `ls` in the DOS console; verify clean execution.
6. **Documentation & Metadata Verification**: Verify `README.md`, `metadata.json`, and `index.html` reflect the verified name and architecture.
7. **Compilation & Lint**: Run `compile_applet` and `lint_applet` to confirm error-free execution.
