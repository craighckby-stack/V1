
import { GoogleGenAI } from "@google/genai";

const REPO = "craighckby-stack/Test-1";
const PROXY_URL = "http://localhost:3000/api/github/proxy";

async function fetchFile(path: string) {
  try {
    const res = await fetch(PROXY_URL, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ url: `https://api.github.com/repos/${REPO}/contents/${path}` })
    });
    const text = await res.text();
    try {
      const data = JSON.parse(text);
      if (data.content) {
        return Buffer.from(data.content, 'base64').toString('utf-8');
      }
    } catch (e) {
      if (text.includes("<!doctype html>")) {
        console.log(`Proxy returned HTML for ${path}.`);
      } else {
        console.log(`Failed to parse JSON for ${path}: ${text.slice(0, 100)}`);
      }
    }
  } catch (e) {
    console.error(`Network error for ${path}:`, e);
  }
  return null;
}

async function run() {
  console.log("Fetching NEXUS_LOG.txt...");
  const logs = await fetchFile("NEXUS_LOG.txt");
  if (logs) {
    console.log("--- LOGS START (FIRST 2000) ---");
    console.log(logs.slice(0, 2000));
    console.log("\n--- LOGS END (LAST 2000) ---");
    console.log(logs.slice(-2000));
  } else {
    console.log("NEXUS_LOG.txt not found.");
  }

  console.log("\nFetching MISTAKES_LEDGER.md...");
  const mistakes = await fetchFile("MISTAKES_LEDGER.md");
  if (mistakes) {
    console.log("--- MISTAKES START ---");
    console.log(mistakes.slice(-2000));
    console.log("--- MISTAKES END ---");
  }

  console.log("\nFetching grog/lessons/LESSONS.md...");
  const lessons = await fetchFile("grog/lessons/LESSONS.md");
  if (lessons) {
    console.log("--- LESSONS START ---");
    console.log(lessons.slice(-2000));
    console.log("--- LESSONS END ---");
  }
}

run().catch(console.error);
