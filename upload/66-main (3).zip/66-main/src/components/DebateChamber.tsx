/**
 * Code Review Helper Component
 * Dual-perspective code analysis: Security Reviewer vs Architecture Reviewer
 * with consensus coefficient and clear review summaries.
 */

import React, { useState } from 'react';
import { conductDebate, DebateVerdict } from '../emg/debate';
import { playDebateGong, playClickSound } from '../emg/SoundEngine';
import { Scale, RefreshCw, BookOpen, ShieldCheck, AlertCircle, FileCode, Check } from 'lucide-react';

interface DebateChamberProps {
  onApplyVerdict?: (verdict: DebateVerdict) => void;
}

export const DebateChamber: React.FC<DebateChamberProps> = ({ onApplyVerdict }) => {
  const [topic, setTopic] = useState('Verify TypeScript Strict Mode & Memory Invariants');
  const [testCode, setTestCode] = useState(`// Candidate Module
export function executeProtectedTask(token: string): Promise<boolean> {
  if (!token || token.length < 16) {
    throw new Error("Invalid credential");
  }
  return Promise.resolve(true);
}`);
  const [filePath, setFilePath] = useState('src/core/security.ts');
  const [verdict, setVerdict] = useState<DebateVerdict | null>(() => conductDebate(topic, testCode, filePath));
  const [isReviewing, setIsReviewing] = useState(false);

  const handleRunReview = () => {
    setIsReviewing(true);
    playDebateGong();

    setTimeout(() => {
      const result = conductDebate(topic, testCode, filePath);
      setVerdict(result);
      setIsReviewing(false);
      if (onApplyVerdict) onApplyVerdict(result);
    }, 350);
  };

  return (
    <div className="flex flex-col gap-5 text-sm">
      {/* Top Controls Card */}
      <div className="bg-zinc-950/80 border border-zinc-800/80 p-5 rounded-xl space-y-4 shadow-lg">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-zinc-800/80 pb-3">
          <div>
            <h2 className="text-base font-semibold text-zinc-100 flex items-center gap-2">
              <Scale className="text-amber-400" size={18} />
              Code Review Helper
            </h2>
            <p className="text-xs text-zinc-400 mt-0.5">
              Dual-perspective code analysis: Security Reviewer vs Architecture Reviewer
            </p>
          </div>
          <div className="text-xs text-zinc-400 flex items-center gap-1.5 self-start sm:self-auto font-mono">
            <span>Automated Code Review</span>
            <span aria-hidden="true">·</span>
            <span className="text-emerald-400">Rules Active</span>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-12 gap-3">
          <div className="md:col-span-8">
            <label className="text-xs font-medium text-zinc-400 block mb-1.5">
              Review Objective &amp; Target File
            </label>
            <div className="flex gap-2">
              <input
                type="text"
                value={topic}
                onChange={e => setTopic(e.target.value)}
                className="helper-input flex-1"
                placeholder="Review topic..."
              />
              <input
                type="text"
                value={filePath}
                onChange={e => setFilePath(e.target.value)}
                className="helper-input w-48 font-mono"
                placeholder="File path..."
              />
            </div>
          </div>

          <div className="md:col-span-4 flex items-end">
            <button
              onClick={() => { playClickSound(); handleRunReview(); }}
              disabled={isReviewing}
              className="w-full py-2.5 px-4 bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 border border-amber-500/30 rounded-lg font-medium text-xs flex items-center justify-center gap-2 transition-all active:scale-[0.98]"
            >
              <RefreshCw size={14} className={isReviewing ? "animate-spin" : ""} />
              {isReviewing ? "Analyzing Code..." : "Run Code Review Helper"}
            </button>
          </div>
        </div>

        <div>
          <label className="text-xs font-medium text-zinc-400 block mb-1.5">
            Candidate Code for Review
          </label>
          <textarea
            value={testCode}
            onChange={e => setTestCode(e.target.value)}
            rows={4}
            className="w-full bg-zinc-900/60 border border-zinc-800 p-3 rounded-lg text-xs font-mono text-zinc-200 focus:outline-none focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500/20 transition-all custom-scrollbar leading-relaxed"
          />
        </div>
      </div>

      {/* Summary Scorecard */}
      {verdict && (
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <div className="bg-zinc-950/70 border border-zinc-800/80 p-4 rounded-xl flex flex-col justify-between">
            <span className="text-xs font-medium text-zinc-400">Review Outcome</span>
            <div className="mt-2 flex items-center gap-2">
              {verdict.consensus === 'APPROVED' ? (
                <ShieldCheck size={18} className="text-emerald-400" />
              ) : (
                <AlertCircle size={18} className="text-rose-400" />
              )}
              <span className={`text-base font-bold tracking-tight ${
                verdict.consensus === 'APPROVED' ? 'text-emerald-400' :
                verdict.consensus === 'CONDITIONAL_APPROVAL' ? 'text-amber-400' : 'text-rose-400'
              }`}>
                {verdict.consensus}
              </span>
            </div>
            <p className="text-[11px] text-zinc-500 mt-1">Validated against security and AST criteria</p>
          </div>

          <div className="bg-zinc-950/70 border border-zinc-800/80 p-4 rounded-xl flex flex-col justify-between">
            <span className="text-xs font-medium text-zinc-400">Consensus Score</span>
            <div className="mt-2">
              <span className="text-xl font-bold text-cyan-400 font-mono">
                {(verdict.consensusCoefficient * 100).toFixed(0)}%
              </span>
              <div className="w-full bg-zinc-800 h-1.5 mt-2 rounded-full overflow-hidden">
                <div
                  className="bg-cyan-400 h-full transition-all duration-500"
                  style={{ width: `${verdict.consensusCoefficient * 100}%` }}
                />
              </div>
            </div>
          </div>

          <div className="bg-zinc-950/70 border border-zinc-800/80 p-4 rounded-xl flex flex-col justify-between">
            <span className="text-xs font-medium text-zinc-400">Friction Index</span>
            <div className="mt-2">
              <span className="text-xl font-bold text-amber-400 font-mono">
                {(verdict.cognitiveFriction * 100).toFixed(0)}%
              </span>
              <div className="w-full bg-zinc-800 h-1.5 mt-2 rounded-full overflow-hidden">
                <div
                  className="bg-amber-400 h-full transition-all duration-500"
                  style={{ width: `${verdict.cognitiveFriction * 100}%` }}
                />
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Structured Dialogue Stream */}
      {verdict && (
        <div className="space-y-3">
          {verdict.arguments.map((arg, idx) => {
            const isSecurity = arg.speaker === 'security';
            const isArch = arg.speaker === 'architecture';

            const borderClass = isSecurity ? 'border-rose-900/40 bg-rose-950/10' :
                                isArch ? 'border-cyan-900/40 bg-cyan-950/10' :
                                'border-amber-900/40 bg-amber-950/15';

            const accentColor = isSecurity ? 'text-rose-400' :
                                isArch ? 'text-cyan-400' :
                                'text-amber-400';

            return (
              <div key={idx} className={`p-4 rounded-xl border ${borderClass} transition-all space-y-2`}>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="text-lg" aria-hidden="true">{arg.avatar}</span>
                    <span className={`font-semibold text-xs ${accentColor}`}>
                      {arg.speakerName}
                    </span>
                  </div>
                  <span className="text-xs font-mono text-zinc-400 font-medium">
                    Stance: <span className={accentColor}>{arg.stance}</span>
                  </span>
                </div>

                <p className="text-zinc-200 text-xs leading-relaxed pl-7">
                  {arg.statement}
                </p>

                {arg.citations && arg.citations.length > 0 && (
                  <div className="flex items-center gap-2 pl-7 pt-1 text-[11px] text-zinc-400">
                    <BookOpen size={12} className="text-zinc-500" />
                    <span>Guidelines Checked: {arg.citations.join(' · ')}</span>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
