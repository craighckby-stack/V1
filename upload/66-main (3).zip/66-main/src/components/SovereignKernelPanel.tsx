/**
 * Security & Verification Helper Dashboard
 * Subsystems for automated refactoring cycles, entropy sanitization, and pattern memory.
 */

import React, { useState } from 'react';
import { executeEmgTriLoopCycle, TriLoopCycleResult } from '../emg/tri-loop';
import { sanitizeAndGovern, calculateShannonEntropy, SecuritySanitizerResult } from '../emg/sanitizer';
import { emgRagInstance, VectorEntry } from '../emg/emg-rag';
import { playClickSound, playChirpSound, playSuccessSound, playErrorSound, playLaserSound } from '../emg/SoundEngine';
import { Shield, Database, Activity, CheckCircle, AlertTriangle, Lock, RefreshCw, Zap, Plus } from 'lucide-react';

type SubTabType = 'triloop' | 'sanitizer' | 'rag' | 'sandbox';

interface SovereignKernelPanelProps {
  activeFile?: { path: string; content?: string };
  onResetGovernor?: () => void;
  governorCycles?: { current: number; max: number };
}

export const SovereignKernelPanel: React.FC<SovereignKernelPanelProps> = ({
  activeFile,
  onResetGovernor,
  governorCycles = { current: 0, max: 15 },
}) => {
  const [activeSubTab, setActiveSubTab] = useState<SubTabType>('triloop');
  const [testFilePath, setTestFilePath] = useState(activeFile?.path || 'src/core/checksum.ts');
  const [testCode, setTestCode] = useState(
    activeFile?.content ||
`export function initializeCredentials() {
  const apiKey = "AIzaSyD-sample-fake-key-1234567890abc";
  return { status: "initialized", key: apiKey };
}`
  );
  const [isProcessing, setIsProcessing] = useState(false);
  const [lastCycleResult, setLastCycleResult] = useState<TriLoopCycleResult | null>(null);
  const [sanitizerResult, setSanitizerResult] = useState<SecuritySanitizerResult | null>(null);
  const [ragVectors, setRagVectors] = useState<VectorEntry[]>(() => emgRagInstance.getAll());
  const [newVectorContent, setNewVectorContent] = useState('');

  const handleRunTriLoop = async () => {
    setIsProcessing(true);
    playLaserSound();

    try {
      const originalCode = `export function initializeCredentials() {\n  return { status: "pending" };\n}`;
      const result = await executeEmgTriLoopCycle(testFilePath, originalCode, testCode);
      setLastCycleResult(result);
      setRagVectors(emgRagInstance.getAll());

      if (result.status === 'CONVERGED' || result.status === 'SANITIZED_APPLIED') {
        playSuccessSound();
      } else {
        playErrorSound();
      }
    } catch {
      playErrorSound();
    } finally {
      setIsProcessing(false);
    }
  };

  const handleTestSanitizer = () => {
    playChirpSound();
    const result = sanitizeAndGovern(testCode);
    setSanitizerResult(result);
  };

  const handleAddVector = () => {
    if (!newVectorContent.trim()) return;
    playClickSound();
    emgRagInstance.addEntry({
      provenance: 'clean',
      trust: 'high',
      filePath: testFilePath,
      content: newVectorContent.trim(),
      diagnosis: 'Pattern manually instantiated into memory bank',
    });
    setRagVectors(emgRagInstance.getAll());
    setNewVectorContent('');
  };

  return (
    <div className="flex flex-col gap-5 text-sm">
      {/* Navigation Tabs */}
      <div className="flex flex-wrap gap-1.5 p-1 bg-zinc-950/80 border border-zinc-800/80 rounded-xl">
        <button
          onClick={() => { playClickSound(); setActiveSubTab('triloop'); }}
          className={`px-3.5 py-2 text-xs font-medium rounded-lg transition-all flex items-center gap-2 ${
            activeSubTab === 'triloop'
              ? 'bg-zinc-800 text-amber-300 shadow-sm border border-zinc-700/60'
              : 'text-zinc-400 hover:text-zinc-200 hover:bg-zinc-900/40'
          }`}
        >
          <Activity size={14} className="text-amber-400" />
          <span>Refactoring Loop</span>
        </button>

        <button
          onClick={() => { playClickSound(); setActiveSubTab('sanitizer'); }}
          className={`px-3.5 py-2 text-xs font-medium rounded-lg transition-all flex items-center gap-2 ${
            activeSubTab === 'sanitizer'
              ? 'bg-zinc-800 text-rose-300 shadow-sm border border-zinc-700/60'
              : 'text-zinc-400 hover:text-zinc-200 hover:bg-zinc-900/40'
          }`}
        >
          <Lock size={14} className="text-rose-400" />
          <span>Entropy Sanitizer</span>
        </button>

        <button
          onClick={() => { playClickSound(); setActiveSubTab('rag'); }}
          className={`px-3.5 py-2 text-xs font-medium rounded-lg transition-all flex items-center gap-2 ${
            activeSubTab === 'rag'
              ? 'bg-zinc-800 text-cyan-300 shadow-sm border border-zinc-700/60'
              : 'text-zinc-400 hover:text-zinc-200 hover:bg-zinc-900/40'
          }`}
        >
          <Database size={14} className="text-cyan-400" />
          <span>Memory Index ({ragVectors.length})</span>
        </button>

        <button
          onClick={() => { playClickSound(); setActiveSubTab('sandbox'); }}
          className={`px-3.5 py-2 text-xs font-medium rounded-lg transition-all flex items-center gap-2 ${
            activeSubTab === 'sandbox'
              ? 'bg-zinc-800 text-violet-300 shadow-sm border border-zinc-700/60'
              : 'text-zinc-400 hover:text-zinc-200 hover:bg-zinc-900/40'
          }`}
        >
          <Shield size={14} className="text-violet-400" />
          <span>Memory Sandbox</span>
        </button>
      </div>

      {/* Subtab 1: Refactoring Loop */}
      {activeSubTab === 'triloop' && (
        <div className="space-y-4">
          <div className="bg-zinc-950/80 border border-zinc-800/80 p-5 rounded-xl space-y-4 shadow-lg">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-zinc-800/80 pb-3">
              <div>
                <h3 className="text-base font-semibold text-zinc-100 flex items-center gap-2">
                  <Zap size={16} className="text-amber-400" />
                  Automated Refactoring Loop Helper
                </h3>
                <p className="text-xs text-zinc-400 mt-0.5">
                  1. Scan &amp; Sanitize · 2. Review Check · 3. Convergence &amp; Proof Hash
                </p>
              </div>

              <div className="flex items-center gap-2">
                {activeFile && (
                  <button
                    onClick={() => {
                      playClickSound();
                      setTestFilePath(activeFile.path);
                      if (activeFile.content) setTestCode(activeFile.content);
                    }}
                    className="px-2.5 py-1.5 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 text-xs rounded-lg transition-colors border border-zinc-700/60"
                  >
                    Sync Active File ({activeFile.path.split('/').pop()})
                  </button>
                )}
                {onResetGovernor && (
                  <button
                    onClick={() => {
                      playClickSound();
                      onResetGovernor();
                    }}
                    className="px-2.5 py-1.5 bg-cyan-950/40 hover:bg-cyan-900/50 text-cyan-400 text-xs rounded-lg transition-colors border border-cyan-800/40 flex items-center gap-1.5"
                    title="Reset Governor loop cycle counter to allow fresh runs"
                  >
                    <RefreshCw size={12} />
                    <span>Reset Cycles ({governorCycles.current}/{governorCycles.max})</span>
                  </button>
                )}
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-12 gap-3">
              <div className="md:col-span-8">
                <label className="text-xs font-medium text-zinc-400 block mb-1.5">Target File Path</label>
                <input
                  type="text"
                  value={testFilePath}
                  onChange={e => setTestFilePath(e.target.value)}
                  className="helper-input font-mono"
                />
              </div>

              <div className="md:col-span-4 flex items-end">
                <button
                  onClick={handleRunTriLoop}
                  disabled={isProcessing}
                  className="w-full py-2.5 px-4 bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 border border-amber-500/30 rounded-lg font-medium text-xs flex items-center justify-center gap-2 transition-all active:scale-[0.98]"
                >
                  <RefreshCw size={14} className={isProcessing ? "animate-spin" : ""} />
                  {isProcessing ? "Running Loop..." : "Execute Refactoring Loop"}
                </button>
              </div>
            </div>

            <div>
              <label className="text-xs font-medium text-zinc-400 block mb-1.5">Candidate Code to Evolve</label>
              <textarea
                value={testCode}
                onChange={e => setTestCode(e.target.value)}
                rows={4}
                className="w-full bg-zinc-900/60 border border-zinc-800 p-3 rounded-lg text-xs font-mono text-zinc-200 focus:outline-none focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500/20 transition-all custom-scrollbar leading-relaxed"
              />
            </div>
          </div>

          {/* Outcome */}
          {lastCycleResult && (
            <div className="bg-zinc-950/80 border border-zinc-800/80 p-5 rounded-xl space-y-4 shadow-lg">
              <div className="flex items-center justify-between border-b border-zinc-800/80 pb-3">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-semibold text-zinc-300">
                    Cycle #{lastCycleResult.cycleNumber} Result:
                  </span>
                  <span className={`text-xs font-bold font-mono px-2 py-0.5 rounded-md ${
                    lastCycleResult.status === 'CONVERGED' ? 'bg-emerald-950 text-emerald-400 border border-emerald-900/50' :
                    lastCycleResult.status === 'SANITIZED_APPLIED' ? 'bg-amber-950 text-amber-400 border border-amber-900/50' :
                    'bg-rose-950 text-rose-400 border border-rose-900/50'
                  }`}>
                    {lastCycleResult.status}
                  </span>
                </div>
                {lastCycleResult.cleanCommitHash && (
                  <span className="text-xs font-mono text-emerald-400 flex items-center gap-1.5">
                    <CheckCircle size={14} /> Commit Hash: {lastCycleResult.cleanCommitHash}
                  </span>
                )}
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="bg-zinc-900/60 p-3 rounded-lg border border-zinc-800/60">
                  <span className="text-xs text-zinc-400 block">Sanitizer</span>
                  <span className={`text-sm font-semibold mt-1 block ${
                    lastCycleResult.sanitizerResult.clean ? 'text-emerald-400' : 'text-rose-400'
                  }`}>
                    {lastCycleResult.sanitizerResult.clean ? 'Verified Clean (0 Leaks)' : `Sanitized (${lastCycleResult.sanitizerResult.violations.length} tokens)`}
                  </span>
                </div>

                <div className="bg-zinc-900/60 p-3 rounded-lg border border-zinc-800/60">
                  <span className="text-xs text-zinc-400 block">AST Score</span>
                  <span className="text-sm font-semibold font-mono text-cyan-400 mt-1 block">
                    {lastCycleResult.astDiffResult.astScore} / 100
                  </span>
                </div>

                <div className="bg-zinc-900/60 p-3 rounded-lg border border-zinc-800/60">
                  <span className="text-xs text-zinc-400 block">Saturation Check</span>
                  <span className="text-sm font-semibold font-mono text-amber-400 mt-1 block">
                    {lastCycleResult.haltState ? lastCycleResult.haltState.reason : 'Active Cycle'}
                  </span>
                </div>
              </div>

              {/* Log */}
              <div className="space-y-1 bg-zinc-950 p-3 rounded-lg border border-zinc-900 font-mono text-xs text-zinc-400 max-h-40 overflow-y-auto custom-scrollbar">
                {lastCycleResult.executionLog.map((log, i) => (
                  <div key={i} className="leading-relaxed">{log}</div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {/* Subtab 2: Entropy Sanitizer */}
      {activeSubTab === 'sanitizer' && (
        <div className="bg-zinc-950/80 border border-zinc-800/80 p-5 rounded-xl space-y-4 shadow-lg">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-zinc-800/80 pb-3">
            <div>
              <h3 className="text-base font-semibold text-zinc-100 flex items-center gap-2">
                <Lock size={16} className="text-rose-400" />
                Shannon Entropy Sanitizer Helper
              </h3>
              <p className="text-xs text-zinc-400 mt-0.5">
                Evaluates character distribution entropy to trap keys before transmission
              </p>
            </div>
            <button
              onClick={handleTestSanitizer}
              className="py-2 px-4 bg-rose-500/10 hover:bg-rose-500/20 text-rose-300 border border-rose-500/30 rounded-lg text-xs font-medium transition-all"
            >
              Scan Buffer
            </button>
          </div>

          <div className="p-3 bg-zinc-900/60 border border-zinc-800/60 rounded-lg flex items-center justify-between">
            <span className="text-xs text-zinc-400">Current Code Entropy:</span>
            <span className="text-sm font-mono font-bold text-amber-400">
              {calculateShannonEntropy(testCode).toFixed(3)} bits/char
            </span>
          </div>

          {sanitizerResult && (
            <div className="space-y-3 pt-2">
              <div className="flex items-center justify-between">
                <span className="text-xs text-zinc-400">Detection Status:</span>
                <span className={`text-xs font-semibold ${sanitizerResult.clean ? 'text-emerald-400' : 'text-rose-400'}`}>
                  {sanitizerResult.errorClass}
                </span>
              </div>

              {sanitizerResult.violations.length > 0 && (
                <div className="space-y-1.5">
                  <span className="text-xs text-rose-400 font-medium block">Violations Flagged:</span>
                  {sanitizerResult.violations.map((v, i) => (
                    <div key={i} className="text-xs text-rose-300 bg-rose-950/20 p-2 rounded-lg border border-rose-900/40">
                      {v}
                    </div>
                  ))}
                </div>
              )}

              <div>
                <span className="text-xs text-zinc-400 block mb-1.5">Sanitized Output:</span>
                <pre className="bg-zinc-900/70 border border-zinc-800 p-3 rounded-lg text-xs font-mono text-zinc-200 overflow-x-auto whitespace-pre-wrap custom-scrollbar">
                  {sanitizerResult.sanitizedCode}
                </pre>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Subtab 3: Memory Index */}
      {activeSubTab === 'rag' && (
        <div className="bg-zinc-950/80 border border-zinc-800/80 p-5 rounded-xl space-y-4 shadow-lg">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-zinc-800/80 pb-3">
            <div>
              <h3 className="text-base font-semibold text-zinc-100 flex items-center gap-2">
                <Database size={16} className="text-cyan-400" />
                Pattern Memory Index Helper
              </h3>
              <p className="text-xs text-zinc-400 mt-0.5">
                Memory entries for clean patterns and failure ledger avoidance
              </p>
            </div>
          </div>

          <div className="flex gap-2">
            <input
              type="text"
              value={newVectorContent}
              onChange={e => setNewVectorContent(e.target.value)}
              placeholder="Add clean pattern into memory index..."
              className="helper-input flex-1"
            />
            <button
              onClick={handleAddVector}
              className="py-2 px-4 bg-cyan-500/10 hover:bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 rounded-lg text-xs font-medium flex items-center gap-1.5 transition-all"
            >
              <Plus size={14} /> Add Pattern
            </button>
          </div>

          <div className="space-y-2 max-h-80 overflow-y-auto custom-scrollbar pr-1">
            {ragVectors.map(vec => (
              <div key={vec.id} className="bg-zinc-900/60 border border-zinc-800/70 p-3 rounded-lg text-xs space-y-1">
                <div className="flex items-center justify-between">
                  <span className="font-semibold text-zinc-200 font-mono">{vec.filePath ?? vec.id}</span>
                  <span className={`text-[11px] font-mono ${
                    vec.provenance === 'clean' ? 'text-emerald-400' : 'text-rose-400'
                  }`}>
                    {vec.provenance}
                  </span>
                </div>
                <p className="text-zinc-300 text-xs leading-relaxed">{vec.content}</p>
                {vec.diagnosis && <p className="text-amber-300/80 text-[11px] italic">Note: {vec.diagnosis}</p>}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Subtab 4: Memory Sandbox */}
      {activeSubTab === 'sandbox' && (
        <div className="bg-zinc-950/80 border border-zinc-800/80 p-5 rounded-xl space-y-4 shadow-lg">
          <div className="border-b border-zinc-800/80 pb-3">
            <h3 className="text-base font-semibold text-zinc-100 flex items-center gap-2">
              <Shield size={16} className="text-violet-400" />
              Memory Isolation Sandbox Helper
            </h3>
            <p className="text-xs text-zinc-400 mt-0.5">
              Execution isolation preventing memory leakage during dynamic module mutations
            </p>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
            <div className="bg-zinc-900/60 p-4 rounded-lg border border-zinc-800/60">
              <span className="text-xs text-zinc-400 block">Garbage Collection Isolation</span>
              <span className="text-base font-bold text-cyan-400 mt-1 block">Active WeakMap Isolation</span>
              <p className="text-xs text-zinc-500 mt-1">Contexts de-allocated on cycle termination</p>
            </div>
            <div className="bg-zinc-900/60 p-4 rounded-lg border border-zinc-800/60">
              <span className="text-xs text-zinc-400 block">Residual Session Drift</span>
              <span className="text-base font-bold text-emerald-400 mt-1 block">0.00% Zero Drift</span>
              <p className="text-xs text-zinc-500 mt-1">Full state resets between file mutations</p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export const VerificationKernelPanel = SovereignKernelPanel;

