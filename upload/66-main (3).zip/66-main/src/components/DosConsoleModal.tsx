/**
 * Developer Console Modal Helper
 * Clean terminal interface supporting pipeline execution, review, and engine CLI commands.
 */

import React, { useState, useRef, useEffect } from 'react';
import { Terminal, X, CornerDownLeft, Sparkles } from 'lucide-react';
import { playClickSound, playChirpSound, playLaserSound, playBootSound } from '../emg/SoundEngine';
import { SANITIZED_ENGINES_CATALOGUE } from '../engines/sanitized-catalogue';
import { SIPHON_SOURCES } from '../core/siphon';

interface DosConsoleModalProps {
  isOpen: boolean;
  onClose: () => void;
  targetRepo?: string;
  files?: Array<{ path: string; size: number; isCodeFile?: boolean }>;
}

export const DosConsoleModal: React.FC<DosConsoleModalProps> = ({ isOpen, onClose, targetRepo = 'craighckby-stack/test-1', files = [] }) => {
  const [inputVal, setInputVal] = useState('');
  const [history, setHistory] = useState<string[]>([
    "Architecture Helper Console [v4.0.0]",
    "Governance Kernel & Clean-Room Agent Engines Runtime",
    "Type 'help' to view available system commands.",
    ""
  ]);
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (isOpen) {
      playBootSound();
    }
  }, [isOpen]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [history]);

  if (!isOpen) return null;

  const handleCommand = (cmd: string) => {
    const trimmed = cmd.trim();
    if (!trimmed) return;

    playClickSound();
    const newHistory = [...history, `helper@system:~$ ${trimmed}`];
    const parts = trimmed.split(' ');
    const command = parts[0].toLowerCase();

    switch (command) {
      case 'help':
        newHistory.push(
          "Available System Commands:",
          "  dir, ls          List active repository structure and file sizes",
          "  status           Display kernel health, AST Diff score, and memory states",
          "  pipeline         Run single pipeline refactoring cycle simulation",
          "  review           Convene Dual-Perspective Code Review Helper",
          "  sanity           Execute Shannon Entropy secret scan on buffer",
          "  triloop          Run 3-loop scan, debate, and halt convergence test",
          "  debate           Execute mock adversarial debate tribunal",
          "  engines          List all 15+ clean-room modular agent engines",
          "  siphon           Show architectural pattern sources matrix",
          "  clear, cls       Clear console log buffer",
          "  exit             Close this console session"
        );
        break;

      case 'dir':
      case 'ls':
        if (files && files.length > 0) {
          newHistory.push(`Loaded repository files in ${targetRepo} (${files.length} total):`);
          files.slice(0, 16).forEach(f => {
            newHistory.push(`  -rw-r--r--   ${f.path.padEnd(36)} ${f.size.toLocaleString().padStart(6)} bytes`);
          });
          if (files.length > 16) {
            newHistory.push(`  ... and ${files.length - 16} additional files.`);
          }
        } else {
          newHistory.push(
            `Directory listing of ${targetRepo}:`,
            "  drwxr-xr-x   src/core         (AST Diff Gate, BinaryShield, Siphon)",
            "  drwxr-xr-x   src/emg          (Verification Kernel, Refactoring Loop, Memory Bank)",
            "  drwxr-xr-x   src/engines      (15 Clean-Room Agent Engines)",
            "  -rw-r--r--   README.md        5,120 bytes",
            "  -rw-r--r--   package.json       920 bytes"
          );
        }
        break;

      case 'pipeline':
        playLaserSound();
        newHistory.push(
          "[Pipeline Simulation] Running full 6-stage architecture refactoring cycle...",
          "  ✓ Stage 0: Pattern Ingestion — Template selected (Clean-Room Standard)",
          "  ✓ Stage 1: Entropy Sanitizer — 0 credentials leaked, Shannon threshold passed",
          "  ✓ Stage 2: Modular Agent Loop — 5-Pillar ReAct sequence executed in VFS",
          "  ✓ Stage 3: AST Diff Gate — 100% symbols preserved, 0% branding injection",
          "  ✓ Stage 4: Code Review — Security & Architecture reviewers approved",
          "  ✓ Stage 5: Convergence Guard — 0-diff code saturation reached, proof hash generated",
          "Verdict: COMPLETED. All stages verified."
        );
        break;

      case 'review':
        playChirpSound();
        newHistory.push(
          "[Code Review Helper] Convening dual-perspective review panel...",
          "  [Security Reviewer]     APPROVED — zero secret tokens, dynamic eval() absent.",
          "  [Architecture Reviewer] APPROVED — interface contracts & exports preserved.",
          "  [Lead Reviewer]         APPROVED (Consensus coefficient: 0.92, Cognitive friction: 0.18).",
          "Consensus: APPROVED."
        );
        break;

      case 'status':
        newHistory.push(
          "Kernel System Status:",
          `  Target Repository:   ${targetRepo}`,
          "  AST Diff Gate:       Active (60% symbol retention floor)",
          "  Secret Sanitizer:    Active (Shannon entropy threshold 4.15)",
          "  WeakMap Sandbox:     Enforced (Zero memory drift)",
          "  Sanitized Engines:   15 loaded and verified",
          "  Tribunal Stance:     Epistemic Harmony"
        );
        break;

      case 'triloop':
        playLaserSound();
        newHistory.push(
          "[Tri-Loop] Loop 1 (Harvest/Scan): Shannon entropy clean (0 leaks).",
          "[Tri-Loop] Loop 2 (Debate): Tribunal approved with 88% consensus coefficient.",
          "[Tri-Loop] Loop 3 (Halt): Self-stopping convergence verified (Hash: c_5f3759).",
          "Proof-of-clean commit synthesized successfully."
        );
        break;

      case 'sanity':
        newHistory.push(
          "[Sanity Check] Scanning memory buffers for high-entropy tokens...",
          "Result: 0 hardcoded credentials detected.",
          "Buffer entropy: 3.42 bits/char (Clean / Normal)"
        );
        break;

      case 'debate':
        playChirpSound();
        newHistory.push(
          "[Tribunal] Prosecutor: 'Candidate AST conforms to type-safety rules.'",
          "[Tribunal] Defender: 'Intent preserved without breaking interface contract.'",
          "[Tribunal] Ruling: APPROVED."
        );
        break;

      case 'engines':
        newHistory.push("Sanitized Agent Engines Registry:");
        SANITIZED_ENGINES_CATALOGUE.slice(0, 8).forEach(e => {
          newHistory.push(`  • ${e.name.padEnd(28)} [${e.sourceOrigin}]`);
        });
        newHistory.push(`  ... and ${SANITIZED_ENGINES_CATALOGUE.length - 8} more in Engines Hub.`);
        break;

      case 'siphon':
        newHistory.push("Curated Architectural Sources:");
        SIPHON_SOURCES.forEach(s => {
          newHistory.push(`  • [${s.id}] ${s.owner}/${s.repo} — ${s.label}`);
        });
        break;

      case 'clear':
      case 'cls':
        setHistory([]);
        setInputVal('');
        return;

      case 'exit':
        onClose();
        return;

      default:
        newHistory.push(`Command not recognized: '${parts[0]}'. Type 'help' for available commands.`);
        break;
    }

    newHistory.push("");
    setHistory(newHistory);
    setInputVal('');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-md p-4 animate-in fade-in duration-200">
      <div className="w-full max-w-3xl h-[520px] bg-zinc-950 border border-zinc-800 shadow-2xl flex flex-col rounded-xl overflow-hidden font-mono text-xs">
        {/* Terminal Title Bar */}
        <div className="bg-zinc-900/90 border-b border-zinc-800 px-4 py-3 flex items-center justify-between text-zinc-300">
          <div className="flex items-center gap-2.5">
            <div className="flex items-center gap-1.5">
              <span className="w-3 h-3 rounded-full bg-rose-500/80 inline-block" />
              <span className="w-3 h-3 rounded-full bg-amber-500/80 inline-block" />
              <span className="w-3 h-3 rounded-full bg-emerald-500/80 inline-block" />
            </div>
            <span className="font-sans font-medium text-xs text-zinc-300 ml-2">
              Developer Terminal — {targetRepo}
            </span>
          </div>
          <button
            onClick={() => { playClickSound(); onClose(); }}
            className="text-zinc-400 hover:text-zinc-100 transition-colors p-1 rounded-md hover:bg-zinc-800"
          >
            <X size={16} />
          </button>
        </div>

        {/* Console Screen */}
        <div className="flex-1 p-4 overflow-y-auto text-xs text-zinc-300 space-y-1 custom-scrollbar leading-relaxed">
          {history.map((line, idx) => (
            <div key={idx} className={line.startsWith('helper@') ? 'text-cyan-400' : ''}>
              {line}
            </div>
          ))}
          <div ref={bottomRef} />
        </div>

        {/* Command Input Bar */}
        <div className="border-t border-zinc-800 px-4 py-3 bg-zinc-950 flex items-center gap-2">
          <span className="text-cyan-400 font-semibold text-xs">helper@system:~$</span>
          <input
            type="text"
            value={inputVal}
            onChange={e => setInputVal(e.target.value)}
            onKeyDown={e => {
              if (e.key === 'Enter') {
                handleCommand(inputVal);
              }
            }}
            autoFocus
            className="flex-1 bg-transparent border-none outline-none text-zinc-100 font-mono text-xs caret-cyan-400 placeholder:text-zinc-600"
            placeholder="Type command..."
          />
          <button
            onClick={() => handleCommand(inputVal)}
            className="text-zinc-400 hover:text-cyan-400 transition-colors"
          >
            <CornerDownLeft size={16} />
          </button>
        </div>
      </div>
    </div>
  );
};
