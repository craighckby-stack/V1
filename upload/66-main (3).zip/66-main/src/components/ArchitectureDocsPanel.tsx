/**
 * Architecture & Audit Documentation Panel
 * In-app interactive viewer for verified system specifications,
 * audit findings, and technical references.
 */

import React, { useState } from 'react';
import {
  FileText,
  ShieldCheck,
  Cpu,
  Layers,
  Terminal,
  CheckCircle2,
  AlertTriangle,
  Info,
  ExternalLink,
  Code,
  Zap,
  Activity,
  Copy,
  Check,
} from 'lucide-react';
import { playClickSound, playChirpSound } from '../emg/SoundEngine';

export const ArchitectureDocsPanel: React.FC = () => {
  const [copiedSection, setCopiedSection] = useState<string | null>(null);

  const handleCopy = (text: string, sectionId: string) => {
    playClickSound();
    navigator.clipboard.writeText(text);
    setCopiedSection(sectionId);
    setTimeout(() => setCopiedSection(null), 2000);
  };

  return (
    <div className="space-y-6 text-zinc-300">
      {/* Header Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 p-5 bg-zinc-950/90 border border-zinc-800/80 rounded-2xl shadow-lg">
        <div className="flex items-center gap-3.5">
          <div className="p-2.5 rounded-xl bg-cyan-500/10 border border-cyan-500/20 text-cyan-400">
            <FileText size={22} />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-base font-bold text-zinc-100 font-display">
                Architecture Helper Pipeline Specification
              </h2>
              <span className="text-xs font-mono px-2 py-0.5 rounded bg-emerald-950/80 text-emerald-400 border border-emerald-800/60 font-semibold">
                Verified v4.0.0
              </span>
            </div>
            <p className="text-xs text-zinc-400 mt-0.5">
              Empirical system architecture, 6-stage pipeline mechanics, and verified audit rectifications.
            </p>
          </div>
        </div>

        <button
          onClick={() => handleCopy(SYSTEM_DOCUMENTATION_TEXT, 'all')}
          className="px-3.5 py-2 bg-zinc-900 hover:bg-zinc-800 text-zinc-200 border border-zinc-700/80 rounded-xl text-xs font-medium flex items-center gap-2 transition-all cursor-pointer shrink-0"
        >
          {copiedSection === 'all' ? <Check size={14} className="text-emerald-400" /> : <Copy size={14} />}
          <span>{copiedSection === 'all' ? 'Copied Full Spec' : 'Copy Full Documentation'}</span>
        </button>
      </div>

      {/* Critical Principles Callout */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-3.5">
        <div className="p-4 bg-zinc-950/80 border border-zinc-800/80 rounded-xl space-y-2">
          <div className="flex items-center gap-2 text-cyan-400 font-semibold text-xs">
            <Cpu size={15} />
            <span>Deterministic Execution</span>
          </div>
          <p className="text-xs text-zinc-400 leading-relaxed">
            No remote LLM API client is called. All transformation stages execute through deterministic regular expressions, AST symbol scanners, and local rule sets.
          </p>
        </div>

        <div className="p-4 bg-zinc-950/80 border border-zinc-800/80 rounded-xl space-y-2">
          <div className="flex items-center gap-2 text-emerald-400 font-semibold text-xs">
            <ShieldCheck size={15} />
            <span>Entropy Sanitization</span>
          </div>
          <p className="text-xs text-zinc-400 leading-relaxed">
            Evaluates Shannon entropy thresholds (4.15 bits/char) and strips hardcoded Google, AWS, GitHub, and OpenAI tokens alongside PII patterns.
          </p>
        </div>

        <div className="p-4 bg-zinc-950/80 border border-zinc-800/80 rounded-xl space-y-2">
          <div className="flex items-center gap-2 text-amber-400 font-semibold text-xs">
            <Layers size={15} />
            <span>AST Symbol Preservation</span>
          </div>
          <p className="text-xs text-zinc-400 leading-relaxed">
            Enforces symbol retention checks across functions, classes, interfaces, and types to guarantee that mutations preserve public interface contracts.
          </p>
        </div>
      </div>

      {/* 6-Stage Pipeline Table */}
      <div className="panel-container p-5 space-y-3">
        <div className="border-b border-zinc-800 pb-2.5 flex items-center justify-between">
          <h3 className="text-xs font-semibold uppercase font-mono tracking-wider text-zinc-200 flex items-center gap-2">
            <Activity size={14} className="text-cyan-400" />
            Six-Stage Client Pipeline Flow
          </h3>
          <span className="text-[11px] font-mono text-zinc-500">src/core/unified-pipeline.ts</span>
        </div>

        <div className="overflow-x-auto custom-scrollbar">
          <table className="w-full text-xs text-left">
            <thead className="bg-zinc-900/80 text-zinc-400 font-mono text-[11px] uppercase border-b border-zinc-800">
              <tr>
                <th className="p-3 w-16">Stage</th>
                <th className="p-3 w-48">Name</th>
                <th className="p-3">Mechanical Behavior</th>
                <th className="p-3 w-40">Output State</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-800/60 font-mono text-[11px]">
              <tr className="hover:bg-zinc-900/40">
                <td className="p-3 text-cyan-400 font-bold">0</td>
                <td className="p-3 font-sans font-semibold text-zinc-200">Pattern Ingestion</td>
                <td className="p-3 font-sans text-zinc-400">
                  Scores six architectural pattern sources based on keyword matches or user dropdown selection.
                </td>
                <td className="p-3 text-emerald-400">Template Origin</td>
              </tr>
              <tr className="hover:bg-zinc-900/40">
                <td className="p-3 text-cyan-400 font-bold">1</td>
                <td className="p-3 font-sans font-semibold text-zinc-200">Security Sanitizer</td>
                <td className="p-3 font-sans text-zinc-400">
                  Calculates Shannon entropy on 24+ character strings and redacts credential tokens, emails, and SSN formats.
                </td>
                <td className="p-3 text-amber-400">[REDACTED_SECRET]</td>
              </tr>
              <tr className="hover:bg-zinc-900/40">
                <td className="p-3 text-cyan-400 font-bold">2</td>
                <td className="p-3 font-sans font-semibold text-zinc-200">Modular Agent Loop</td>
                <td className="p-3 font-sans text-zinc-400">
                  Executes bounded 5-Pillar clean-room ReAct steps in an in-memory virtual file system (VFS).
                </td>
                <td className="p-3 text-cyan-400">Quarantined VFS</td>
              </tr>
              <tr className="hover:bg-zinc-900/40">
                <td className="p-3 text-cyan-400 font-bold">3</td>
                <td className="p-3 font-sans font-semibold text-zinc-200">AST Verification Gate</td>
                <td className="p-3 font-sans text-zinc-400">
                  Scans function, class, and interface symbols. Computes structural drift on normalized code (excluding comments).
                </td>
                <td className="p-3 text-emerald-400">AST Score &ge; 50/100</td>
              </tr>
              <tr className="hover:bg-zinc-900/40">
                <td className="p-3 text-cyan-400 font-bold">4</td>
                <td className="p-3 font-sans font-semibold text-zinc-200">Code Review Panel</td>
                <td className="p-3 font-sans text-zinc-400">
                  Dual-perspective evaluation: Security Reviewer vs Architecture Reviewer with refined regex verification.
                </td>
                <td className="p-3 text-emerald-400">APPROVED / CONDITIONAL</td>
              </tr>
              <tr className="hover:bg-zinc-900/40">
                <td className="p-3 text-cyan-400 font-bold">5</td>
                <td className="p-3 font-sans font-semibold text-zinc-200">Commit &amp; Convergence</td>
                <td className="p-3 font-sans text-zinc-400">
                  Checks 0-diff code saturation, updates the SelfStoppingGovernor with batch reset, and generates a SHA-256 proof hash.
                </td>
                <td className="p-3 text-cyan-400">Proof Commit Hash</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      {/* Verified Audit Rectifications */}
      <div className="panel-container p-5 space-y-4">
        <div className="border-b border-zinc-800 pb-2.5">
          <h3 className="text-xs font-semibold uppercase font-mono tracking-wider text-zinc-200 flex items-center gap-2">
            <CheckCircle2 size={14} className="text-emerald-400" />
            Verified Audit Rectifications Applied
          </h3>
          <p className="text-xs text-zinc-400 mt-0.5">
            Key fixes implemented to address every bottleneck and edge-case discovered during empirical verification.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
          <div className="p-3.5 bg-zinc-900/60 border border-zinc-800/80 rounded-xl space-y-1.5">
            <div className="font-semibold text-zinc-200 flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-emerald-400" />
              <span>15-Run Governor Lockout Fixed</span>
            </div>
            <p className="text-zinc-400 text-[11px] leading-relaxed">
              Batch runs and multi-file mutations now automatically reset loop cycle counters. Added a manual "Reset Cycles" button in the navigation bar and Governance tab to prevent arbitrary MAX_CYCLES_REACHED halts.
            </p>
          </div>

          <div className="p-3.5 bg-zinc-900/60 border border-zinc-800/80 rounded-xl space-y-1.5">
            <div className="font-semibold text-zinc-200 flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-emerald-400" />
              <span>Small-File AST Drift Calculation Fixed</span>
            </div>
            <p className="text-zinc-400 text-[11px] leading-relaxed">
              Drift calculations now strip prepended comment headers and contract boilerplate before comparing lengths, with a baseline divisor floor to prevent compact files from falsely triggering AST_STRUCTURAL_DRIFT.
            </p>
          </div>

          <div className="p-3.5 bg-zinc-900/60 border border-zinc-800/80 rounded-xl space-y-1.5">
            <div className="font-semibold text-zinc-200 flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-emerald-400" />
              <span>Regex False-Positive Triggers Eliminated</span>
            </div>
            <p className="text-zinc-400 text-[11px] leading-relaxed">
              Replaced naive substring matching with exact token patterns: words like "task-runner" or "risk-score" no longer trigger OpenAI key alerts, and standard function declarations no longer trip dynamic eval alarms.
            </p>
          </div>

          <div className="p-3.5 bg-zinc-900/60 border border-zinc-800/80 rounded-xl space-y-1.5">
            <div className="font-semibold text-zinc-200 flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-emerald-400" />
              <span>50MB Payload Capacity &amp; Reactive Modals</span>
            </div>
            <p className="text-zinc-400 text-[11px] leading-relaxed">
              Express JSON limits increased from 100KB to 50MB for batch commits. AST Diff Modal converted to reactive useMemo hooks that update dynamically whenever files are selected.
            </p>
          </div>
        </div>
      </div>

      {/* HTTP API Reference */}
      <div className="panel-container p-5 space-y-3">
        <div className="border-b border-zinc-800 pb-2.5">
          <h3 className="text-xs font-semibold uppercase font-mono tracking-wider text-zinc-200 flex items-center gap-2">
            <Terminal size={14} className="text-cyan-400" />
            Express Server API Reference (server.ts)
          </h3>
          <p className="text-xs text-zinc-400 mt-0.5">
            Server-side routes supporting repository scanning, token verification, and batch file commit dispatch.
          </p>
        </div>

        <div className="overflow-x-auto custom-scrollbar">
          <table className="w-full text-xs text-left">
            <thead className="bg-zinc-900/80 text-zinc-400 font-mono text-[11px] uppercase border-b border-zinc-800">
              <tr>
                <th className="p-3 w-48">Endpoint</th>
                <th className="p-3 w-20">Method</th>
                <th className="p-3">Purpose</th>
                <th className="p-3 w-28">Max Payload</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-800/60 font-mono text-[11px]">
              <tr className="hover:bg-zinc-900/40">
                <td className="p-3 text-cyan-300">/api/health</td>
                <td className="p-3 text-emerald-400">GET</td>
                <td className="p-3 font-sans text-zinc-400">Returns health status, active version (4.0.0), and active subsystems.</td>
                <td className="p-3 text-zinc-500">N/A</td>
              </tr>
              <tr className="hover:bg-zinc-900/40">
                <td className="p-3 text-cyan-300">/api/github/validate-token</td>
                <td className="p-3 text-amber-400">POST</td>
                <td className="p-3 font-sans text-zinc-400">Validates personal access token with GitHub /user API and returns scopes.</td>
                <td className="p-3 text-zinc-500">50 MB</td>
              </tr>
              <tr className="hover:bg-zinc-900/40">
                <td className="p-3 text-cyan-300">/api/github/repo-tree</td>
                <td className="p-3 text-amber-400">POST</td>
                <td className="p-3 font-sans text-zinc-400">Fetches recursive git tree for specified repository branch; falls back to root.</td>
                <td className="p-3 text-zinc-500">50 MB</td>
              </tr>
              <tr className="hover:bg-zinc-900/40">
                <td className="p-3 text-cyan-300">/api/github/fetch-file</td>
                <td className="p-3 text-amber-400">POST</td>
                <td className="p-3 font-sans text-zinc-400">Reads blob contents via contents API and decodes base64 payload to UTF-8.</td>
                <td className="p-3 text-zinc-500">50 MB</td>
              </tr>
              <tr className="hover:bg-zinc-900/40">
                <td className="p-3 text-cyan-300">/api/github/batch-commit-files</td>
                <td className="p-3 text-amber-400">POST</td>
                <td className="p-3 font-sans text-zinc-400">Dispatches multi-file PUT requests to target repository branch using GitHub token.</td>
                <td className="p-3 text-emerald-400 font-bold">50 MB</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

const SYSTEM_DOCUMENTATION_TEXT = `# Architecture Helper Pipeline

A React + Vite single-page app, served by a small Express server, that loads source files (from five built-in samples or from a GitHub repository), passes each file through a six-stage client-side "pipeline", shows the results in a dashboard, and can commit the results back to a GitHub branch through the GitHub REST API.

## Core Characteristics
- Deterministic regex, AST symbol extraction, and rule-based verification.
- Language-aware comment headers and structural preservation.
- Full 50MB payload batch commit capacity for multi-file repositories.
- Zero-leak WeakMap memory isolation and SelfStoppingGovernor cycle guards.
`;
