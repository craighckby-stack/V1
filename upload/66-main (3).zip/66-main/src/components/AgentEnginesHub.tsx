/**
 * Modular Agent Engines Helper Component
 * Catalogue browser, 5-Pillar Architecture validator,
 * and live interactive runtime runner.
 */

import React, { useState } from 'react';
import { SANITIZED_ENGINES_CATALOGUE, SanitizedEngineEntry } from '../engines/sanitized-catalogue';
import { executeCleanRoomEngine, EngineExecutionResult } from '../engines/clean-room-runtime';
import { playClickSound, playLaserSound, playSuccessSound } from '../emg/SoundEngine';
import { Cpu, Search, Check, Play, ShieldCheck, Box, RefreshCw, Terminal, Layers } from 'lucide-react';

export const AgentEnginesHub: React.FC = () => {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedEngine, setSelectedEngine] = useState<SanitizedEngineEntry>(SANITIZED_ENGINES_CATALOGUE[0]);
  const [runGoal, setRunGoal] = useState('Analyze repository AST and synthesize clean-room refactoring plan');
  const [isExecuting, setIsExecuting] = useState(false);
  const [executionResult, setExecutionResult] = useState<EngineExecutionResult | null>(null);

  const categories = [
    { id: 'all', label: 'All Engines' },
    { id: 'reasoning-loop', label: 'Reasoning Loops' },
    { id: 'orchestration', label: 'Orchestration' },
    { id: 'memory-context', label: 'Memory & Context' },
    { id: 'messaging-runtime', label: 'Messaging Runtimes' },
    { id: 'security-sandbox', label: 'Security & Sandboxes' },
    { id: 'harvested-agent', label: 'Harvested Frameworks' },
  ];

  const filteredEngines = SANITIZED_ENGINES_CATALOGUE.filter(engine => {
    const matchesCat = selectedCategory === 'all' || engine.category === selectedCategory;
    const matchesSearch = engine.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          engine.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          engine.sourceOrigin.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCat && matchesSearch;
  });

  const handleRunEngine = async () => {
    setIsExecuting(true);
    playLaserSound();

    try {
      const res = await executeCleanRoomEngine(selectedEngine.id, runGoal);
      setExecutionResult(res);
      playSuccessSound();
    } catch {
      // Error handling
    } finally {
      setIsExecuting(false);
    }
  };

  return (
    <div className="flex flex-col gap-5 text-sm">
      {/* Top Banner Card */}
      <div className="bg-zinc-950/80 border border-zinc-800/80 p-5 rounded-xl flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-lg">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-lg bg-cyan-500/10 border border-cyan-500/20 text-cyan-400">
            <Cpu size={20} />
          </div>
          <div>
            <h2 className="text-base font-semibold text-zinc-100">
              Modular Agent Engines Helper
            </h2>
            <p className="text-xs text-zinc-400 mt-0.5">
              5-Pillar Architecture · {SANITIZED_ENGINES_CATALOGUE.length} Verified Modular Engines
            </p>
          </div>
        </div>

        <div className="text-xs font-mono text-emerald-400 flex items-center gap-1.5 self-start sm:self-auto">
          <Check size={14} />
          <span>Vendor Neutral &amp; Verified Clean</span>
        </div>
      </div>

      {/* Search and Category Filter */}
      <div className="flex flex-col gap-3">
        <div className="relative">
          <Search size={14} className="absolute left-3.5 top-3.5 text-zinc-500" />
          <input
            type="text"
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            placeholder="Search engines by title, origin or description..."
            className="helper-input pl-10 text-xs"
          />
        </div>

        <div className="flex gap-1.5 overflow-x-auto pb-1 custom-scrollbar">
          {categories.map(cat => (
            <button
              key={cat.id}
              onClick={() => { playClickSound(); setSelectedCategory(cat.id); }}
              className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-all whitespace-nowrap ${
                selectedCategory === cat.id
                  ? 'bg-zinc-800 text-cyan-300 border border-zinc-700/80 shadow-sm'
                  : 'text-zinc-400 hover:text-zinc-200 hover:bg-zinc-900/50'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>
      </div>

      {/* Main Grid: Catalog List & Detail/Execution View */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-4">
        {/* Left: Engine List */}
        <div className="md:col-span-5 space-y-2 max-h-[540px] overflow-y-auto custom-scrollbar pr-1">
          {filteredEngines.map(engine => {
            const isSelected = selectedEngine.id === engine.id;
            return (
              <div
                key={engine.id}
                onClick={() => { playClickSound(); setSelectedEngine(engine); }}
                className={`p-3.5 rounded-xl border cursor-pointer transition-all ${
                  isSelected
                    ? 'border-cyan-500/50 bg-cyan-950/20 shadow-md'
                    : 'border-zinc-800/80 bg-zinc-950/60 hover:border-zinc-700 hover:bg-zinc-900/40'
                }`}
              >
                <div className="flex items-center justify-between mb-1.5">
                  <span className={`font-semibold text-xs ${isSelected ? 'text-cyan-300' : 'text-zinc-200'}`}>
                    {engine.name}
                  </span>
                  <span className="text-[11px] font-mono text-zinc-500">
                    {engine.sourceOrigin}
                  </span>
                </div>
                <p className="text-xs text-zinc-400 line-clamp-2 leading-relaxed">
                  {engine.description}
                </p>
              </div>
            );
          })}
        </div>

        {/* Right: Selected Engine Details & Live Interactive Runner */}
        <div className="md:col-span-7 bg-zinc-950/80 border border-zinc-800/80 p-5 rounded-xl space-y-4 shadow-lg">
          <div className="border-b border-zinc-800/80 pb-3">
            <div className="flex items-center justify-between">
              <h3 className="text-base font-semibold text-cyan-300">
                {selectedEngine.name}
              </h3>
              <span className="text-xs font-mono text-amber-400">
                {selectedEngine.category}
              </span>
            </div>
            <p className="text-xs text-zinc-400 mt-1 leading-relaxed">
              {selectedEngine.description}
            </p>
          </div>

          {/* 5-Pillar Architecture Compliance Matrix */}
          <div>
            <span className="text-xs font-medium text-zinc-400 block mb-2 flex items-center gap-1.5">
              <ShieldCheck size={14} className="text-emerald-400" />
              5-Pillar Architecture Compliance Matrix
            </span>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 text-xs">
              <div className="bg-zinc-900/60 p-2.5 border border-zinc-800/60 rounded-lg flex items-center gap-2">
                <Check size={12} className="text-emerald-400" />
                <span className="text-zinc-300">01-Lifecycle Kernel</span>
              </div>
              <div className="bg-zinc-900/60 p-2.5 border border-zinc-800/60 rounded-lg flex items-center gap-2">
                <Check size={12} className="text-emerald-400" />
                <span className="text-zinc-300">02-ReAct Loop Engine</span>
              </div>
              <div className="bg-zinc-900/60 p-2.5 border border-zinc-800/60 rounded-lg flex items-center gap-2">
                <Check size={12} className="text-emerald-400" />
                <span className="text-zinc-300">03-Stream Adapter</span>
              </div>
              <div className="bg-zinc-900/60 p-2.5 border border-zinc-800/60 rounded-lg flex items-center gap-2">
                <Check size={12} className="text-emerald-400" />
                <span className="text-zinc-300">04-VFS Tool Sandbox</span>
              </div>
              <div className="bg-zinc-900/60 p-2.5 border border-zinc-800/60 rounded-lg flex items-center gap-2">
                <Check size={12} className="text-emerald-400" />
                <span className="text-zinc-300">05-Token Budget Tree</span>
              </div>
              <div className="bg-zinc-900/60 p-2.5 border border-zinc-800/60 rounded-lg flex items-center gap-2">
                <Check size={12} className="text-emerald-400" />
                <span className="text-zinc-300">Isolated Scope</span>
              </div>
            </div>
          </div>

          {/* Live Runner Controls */}
          <div className="space-y-2 pt-2 border-t border-zinc-800/80">
            <label className="text-xs font-medium text-zinc-400 block">
              Execute In-Memory Engine Sandbox
            </label>
            <div className="flex gap-2">
              <input
                type="text"
                value={runGoal}
                onChange={e => setRunGoal(e.target.value)}
                placeholder="Agent goal or instruction..."
                className="helper-input flex-1"
              />
              <button
                onClick={handleRunEngine}
                disabled={isExecuting}
                className="py-2.5 px-4 bg-cyan-500/10 hover:bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 rounded-lg text-xs font-medium flex items-center gap-2 transition-all active:scale-[0.98]"
              >
                <Play size={14} className={isExecuting ? "animate-spin" : ""} />
                {isExecuting ? "Executing..." : "Run Engine Helper"}
              </button>
            </div>
          </div>

          {/* Execution Trace Output */}
          {executionResult && (
            <div className="bg-zinc-900/80 border border-zinc-800 p-4 rounded-xl space-y-3 text-xs">
              <div className="flex items-center justify-between border-b border-zinc-800/80 pb-2">
                <span className="text-zinc-400 font-medium">Execution Status:</span>
                <span className="text-emerald-400 font-semibold">{executionResult.status}</span>
              </div>

              <div className="space-y-2 font-mono text-xs">
                {executionResult.steps.map((step, idx) => (
                  <div key={idx} className="bg-zinc-950 p-2.5 rounded-lg border border-zinc-900 space-y-1">
                    <div className="flex justify-between text-zinc-500 text-[11px]">
                      <span>Step {step.stepNumber}</span>
                      {step.actionName && <span className="text-amber-400">Action: {step.actionName}</span>}
                    </div>
                    <div className="text-zinc-200">{step.thought}</div>
                    {step.observation && <div className="text-zinc-400 italic text-[11px]">Obs: {step.observation}</div>}
                  </div>
                ))}
              </div>

              <div className="pt-2 border-t border-zinc-800 text-zinc-300 leading-relaxed">
                {executionResult.finalAnswer}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
