/**
 * AST Diff Gate Modal Component
 * Modernized with clean side-by-side code review viewer and high-legibility syntax panes.
 */

import React, { useMemo } from 'react';
import { evaluateAstDiff, AstDiffResult } from '../core/ast-diff-gate';
import { playClickSound } from '../emg/SoundEngine';
import { X, ShieldAlert, Cpu, CheckCircle2, AlertTriangle, FileCode } from 'lucide-react';

interface AstDiffModalProps {
  isOpen: boolean;
  onClose: () => void;
  originalCode: string;
  proposedCode: string;
}

export const AstDiffModal: React.FC<AstDiffModalProps> = ({
  isOpen,
  onClose,
  originalCode,
  proposedCode,
}) => {
  const diffResult = useMemo<AstDiffResult>(() =>
    evaluateAstDiff(originalCode, proposedCode),
    [originalCode, proposedCode]
  );

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-md p-4 animate-in fade-in duration-200">
      <div className="w-full max-w-5xl h-[600px] bg-zinc-950 border border-zinc-800 shadow-2xl flex flex-col rounded-xl overflow-hidden font-sans text-xs">
        {/* Title Bar */}
        <div className="bg-zinc-900/90 border-b border-zinc-800 px-5 py-3.5 flex items-center justify-between text-zinc-200">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-amber-500/10 border border-amber-500/20 text-amber-400">
              <Cpu size={16} />
            </div>
            <div>
              <h3 className="font-semibold text-sm text-zinc-100">
                AST Diff Gate · Syntax &amp; Symbol Verifier
              </h3>
              <p className="text-xs text-zinc-400">
                Verifies AST symbol retention, structural drift ratios, and branding injections
              </p>
            </div>
          </div>
          <button
            onClick={() => { playClickSound(); onClose(); }}
            className="text-zinc-400 hover:text-zinc-100 transition-colors p-1.5 rounded-lg hover:bg-zinc-800"
          >
            <X size={18} />
          </button>
        </div>

        {/* Metrics Bar */}
        <div className="p-4 bg-zinc-900/40 border-b border-zinc-800 grid grid-cols-2 sm:grid-cols-4 gap-3">
          <div className="bg-zinc-900/70 p-3 border border-zinc-800/70 rounded-xl">
            <span className="text-xs text-zinc-400 block">AST Score</span>
            <span className={`text-lg font-bold font-mono mt-1 block ${diffResult.astScore >= 70 ? 'text-emerald-400' : 'text-rose-400'}`}>
              {diffResult.astScore} / 100
            </span>
          </div>

          <div className="bg-zinc-900/70 p-3 border border-zinc-800/70 rounded-xl">
            <span className="text-xs text-zinc-400 block">Symbol Retention</span>
            <span className="text-lg font-bold font-mono text-cyan-400 mt-1 block">
              {diffResult.symbolMap.retainedCount} / {diffResult.symbolMap.originalCount}
            </span>
          </div>

          <div className="bg-zinc-900/70 p-3 border border-zinc-800/70 rounded-xl">
            <span className="text-xs text-zinc-400 block">Structural Drift</span>
            <span className="text-lg font-bold font-mono text-amber-400 mt-1 block">
              {(diffResult.structuralDriftRatio * 100).toFixed(0)}%
            </span>
          </div>

          <div className="bg-zinc-900/70 p-3 border border-zinc-800/70 rounded-xl">
            <span className="text-xs text-zinc-400 block">Gate Verdict</span>
            <span className={`text-lg font-bold font-mono mt-1 block ${diffResult.passed ? 'text-emerald-400' : 'text-rose-400'}`}>
              {diffResult.passed ? 'PASSED' : 'REJECTED'}
            </span>
          </div>
        </div>

        {/* Violations Warning Bar */}
        {diffResult.violations.length > 0 && (
          <div className="bg-rose-950/20 border-b border-rose-900/40 px-4 py-2.5 space-y-1">
            <span className="text-xs text-rose-300 font-semibold flex items-center gap-1.5">
              <ShieldAlert size={14} /> Violations Identified:
            </span>
            {diffResult.violations.map((v, i) => (
              <div key={i} className="text-xs text-rose-400/90 pl-5 font-mono">
                • [{v.code}] {v.message} ({v.severity} severity)
              </div>
            ))}
          </div>
        )}

        {/* Side-by-Side Code Viewer */}
        <div className="flex-1 grid grid-cols-1 md:grid-cols-2 gap-3 p-4 overflow-hidden">
          <div className="flex flex-col border border-zinc-800/80 bg-zinc-900/60 rounded-xl overflow-hidden shadow-inner">
            <div className="bg-zinc-900/90 px-3 py-2 text-xs text-zinc-400 font-medium border-b border-zinc-800 flex justify-between items-center">
              <span>Original Baseline</span>
              <span className="font-mono text-[11px] text-zinc-500">{originalCode.length} bytes</span>
            </div>
            <pre className="flex-1 p-3 text-xs text-zinc-300 overflow-auto whitespace-pre-wrap font-mono custom-scrollbar leading-relaxed">
              {originalCode}
            </pre>
          </div>

          <div className="flex flex-col border border-zinc-800/80 bg-zinc-900/60 rounded-xl overflow-hidden shadow-inner">
            <div className="bg-zinc-900/90 px-3 py-2 text-xs text-cyan-400 font-medium border-b border-zinc-800 flex justify-between items-center">
              <span>Proposed Mutation</span>
              <span className="font-mono text-[11px] text-zinc-500">{proposedCode.length} bytes</span>
            </div>
            <pre className="flex-1 p-3 text-xs text-cyan-200/90 overflow-auto whitespace-pre-wrap font-mono custom-scrollbar leading-relaxed">
              {proposedCode}
            </pre>
          </div>
        </div>
      </div>
    </div>
  );
};
