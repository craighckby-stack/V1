/**
 * Sanitized Autonomous Agent Engines Catalogue
 * Origin: craighckby-stack/sanitized-agent-engines
 * Clean-room runtime engine specifications and production architecture.
 * All vendor trademarks and proprietary branding have been scrubbed into isolated, composable runtime architecture.
 */

export interface SanitizedEngineEntry {
  id: string;
  name: string;
  category: 'reasoning-loop' | 'orchestration' | 'memory-context' | 'messaging-runtime' | 'security-sandbox' | 'harvested-agent';
  description: string;
  sourceOrigin: string;
  status: 'Clean-Room Sanitized' | 'Verified Active';
  fivePillarCompliance: {
    lifecycleKernel: boolean;
    reactLoop: boolean;
    streamAdapter: boolean;
    vfsSandbox: boolean;
    sessionTreeBudget: boolean;
  };
  sampleCapability: string;
}

export const SANITIZED_ENGINES_CATALOGUE: readonly SanitizedEngineEntry[] = [
  {
    id: "inference-reasoning-loop",
    name: "Inference Reasoning Loop",
    category: "reasoning-loop",
    description: "Stateful orchestration engine managing the Reasoning-Action-Observation cycle with step-budget enforcement.",
    sourceOrigin: "clean-room/core",
    status: "Clean-Room Sanitized",
    fivePillarCompliance: { lifecycleKernel: true, reactLoop: true, streamAdapter: true, vfsSandbox: true, sessionTreeBudget: true },
    sampleCapability: "Executes bounded ReAct iterations with infinite-loop tripwires."
  },
  {
    id: "context-compaction-engine",
    name: "Context Compaction Engine",
    category: "memory-context",
    description: "Token budget guardian implementing sliding windows, recursive summarization, and AST deduplication.",
    sourceOrigin: "clean-room/memory",
    status: "Clean-Room Sanitized",
    fivePillarCompliance: { lifecycleKernel: true, reactLoop: true, streamAdapter: true, vfsSandbox: true, sessionTreeBudget: true },
    sampleCapability: "Prevents context window overflow across 100+ turn continuous sessions."
  },
  {
    id: "generic-message-transport",
    name: "Generic Message Transport",
    category: "messaging-runtime",
    description: "Event-driven asynchronous message abstraction routing between agent cores and IO endpoints.",
    sourceOrigin: "clean-room/transport",
    status: "Clean-Room Sanitized",
    fivePillarCompliance: { lifecycleKernel: true, reactLoop: true, streamAdapter: true, vfsSandbox: true, sessionTreeBudget: true },
    sampleCapability: "Non-blocking multiplexed stream distribution with backpressure handling."
  },
  {
    id: "multi-agent-coordinator-engine",
    name: "Multi-Agent Coordinator Engine",
    category: "orchestration",
    description: "Orchestration engine managing turn-taking, role allocation, and consensus voting across independent agents.",
    sourceOrigin: "clean-room/orchestration",
    status: "Clean-Room Sanitized",
    fivePillarCompliance: { lifecycleKernel: true, reactLoop: true, streamAdapter: true, vfsSandbox: true, sessionTreeBudget: true },
    sampleCapability: "Autonomous leader election and dialectical debate synthesis."
  },
  {
    id: "actor-based-messaging-runtime",
    name: "Actor-Based Messaging Runtime",
    category: "messaging-runtime",
    description: "Low-level concurrency framework where each agent acts as an isolated actor with an atomic mailbox.",
    sourceOrigin: "clean-room/concurrency",
    status: "Clean-Room Sanitized",
    fivePillarCompliance: { lifecycleKernel: true, reactLoop: true, streamAdapter: true, vfsSandbox: true, sessionTreeBudget: true },
    sampleCapability: "Zero-shared-memory message passing with FIFO message queues."
  },
  {
    id: "action-dispatch-permission-engine",
    name: "Action Dispatch Permission Engine",
    category: "security-sandbox",
    description: "Zero-leak gatekeeper evaluating tool execution requests against capability envelopes.",
    sourceOrigin: "clean-room/security",
    status: "Clean-Room Sanitized",
    fivePillarCompliance: { lifecycleKernel: true, reactLoop: true, streamAdapter: true, vfsSandbox: true, sessionTreeBudget: true },
    sampleCapability: "Blocks unvetted shell execution, network escape, and file overwrites."
  },
  {
    id: "activity-hook-engine",
    name: "Activity Hook Engine",
    category: "security-sandbox",
    description: "Interception middleware triggering telemetry, state checkpoints, and audit logging on agent transitions.",
    sourceOrigin: "clean-room/telemetry",
    status: "Clean-Room Sanitized",
    fivePillarCompliance: { lifecycleKernel: true, reactLoop: true, streamAdapter: true, vfsSandbox: true, sessionTreeBudget: true },
    sampleCapability: "Audits pre/post mutation AST diffs and execution latencies."
  },
  {
    id: "langgraph-sanitized",
    name: "LangGraph Clean-Room Runtime",
    category: "harvested-agent",
    description: "Cyclic state graph engine with non-linear branch management, checkpointing, and time-travel rollback.",
    sourceOrigin: "langchain-ai/langgraph",
    status: "Clean-Room Sanitized",
    fivePillarCompliance: { lifecycleKernel: true, reactLoop: true, streamAdapter: true, vfsSandbox: true, sessionTreeBudget: true },
    sampleCapability: "Graph-based stateful agent loops with conditional branch edges."
  },
  {
    id: "autogpt-sanitized",
    name: "AutoGPT Clean-Room Runtime",
    category: "harvested-agent",
    description: "Autonomous task breakdown engine with hierarchical memory recall and recursive sub-goal execution.",
    sourceOrigin: "Significant-Gravitas/AutoGPT",
    status: "Clean-Room Sanitized",
    fivePillarCompliance: { lifecycleKernel: true, reactLoop: true, streamAdapter: true, vfsSandbox: true, sessionTreeBudget: true },
    sampleCapability: "Decomposes complex objectives into atomic verifiable actions."
  },
  {
    id: "aider-sanitized",
    name: "Aider Clean-Room Runtime",
    category: "harvested-agent",
    description: "Repository map builder and unified git patch synthesizer with file-dependency graph analysis.",
    sourceOrigin: "Aider-AI/aider",
    status: "Clean-Room Sanitized",
    fivePillarCompliance: { lifecycleKernel: true, reactLoop: true, streamAdapter: true, vfsSandbox: true, sessionTreeBudget: true },
    sampleCapability: "Generates surgical unified diffs with exact line matching."
  },
  {
    id: "crewai-sanitized",
    name: "CrewAI Clean-Room Runtime",
    category: "harvested-agent",
    description: "Role-playing autonomous agent collective with hierarchical process delegation and task handoff.",
    sourceOrigin: "crewAIInc/crewAI",
    status: "Clean-Room Sanitized",
    fivePillarCompliance: { lifecycleKernel: true, reactLoop: true, streamAdapter: true, vfsSandbox: true, sessionTreeBudget: true },
    sampleCapability: "Coordinates specialized personas: Researcher, Architect, Verifier, Coder."
  },
  {
    id: "open-interpreter-sanitized",
    name: "Open-Interpreter Clean-Room Runtime",
    category: "harvested-agent",
    description: "Sandboxed command interpreter with virtual environment isolation and real-time terminal output streaming.",
    sourceOrigin: "KillianLucas/open-interpreter",
    status: "Clean-Room Sanitized",
    fivePillarCompliance: { lifecycleKernel: true, reactLoop: true, streamAdapter: true, vfsSandbox: true, sessionTreeBudget: true },
    sampleCapability: "Safely runs multi-language code snippets within memory constraints."
  },
  {
    id: "litellm-sanitized",
    name: "LiteLLM Clean-Room Runtime",
    category: "harvested-agent",
    description: "Unified model proxy adapter normalizing multiple LLM APIs into standardized completions and streaming.",
    sourceOrigin: "BerriAI/litellm",
    status: "Clean-Room Sanitized",
    fivePillarCompliance: { lifecycleKernel: true, reactLoop: true, streamAdapter: true, vfsSandbox: true, sessionTreeBudget: true },
    sampleCapability: "Seamless failover between Gemini, Cerebras, Grok, and Claude."
  },
  {
    id: "autogen-sanitized",
    name: "AutoGen Clean-Room Runtime",
    category: "harvested-agent",
    description: "Multi-agent conversational framework with customizable agent personas and human-in-the-loop triggers.",
    sourceOrigin: "microsoft/autogen",
    status: "Clean-Room Sanitized",
    fivePillarCompliance: { lifecycleKernel: true, reactLoop: true, streamAdapter: true, vfsSandbox: true, sessionTreeBudget: true },
    sampleCapability: "Dynamic multi-party group chat with consensus termination."
  },
  {
    id: "agno-sanitized",
    name: "Agno Clean-Room Runtime",
    category: "harvested-agent",
    description: "High-speed multimodal agent runtime optimized for low latency and zero-dependency vector retrieval.",
    sourceOrigin: "agno-agi/agno",
    status: "Clean-Room Sanitized",
    fivePillarCompliance: { lifecycleKernel: true, reactLoop: true, streamAdapter: true, vfsSandbox: true, sessionTreeBudget: true },
    sampleCapability: "Sub-millisecond tool routing and instant session rehydration."
  }
];
