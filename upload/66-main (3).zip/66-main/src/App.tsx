/**
 * ARCHITECTURE HELPER PIPELINE v4.0
 * Consolidated refactoring pipeline integrating:
 *   - Pattern Ingestion Helper (Template & Context Analysis)
 *   - Security Sanitizer Helper (Shannon Entropy & Key Redaction)
 *   - Refactoring Rules Helper (5-Pillar Structural Transformations)
 *   - AST Verification Helper (Symbol Retention & Structural Diff)
 *   - Code Review Helper (Security Reviewer vs Architecture Reviewer)
 *   - Convergence & Commit Helper (Proof Verification & Git Dispatch)
 *
 * Full Multi-File Batch Mutation Support:
 *   - Input target repository & base branch
 *   - Auto-select all repository files
 *   - Mutate all files through the complete single pipeline
 *   - Batch commit all mutated files to GitHub
 *   - Interactive user token prompts & verification
 */

import React, { useState, useEffect, useRef } from 'react';
import * as Sentry from '@sentry/react';
import {
  Play,
  RefreshCw,
  Check,
  CheckCircle2,
  AlertTriangle,
  Key,
  Cpu,
  Scale,
  Terminal,
  Code,
  Copy,
  Volume2,
  VolumeX,
  FileCode,
  ShieldCheck,
  Sparkles,
  Zap,
  GitCommit,
  Eye,
  EyeOff,
  ExternalLink,
  Box,
  Layers,
  Activity,
  Info,
  X,
  FolderTree,
  CheckSquare,
  Square,
  Search,
  ArrowRight,
  Shield,
  FileText,
} from 'lucide-react';

import {
  unifiedPipelineRunnerInstance,
  PipelineConfig,
  PipelineExecutionReport,
  PipelineStageState,
  PipelineStageId,
} from './core/unified-pipeline';
import { SIPHON_SOURCES } from './core/siphon';
import { VerificationKernelPanel } from './components/SovereignKernelPanel';
import { DebateChamber } from './components/DebateChamber';
import { AgentEnginesHub } from './components/AgentEnginesHub';
import { DosConsoleModal } from './components/DosConsoleModal';
import { AstDiffModal } from './components/AstDiffModal';
import { ArchitectureDocsPanel } from './components/ArchitectureDocsPanel';
import {
  playClickSound,
  playLaserSound,
  playSuccessSound,
  playErrorSound,
  playChirpSound,
  setSoundEnabled,
} from './emg/SoundEngine';

export interface RepoFileItem {
  path: string;
  size: number;
  sha?: string;
  isCodeFile: boolean;
  selected: boolean;
  status: 'idle' | 'fetching' | 'running' | 'completed' | 'blocked' | 'failed';
  content?: string;
  report?: PipelineExecutionReport;
  error?: string;
}

const DEFAULT_REPO_FILES: RepoFileItem[] = [
  {
    path: 'src/core/checksum.ts',
    size: 345,
    isCodeFile: true,
    selected: true,
    status: 'idle',
    content: `// Sample Target Module for Architecture Helper Refactoring
export function calculateChecksum(payload: string): string {
  let hash = 0;
  for (let i = 0; i < payload.length; i++) {
    hash = ((hash << 5) - hash) + payload.charCodeAt(i);
    hash |= 0;
  }
  return hash.toString(16);
}

export function verifyIntegrity(data: string, expected: string): boolean {
  return calculateChecksum(data) === expected;
}`,
  },
  {
    path: 'src/utils/auth-token.ts',
    size: 490,
    isCodeFile: true,
    selected: true,
    status: 'idle',
    content: `// Authentication Token Parser Helper
export function parseAuthHeader(headerValue: string): { scheme: string; token: string } | null {
  if (!headerValue || !headerValue.startsWith('Bearer ')) return null;
  const token = headerValue.slice(7).trim();
  return { scheme: 'Bearer', token };
}

export function sanitizeSecretDisplay(token: string): string {
  if (token.length <= 8) return '***';
  return token.slice(0, 4) + '...' + token.slice(-4);
}`,
  },
  {
    path: 'src/services/api-client.ts',
    size: 610,
    isCodeFile: true,
    selected: true,
    status: 'idle',
    content: `// Remote HTTP Client Service
export interface RequestOptions {
  timeoutMs?: number;
  headers?: Record<string, string>;
}

export async function requestJson<T>(url: string, options?: RequestOptions): Promise<T> {
  const response = await fetch(url, {
    headers: {
      'Accept': 'application/json',
      ...(options?.headers || {})
    }
  });
  if (!response.ok) throw new Error(\`HTTP \${response.status}\`);
  return response.json();
}`,
  },
  {
    path: 'src/engines/task-runner.ts',
    size: 520,
    isCodeFile: true,
    selected: true,
    status: 'idle',
    content: `// Task Execution Engine
export interface TaskDefinition {
  id: string;
  name: string;
  execute: () => Promise<void>;
}

export class TaskRunner {
  private queue: TaskDefinition[] = [];
  public register(task: TaskDefinition) {
    this.queue.push(task);
  }
  public async runAll(): Promise<number> {
    let count = 0;
    for (const t of this.queue) {
      await t.execute();
      count++;
    }
    return count;
  }
}`,
  },
  {
    path: 'src/models/user-profile.ts',
    size: 410,
    isCodeFile: true,
    selected: true,
    status: 'idle',
    content: `// User Profile Contract
export interface UserProfile {
  id: string;
  username: string;
  displayName: string;
  roles: string[];
  lastActiveAt: number;
}

export function hasAdminRole(profile: UserProfile): boolean {
  return profile.roles.includes('admin') || profile.roles.includes('superadmin');
}`,
  },
];

const PRESET_REPOS = [
  { name: 'craighckby-stack/test-1', label: 'test-1 (Default)' },
  { name: 'craighckby-stack/pattern-optimizer-helper', label: 'Pattern Optimizer' },
  { name: 'craighckby-stack/clean-room-agents-helper', label: 'Clean Room Runtime' },
];

export default function App() {
  // --- Pipeline Credentials & Configurations ---
  const [githubToken, setGithubToken] = useState('');
  const [showToken, setShowToken] = useState(false);
  const [geminiApiKey, setGeminiApiKey] = useState('');
  const [showApiKey, setShowApiKey] = useState(false);
  const [targetRepo, setTargetRepo] = useState('craighckby-stack/test-1');
  const [targetBranch, setTargetBranch] = useState('main');
  const [evolutionBranch, setEvolutionBranch] = useState('helper-evolution');
  const [userPrompt, setUserPrompt] = useState(
    'Apply Shannon entropy sanitization, AST symbol preservation, and 5-pillar modular agent loop'
  );
  const [siphonSourceId, setSiphonSourceId] = useState('pattern-optimizer-helper');

  // --- Repository Files & Batch State ---
  const [repoFiles, setRepoFiles] = useState<RepoFileItem[]>(DEFAULT_REPO_FILES);
  const [activeFilePath, setActiveFilePath] = useState<string>('src/core/checksum.ts');
  const [fileFilter, setFileFilter] = useState('');
  const [isLoadingRepoTree, setIsLoadingRepoTree] = useState(false);

  // --- GitHub Validation State & Prompts ---
  const [isVerifyingToken, setIsVerifyingToken] = useState(false);
  const [tokenStatus, setTokenStatus] = useState<{
    valid: boolean;
    username?: string;
    avatarUrl?: string;
    error?: string;
  } | null>(null);
  const [tokenPromptDismissed, setTokenPromptDismissed] = useState(false);
  const [showTokenModal, setShowTokenModal] = useState(false);
  const tokenInputRef = useRef<HTMLInputElement>(null);

  // --- Pipeline Execution State ---
  const [isRunning, setIsRunning] = useState(false);
  const [currentStageId, setCurrentStageId] = useState<PipelineStageId | null>(null);
  const [activeBatchIndex, setActiveBatchIndex] = useState<number | null>(null);
  const [batchProgress, setBatchProgress] = useState<{ current: number; total: number; currentFile: string } | null>(null);
  const [pipelineReport, setPipelineReport] = useState<PipelineExecutionReport | null>(null);
  const [activeTab, setActiveTab] = useState<'pipeline' | 'batch' | 'docs' | 'review' | 'governance' | 'engines' | 'logs'>('pipeline');
  const [logs, setLogs] = useState<Array<{ timestamp: string; message: string; type: 'info' | 'warn' | 'success' | 'error' }>>([]);
  const [maxCyclesInput, setMaxCyclesInput] = useState<number>(100);
  const [autoCommitOnComplete, setAutoCommitOnComplete] = useState<boolean>(true);
  const [governorCycles, setGovernorCycles] = useState(() => {
    unifiedPipelineRunnerInstance.setMaxCycles(100);
    return unifiedPipelineRunnerInstance.getGovernorCycles();
  });
  // --- Autonomous Background Loop State ---
  const [autoStatus, setAutoStatus] = useState<{
    enabled: boolean;
    intervalMinutes: number;
    targetRepo: string;
    branch: string;
    maxCycles: number;
    autoPush: boolean;
    lastRunTime: string | null;
    totalRuns: number;
    totalFilesCommitted: number;
    status: 'idle' | 'running' | 'paused' | 'error';
    logs: Array<{ timestamp: string; message: string; type: 'info' | 'warn' | 'success' | 'error' }>;
  }>({
    enabled: false,
    intervalMinutes: 10,
    targetRepo: 'craighckby-stack/test-1',
    branch: 'helper-evolution',
    maxCycles: 100,
    autoPush: true,
    lastRunTime: null,
    totalRuns: 0,
    totalFilesCommitted: 0,
    status: 'paused',
    logs: [],
  });

  const fetchAutoStatus = async () => {
    try {
      const res = await fetch('/api/autonomous/status');
      if (res.ok) {
        const data = await res.json();
        setAutoStatus(data);
      }
    } catch {
      // ignore
    }
  };

  const toggleAutoLoop = async (enable: boolean) => {
    playClickSound();
    try {
      const res = await fetch('/api/autonomous/config', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          enabled: enable,
          intervalMinutes: autoStatus.intervalMinutes,
          targetRepo: targetRepo || autoStatus.targetRepo,
          branch: evolutionBranch || autoStatus.branch,
          autoPush: true,
          maxCycles: maxCyclesInput,
        }),
      });
      if (res.ok) {
        const data = await res.json();
        setAutoStatus(data.config);
        playSuccessSound();
        addLog(enable ? 'Autonomous background self-enhancing loop ENABLED.' : 'Autonomous loop PAUSED.', 'info');
      }
    } catch {
      playErrorSound();
    }
  };

  const triggerAutoRunNow = async () => {
    playLaserSound();
    addLog('Triggering immediate autonomous background cycle...', 'info');
    try {
      await fetch('/api/autonomous/trigger', { method: 'POST' });
      fetchAutoStatus();
    } catch {
      // ignore
    }
  };

  const isCancelledRef = useRef(false);

  const handleStopPipeline = () => {
    isCancelledRef.current = true;
    playErrorSound();
    addLog('[PIPELINE ABORT] Stop requested by user. Terminating batch mutation loop...', 'warn');
  };

  const handleResetGovernor = () => {
    unifiedPipelineRunnerInstance.resetGovernor();
    setGovernorCycles(unifiedPipelineRunnerInstance.getGovernorCycles());
    playSuccessSound();
    addLog('Governor cycle limit reset to 0.', 'info');
  };

  useEffect(() => {
    fetchAutoStatus();
    const interval = setInterval(fetchAutoStatus, 10000);
    return () => clearInterval(interval);
  }, []);

  // --- Committing State ---
  const [isCommitting, setIsCommitting] = useState(false);
  const [commitSuccessMessage, setCommitSuccessMessage] = useState<string | null>(null);

  // --- Tool Modals & Sound ---
  const [isDosOpen, setIsDosOpen] = useState(false);
  const [isAstDiffOpen, setIsAstDiffOpen] = useState(false);
  const [isSoundMuted, setIsSoundMuted] = useState(false);

  const logsEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    logsEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [logs]);

  // Initial check for GitHub token via backend
  useEffect(() => {
    verifyGithubToken(false);
  }, []);

  const addLog = (message: string, type: 'info' | 'warn' | 'success' | 'error' = 'info') => {
    setLogs(prev => [
      ...prev,
      {
        timestamp: new Date().toLocaleTimeString(),
        message,
        type,
      },
    ]);
  };

  const verifyGithubToken = async (showNotifications = true) => {
    setIsVerifyingToken(true);
    try {
      const res = await fetch('/api/github/validate-token', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ token: githubToken || undefined }),
      });
      const data = await res.json();
      if (res.ok && data.valid) {
        setTokenStatus({ valid: true, username: data.username, avatarUrl: data.avatarUrl });
        if (showNotifications) {
          playSuccessSound();
          addLog(`GitHub token verified: @${data.username}`, 'success');
        }
      } else {
        setTokenStatus({ valid: false, error: data.error || 'Token not configured or invalid' });
        if (showNotifications) {
          playErrorSound();
          addLog(`GitHub token check: ${data.error || 'Not configured'}`, 'warn');
        }
      }
    } catch {
      setTokenStatus({ valid: false, error: 'Could not connect to GitHub API' });
    } finally {
      setIsVerifyingToken(false);
    }
  };

  // Scan target repository tree and AUTO SELECT ALL FILES
  const scanRepositoryTree = async () => {
    if (!targetRepo.trim()) return;
    setIsLoadingRepoTree(true);
    playClickSound();
    addLog(`Scanning repository file tree: ${targetRepo} (${targetBranch})...`, 'info');

    try {
      const res = await fetch('/api/github/repo-tree', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          repo: targetRepo,
          branch: targetBranch,
          token: githubToken || undefined,
        }),
      });

      if (res.ok) {
        const data = await res.json();
        const treeFiles: Array<{ path: string; size: number; sha: string; isCodeFile: boolean }> = data.files || [];

        if (treeFiles.length > 0) {
          // Auto-select code files by default to avoid corrupting binary or non-code blobs
          const newFiles: RepoFileItem[] = treeFiles.map(f => ({
            path: f.path,
            size: f.size,
            sha: f.sha,
            isCodeFile: f.isCodeFile,
            selected: f.isCodeFile,
            status: 'idle',
          }));

          setRepoFiles(newFiles);
          if (newFiles.length > 0) {
            const firstCodeFile = newFiles.find(f => f.isCodeFile) || newFiles[0];
            setActiveFilePath(firstCodeFile.path);
          }
          playSuccessSound();
          addLog(`Loaded ${newFiles.length} files from ${targetRepo}. ${newFiles.filter(f => f.isCodeFile).length} code files selected.`, 'success');
          return;
        }
      }

      // If remote tree failed or returned empty (e.g., token limit or private), preserve existing files with auto-select
      playChirpSound();
      addLog(`Remote tree notice: keeping default modular files for ${targetRepo}. All files auto-selected.`, 'warn');
      setRepoFiles(prev => prev.map(f => ({ ...f, selected: true })));
      if (!githubToken && !tokenStatus?.valid) {
        setShowTokenModal(true);
      }
    } catch (err) {
      playErrorSound();
      addLog(`Tree scan error: ${(err as Error).message}`, 'error');
    } finally {
      setIsLoadingRepoTree(false);
    }
  };

  // Toggle selection for all files
  const toggleSelectAll = (select: boolean) => {
    playClickSound();
    setRepoFiles(prev => prev.map(f => ({ ...f, selected: select })));
    addLog(select ? 'Auto-selected all repository files.' : 'Deselected all repository files.', 'info');
  };

  // Toggle single file selection
  const toggleFileSelected = (path: string) => {
    playClickSound();
    setRepoFiles(prev =>
      prev.map(f => (f.path === path ? { ...f, selected: !f.selected } : f))
    );
  };

  // Get active file object
  const activeFile = repoFiles.find(f => f.path === activeFilePath) || repoFiles[0];

  // Fetch single remote file content
  const fetchFileContent = async (fileItem: RepoFileItem): Promise<string> => {
    if (fileItem.content) return fileItem.content;

    try {
      const res = await fetch('/api/github/fetch-file', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          repo: targetRepo,
          path: fileItem.path,
          branch: targetBranch,
          token: githubToken || undefined,
        }),
      });

      if (res.ok) {
        const data = await res.json();
        const content = data.content || '';
        setRepoFiles(prev =>
          prev.map(f => (f.path === fileItem.path ? { ...f, content } : f))
        );
        return content;
      }
    } catch {
      // Fallback to placeholder code
    }

    const fallback = `// Source file: ${fileItem.path}\nexport interface TargetModuleContract {\n  readonly version: string;\n  readonly status: 'active';\n}\n\nexport function processData(input: string): string {\n  return input.trim();\n}`;
    setRepoFiles(prev =>
      prev.map(f => (f.path === fileItem.path ? { ...f, content: fallback } : f))
    );
    return fallback;
  };

  // MUTATE ALL SELECTED FILES IN WHOLE PIPELINE
  const handleMutateAllInPipeline = async () => {
    if (isRunning) return;
    const selectedFiles = repoFiles.filter(f => f.selected);

    if (selectedFiles.length === 0) {
      playErrorSound();
      addLog('No files selected. Please select at least one file or click Auto-Select All.', 'warn');
      return;
    }

    setIsRunning(true);
    setCommitSuccessMessage(null);
    playLaserSound();
    isCancelledRef.current = false;
    unifiedPipelineRunnerInstance.setMaxCycles(maxCyclesInput);
    unifiedPipelineRunnerInstance.resetGovernor();
    setGovernorCycles(unifiedPipelineRunnerInstance.getGovernorCycles());
    addLog(`[PIPELINE START] Mutating ${selectedFiles.length} file(s) across full single pipeline (Max Cycles: ${maxCyclesInput})...`, 'info');

    let completedCount = 0;

    for (let i = 0; i < selectedFiles.length; i++) {
      if (isCancelledRef.current) {
        addLog(`[PIPELINE ABORTED] Batch mutation stopped by user after ${completedCount} file(s).`, 'warn');
        break;
      }
      const targetFile = selectedFiles[i];
      setActiveBatchIndex(i);
      setActiveFilePath(targetFile.path);
      setBatchProgress({ current: i + 1, total: selectedFiles.length, currentFile: targetFile.path });

      // Mark file as running
      setRepoFiles(prev =>
        prev.map(f => (f.path === targetFile.path ? { ...f, status: 'running' } : f))
      );

      try {
        const fileContent = await fetchFileContent(targetFile);

        const config: PipelineConfig = {
          githubToken: githubToken || undefined,
          geminiApiKey: geminiApiKey || undefined,
          targetRepo,
          targetBranch,
          evolutionBranch,
          filePath: targetFile.path,
          userPrompt,
          siphonSourceId,
          code: fileContent,
        };

        const report = await unifiedPipelineRunnerInstance.runPipeline(
          config,
          stage => {
            setCurrentStageId(stage.id);
            if (stage.status === 'running') playChirpSound();
          },
          entry => {
            setLogs(prev => [...prev, entry]);
          }
        );

        setPipelineReport(report);
        const isOk = report.status === 'COMPLETED' || report.status === 'SANITIZED_APPLIED';

        setRepoFiles(prev =>
          prev.map(f =>
            f.path === targetFile.path
              ? {
                  ...f,
                  status: isOk ? 'completed' : 'blocked',
                  report,
                  content: report.evolvedCode,
                }
              : f
          )
        );

        completedCount++;
        playChirpSound();
      } catch (err) {
        setRepoFiles(prev =>
          prev.map(f =>
            f.path === targetFile.path
              ? { ...f, status: 'failed', error: (err as Error).message }
              : f
          )
        );
        addLog(`Error mutating ${targetFile.path}: ${(err as Error).message}`, 'error');
      }
    }

    setCurrentStageId(null);
    setActiveBatchIndex(null);
    setBatchProgress(null);
    setIsRunning(false);
    setGovernorCycles(unifiedPipelineRunnerInstance.getGovernorCycles());

    if (completedCount > 0) {
      playSuccessSound();
      addLog(`[PIPELINE COMPLETE] Successfully processed all ${completedCount} file(s) through whole pipeline.`, 'success');
      setActiveTab('batch');

      if (autoCommitOnComplete) {
        addLog(`[AUTO-PUSH] Auto-Push enabled: Automatically dispatching GitHub batch commit for mutated file(s)...`, 'info');
        setTimeout(() => {
          handleBatchCommit();
        }, 500);
      }
    } else {
      playErrorSound();
      addLog('Pipeline finished with errors.', 'error');
    }
  };

  // Run pipeline on single active file
  const handleRunActiveFile = async () => {
    if (isRunning || !activeFile) return;
    setIsRunning(true);
    setCommitSuccessMessage(null);
    playLaserSound();
    setGovernorCycles(unifiedPipelineRunnerInstance.getGovernorCycles());

    const fileContent = await fetchFileContent(activeFile);

    const config: PipelineConfig = {
      githubToken: githubToken || undefined,
      geminiApiKey: geminiApiKey || undefined,
      targetRepo,
      targetBranch,
      evolutionBranch,
      filePath: activeFile.path,
      userPrompt,
      siphonSourceId,
      code: fileContent,
    };

    try {
      const report = await unifiedPipelineRunnerInstance.runPipeline(
        config,
        stage => {
          setCurrentStageId(stage.id);
          if (stage.status === 'running') playChirpSound();
        },
        entry => {
          setLogs(prev => [...prev, entry]);
        }
      );

      setPipelineReport(report);
      setCurrentStageId(null);

      const isOk = report.status === 'COMPLETED' || report.status === 'SANITIZED_APPLIED';
      setRepoFiles(prev =>
        prev.map(f =>
          f.path === activeFile.path
            ? { ...f, status: isOk ? 'completed' : 'blocked', report, content: report.evolvedCode }
            : f
        )
      );

      if (isOk) {
        playSuccessSound();
      } else {
        playErrorSound();
      }
    } catch (e) {
      playErrorSound();
      addLog(`Pipeline error: ${(e as Error).message}`, 'error');
    } finally {
      setIsRunning(false);
    }
  };

  // Batch commit all mutated files
  const handleBatchCommit = async () => {
    const mutatedFiles = repoFiles.filter(f => f.status === 'completed' && f.report?.evolvedCode);

    if (mutatedFiles.length === 0) {
      playErrorSound();
      addLog('No mutated files ready to commit. Run the pipeline first.', 'warn');
      return;
    }

    if (!githubToken && !tokenStatus?.valid) {
      setShowTokenModal(true);
      playErrorSound();
      addLog('GitHub Personal Access Token required to dispatch commits.', 'warn');
      return;
    }

    setIsCommitting(true);
    playLaserSound();
    addLog(`Dispatching batch commit for ${mutatedFiles.length} files to ${evolutionBranch}...`, 'info');

    try {
      const payloadFiles = mutatedFiles.map(f => ({
        path: f.path,
        content: f.report!.evolvedCode,
        sha: f.sha,
      }));

      const res = await fetch('/api/github/batch-commit-files', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          repo: targetRepo,
          branch: evolutionBranch || targetBranch,
          files: payloadFiles,
          message: `Batch refactor ${mutatedFiles.length} files via Single Pipeline Helper`,
          token: githubToken || undefined,
        }),
      });

      const data = await res.json().catch(() => ({ error: `HTTP ${res.status}: ${res.statusText || 'Unable to parse server response'}` }));
      if (res.ok && data.committedCount > 0) {
        playSuccessSound();
        setCommitSuccessMessage(`Successfully committed ${data.committedCount}/${data.totalCount} files to branch ${evolutionBranch}!`);
        addLog(`Dispatched batch commit to GitHub repository ${targetRepo}`, 'success');
      } else {
        playErrorSound();
        addLog(`Batch commit issue: ${data.error || 'Check repository permissions'}`, 'error');
      }
    } catch (err) {
      playErrorSound();
      addLog(`Commit error: ${(err as Error).message}`, 'error');
    } finally {
      setIsCommitting(false);
    }
  };

  const selectedCount = repoFiles.filter(f => f.selected).length;
  const filteredFiles = repoFiles.filter(f =>
    f.path.toLowerCase().includes(fileFilter.toLowerCase())
  );

  return (
    <Sentry.ErrorBoundary
      fallback={({ error, resetError }) => (
        <div className="p-8 bg-zinc-950 text-zinc-100 min-h-screen flex flex-col items-center justify-center text-center gap-4">
          <AlertTriangle size={48} className="text-rose-500" />
          <h1 className="text-xl font-bold tracking-tight">Helper Pipeline Exception</h1>
          <p className="max-w-md text-xs text-zinc-400 font-mono">
            {(error as any)?.message || String(error)}
          </p>
          <button onClick={resetError} className="helper-btn w-auto px-6 py-2.5">
            Reset Environment
          </button>
        </div>
      )}
    >
      <div className="p-3 sm:p-6 flex flex-col items-center gap-5 min-h-screen bg-[#09090b] text-zinc-100">
        {/* Top Header Bar */}
        <header className="w-full max-w-[1700px] flex flex-col xl:flex-row items-center justify-between border-b border-zinc-800/80 pb-4 gap-4">
          <div className="flex items-center gap-3.5 self-start xl:self-auto">
            <div className="p-2.5 rounded-xl bg-gradient-to-br from-cyan-500/20 to-rose-500/10 border border-cyan-500/30 text-cyan-400 shadow-md">
              <Cpu size={22} />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="font-display text-lg sm:text-xl font-bold tracking-tight text-zinc-100">
                  Architecture Helper Pipeline
                </h1>
                <span className="text-xs font-mono font-medium text-cyan-400 bg-cyan-950/60 px-2 py-0.5 rounded-md border border-cyan-900/50">
                  v4.0.0
                </span>
              </div>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-3 w-full xl:w-auto justify-between xl:justify-end">
            {/* Quick Helper Tools & Governor Counter */}
            <div className="flex items-center gap-1.5 bg-zinc-950/80 p-1 border border-zinc-800/80 rounded-xl shadow-sm">
              <button
                onClick={() => { playClickSound(); setIsDosOpen(true); }}
                className="p-2 text-zinc-400 hover:text-zinc-100 rounded-lg hover:bg-zinc-900 transition-colors cursor-pointer"
                title="Open Terminal Helper"
              >
                <Terminal size={15} />
              </button>
              <button
                onClick={() => { playClickSound(); setIsAstDiffOpen(true); }}
                className="p-2 text-zinc-400 hover:text-amber-300 rounded-lg hover:bg-zinc-900 transition-colors cursor-pointer"
                title="Open AST Diff Helper"
              >
                <Code size={15} />
              </button>
              <button
                onClick={() => {
                  const nextMuted = !isSoundMuted;
                  setIsSoundMuted(nextMuted);
                  setSoundEnabled(!nextMuted);
                  if (!nextMuted) playChirpSound();
                }}
                className={`p-2 rounded-lg hover:bg-zinc-900 transition-colors cursor-pointer ${
                  !isSoundMuted ? 'text-cyan-400' : 'text-zinc-600'
                }`}
                title={isSoundMuted ? "Unmute Audio Feedback Helper" : "Mute Audio Feedback Helper"}
              >
                {isSoundMuted ? <VolumeX size={15} /> : <Volume2 size={15} />}
              </button>

              <div className="h-4 w-px bg-zinc-800 mx-1" />

              <div className="flex items-center gap-1.5 px-2 py-1 text-xs font-mono">
                <span className="text-zinc-500 text-[11px]">Cycles:</span>
                <span className={`font-semibold ${governorCycles.current >= 12 ? 'text-amber-400' : 'text-cyan-400'}`}>
                  {governorCycles.current}/{governorCycles.max}
                </span>
                <button
                  onClick={handleResetGovernor}
                  className="p-1 hover:text-cyan-300 text-zinc-500 rounded transition-colors"
                  title="Reset Governor loop cycle counter"
                >
                  <RefreshCw size={12} />
                </button>
              </div>
            </div>

            {/* Autonomous Background Loop Badge */}
            <button
              onClick={() => toggleAutoLoop(!autoStatus.enabled)}
              className={`flex items-center gap-2 text-xs font-mono px-3.5 py-2 border rounded-xl transition-all cursor-pointer ${
                autoStatus.enabled
                  ? 'bg-emerald-950/40 border-emerald-800/60 text-emerald-300'
                  : 'bg-zinc-950/80 border-zinc-800/80 text-zinc-400 hover:border-zinc-700'
              }`}
              title="Toggle Scheduled Autonomous Background Loop"
            >
              <RefreshCw size={13} className={autoStatus.enabled ? "text-emerald-400 animate-spin" : "text-zinc-500"} />
              <span>
                Auto Loop: <span className={autoStatus.enabled ? "text-emerald-400 font-bold" : "text-zinc-500"}>
                  {autoStatus.enabled ? `ON (${autoStatus.intervalMinutes}m)` : "OFF"}
                </span>
              </span>
            </button>

            {/* Token Prompt Status Badge */}
            <button
              onClick={() => { playClickSound(); setShowTokenModal(true); }}
              className="flex items-center gap-2 text-xs font-mono text-zinc-400 bg-zinc-950/80 px-3.5 py-2 border border-zinc-800/80 rounded-xl hover:border-zinc-700 transition-all cursor-pointer"
              title="Click to configure user GitHub Token"
            >
              <Key size={13} className={tokenStatus?.valid ? 'text-emerald-400' : 'text-amber-400'} />
              <span>
                {tokenStatus?.valid ? (
                  <span className="text-emerald-400 font-semibold">@{tokenStatus.username}</span>
                ) : (
                  <span className="text-amber-400 font-medium">Configure Token Prompt</span>
                )}
              </span>
              <span aria-hidden="true">·</span>
              <span className={`w-2 h-2 rounded-full ${isRunning ? 'bg-cyan-400 animate-pulse' : 'bg-emerald-400'}`} />
              <span className="text-zinc-200">{isRunning ? 'Mutating' : 'Ready'}</span>
            </button>
          </div>
        </header>

        {/* User Token Warning Banner */}
        {!tokenStatus?.valid && !tokenPromptDismissed && (
          <div className="w-full max-w-[1700px] bg-gradient-to-r from-cyan-950/40 via-zinc-950 to-amber-950/20 border border-cyan-800/40 p-4 rounded-2xl flex flex-col md:flex-row items-start md:items-center justify-between gap-3 shadow-lg">
            <div className="flex items-start gap-3">
              <div className="p-2 rounded-lg bg-cyan-500/10 text-cyan-400 mt-0.5">
                <Key size={16} />
              </div>
              <div>
                <h3 className="text-xs font-semibold text-zinc-100 flex items-center gap-2">
                  <span>GitHub Token Prompt: Unlock Full Repository Scanning</span>
                  <span className="text-[10px] bg-cyan-900/40 text-cyan-300 px-2 py-0.5 rounded border border-cyan-800/50">
                    Recommended
                  </span>
                </h3>
                <p className="text-xs text-zinc-400 mt-0.5 leading-relaxed">
                  Enter your GitHub Personal Access Token to auto-scan entire repositories, access private branches, and dispatch verified batch commits. You can also run the whole pipeline on default local files.
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2 self-end md:self-auto shrink-0">
              <button
                onClick={() => { playClickSound(); setShowTokenModal(true); }}
                className="px-3 py-1.5 bg-cyan-500 hover:bg-cyan-400 text-zinc-950 text-xs font-semibold rounded-lg shadow-sm flex items-center gap-1.5 transition-all cursor-pointer"
              >
                <Key size={13} />
                <span>Enter Token</span>
              </button>
              <button
                onClick={() => { playClickSound(); setTokenPromptDismissed(true); }}
                className="p-1.5 text-zinc-500 hover:text-zinc-300 transition-colors rounded-lg cursor-pointer"
                title="Dismiss prompt"
              >
                <X size={15} />
              </button>
            </div>
          </div>
        )}

        {/* Repository & Single Pipeline Configuration Card */}
        <section className="w-full max-w-[1700px] bg-zinc-950/80 border border-zinc-800/80 p-5 rounded-2xl shadow-xl space-y-4">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-2 border-b border-zinc-800/80 pb-3">
            <div>
              <h2 className="text-sm font-semibold text-zinc-200 flex items-center gap-2">
                <FolderTree size={16} className="text-cyan-400" />
                Target Repository &amp; File Selector Helper
              </h2>
              <p className="text-xs text-zinc-400 mt-0.5">
                Input your target repository. All repository files are auto-selected by default to mutate across the whole pipeline.
              </p>
            </div>

            {/* Quick Repository Presets */}
            <div className="flex flex-wrap items-center gap-1.5">
              <span className="text-[11px] text-zinc-500 font-mono">Presets:</span>
              {PRESET_REPOS.map(preset => (
                <button
                  key={preset.name}
                  onClick={() => {
                    playClickSound();
                    setTargetRepo(preset.name);
                  }}
                  className={`px-2 py-1 text-[11px] font-mono rounded-md border transition-all cursor-pointer ${
                    targetRepo === preset.name
                      ? 'bg-cyan-950/50 border-cyan-700 text-cyan-300'
                      : 'bg-zinc-900 border-zinc-800 text-zinc-400 hover:text-zinc-200'
                  }`}
                >
                  {preset.label}
                </button>
              ))}
            </div>
          </div>

          {/* Repo, Branch, Token, and Actions Row */}
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-3 text-xs">
            {/* Target Repository Input */}
            <div>
              <label className="font-medium text-zinc-400 block mb-1.5 flex items-center justify-between">
                <span>Target Repository</span>
                <span className="text-[10px] text-zinc-500 font-mono">owner/repo</span>
              </label>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={targetRepo}
                  onChange={e => setTargetRepo(e.target.value)}
                  placeholder="owner/repo"
                  className="helper-input flex-1 font-mono"
                />
                <button
                  type="button"
                  onClick={scanRepositoryTree}
                  disabled={isLoadingRepoTree}
                  className="px-3 bg-cyan-600 hover:bg-cyan-500 text-zinc-950 font-bold rounded-lg transition-all flex items-center gap-1 text-xs cursor-pointer disabled:opacity-50"
                  title="Scan & Auto-Select All Files in Target Repository"
                >
                  <RefreshCw size={12} className={isLoadingRepoTree ? "animate-spin" : ""} />
                  <span>Scan</span>
                </button>
              </div>
            </div>

            {/* Target & Evolution Branches */}
            <div>
              <label className="font-medium text-zinc-400 block mb-1.5 flex items-center justify-between">
                <span>Target &amp; Mutation Branches</span>
              </label>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={targetBranch}
                  onChange={e => setTargetBranch(e.target.value)}
                  placeholder="main"
                  className="helper-input w-24 font-mono text-xs"
                  title="Target source branch"
                />
                <input
                  type="text"
                  value={evolutionBranch}
                  onChange={e => setEvolutionBranch(e.target.value)}
                  placeholder="helper-evolution"
                  className="helper-input flex-1 font-mono text-xs"
                  title="Branch to dispatch commits to"
                />
              </div>
            </div>

            {/* User GitHub Token */}
            <div>
              <label className="font-medium text-zinc-400 block mb-1.5 flex items-center justify-between">
                <span>User GitHub Token</span>
                <button
                  type="button"
                  onClick={() => setShowTokenModal(true)}
                  className="text-[10px] text-cyan-400 hover:underline cursor-pointer"
                >
                  Prompt Helper
                </button>
              </label>
              <div className="relative">
                <input
                  ref={tokenInputRef}
                  type={showToken ? "text" : "password"}
                  value={githubToken}
                  onChange={e => setGithubToken(e.target.value)}
                  placeholder="ghp_************************************"
                  className="helper-input pr-9 font-mono"
                />
                <button
                  type="button"
                  onClick={() => setShowToken(!showToken)}
                  className="absolute right-2.5 top-2.5 text-zinc-500 hover:text-zinc-300 transition-colors cursor-pointer"
                >
                  {showToken ? <EyeOff size={14} /> : <Eye size={14} />}
                </button>
              </div>
            </div>

            {/* Pattern Helper Source */}
            <div>
              <label className="font-medium text-zinc-400 block mb-1.5 flex items-center justify-between">
                <span>Pattern Helper Source</span>
              </label>
              <select
                value={siphonSourceId}
                onChange={e => setSiphonSourceId(e.target.value)}
                className="helper-input font-mono bg-zinc-950/80 cursor-pointer"
              >
                {SIPHON_SOURCES.map(source => (
                  <option key={source.id} value={source.id}>
                    {source.label}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Goal Prompt */}
          <div>
            <label className="font-medium text-xs text-zinc-400 block mb-1.5">
              Pipeline Evolution Objective &amp; Goal Instruction
            </label>
            <input
              type="text"
              value={userPrompt}
              onChange={e => setUserPrompt(e.target.value)}
              placeholder="Instruction for autonomous refactoring and pattern selection..."
              className="helper-input text-xs"
            />
          </div>

          {/* Auto-Select All Files Bar */}
          <div className="bg-zinc-900/60 p-3.5 rounded-xl border border-zinc-800/80 space-y-3">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <span className="text-xs font-semibold text-zinc-200">
                  Repository Files:
                </span>
                <span className="text-xs font-mono px-2 py-0.5 rounded-md bg-cyan-950/80 border border-cyan-800/60 text-cyan-300 font-bold">
                  {selectedCount} / {repoFiles.length} Selected (Auto-Selected)
                </span>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => {
                    playClickSound();
                    setRepoFiles(prev => prev.map(f => ({ ...f, selected: f.isCodeFile })));
                  }}
                  className="px-2.5 py-1 text-xs bg-cyan-950/40 hover:bg-cyan-900/50 text-cyan-300 rounded-md border border-cyan-800/50 transition-all flex items-center gap-1 cursor-pointer"
                  title="Select recognized code source files only"
                >
                  <Code size={12} className="text-cyan-400" />
                  <span>Code Files Only</span>
                </button>
                <button
                  type="button"
                  onClick={() => toggleSelectAll(true)}
                  className="px-2.5 py-1 text-xs bg-zinc-800 hover:bg-zinc-700 text-zinc-200 rounded-md border border-zinc-700 transition-all flex items-center gap-1 cursor-pointer"
                >
                  <CheckSquare size={12} className="text-cyan-400" />
                  <span>Select All</span>
                </button>
                <button
                  type="button"
                  onClick={() => toggleSelectAll(false)}
                  className="px-2.5 py-1 text-xs bg-zinc-800 hover:bg-zinc-700 text-zinc-300 rounded-md border border-zinc-700 transition-all flex items-center gap-1 cursor-pointer"
                >
                  <Square size={12} className="text-zinc-400" />
                  <span>Deselect All</span>
                </button>

                <div className="relative">
                  <Search size={12} className="absolute left-2.5 top-2 text-zinc-500" />
                  <input
                    type="text"
                    value={fileFilter}
                    onChange={e => setFileFilter(e.target.value)}
                    placeholder="Filter files..."
                    className="pl-7 pr-2 py-1 bg-zinc-950 border border-zinc-800 rounded-md text-xs font-mono text-zinc-300 w-36 outline-none focus:border-cyan-500"
                  />
                </div>
              </div>
            </div>

            {/* File Chips Matrix */}
            <div className="flex flex-wrap gap-2 max-h-36 overflow-y-auto custom-scrollbar p-1">
              {filteredFiles.map(file => {
                const isActive = file.path === activeFilePath;
                return (
                  <div
                    key={file.path}
                    className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border text-xs font-mono transition-all cursor-pointer select-none ${
                      file.selected
                        ? isActive
                          ? 'bg-cyan-950/60 border-cyan-500 text-cyan-200 shadow-sm'
                          : 'bg-zinc-900 border-cyan-800/40 text-zinc-200 hover:border-cyan-700'
                        : 'bg-zinc-950/40 border-zinc-800/60 text-zinc-500 hover:border-zinc-700'
                    }`}
                  >
                    <button
                      type="button"
                      onClick={() => toggleFileSelected(file.path)}
                      className="p-0.5 hover:text-cyan-400 transition-colors"
                      title={file.selected ? "Deselect file" : "Select file"}
                    >
                      {file.selected ? (
                        <CheckSquare size={13} className="text-cyan-400" />
                      ) : (
                        <Square size={13} className="text-zinc-500" />
                      )}
                    </button>

                    <span
                      onClick={() => {
                        playClickSound();
                        setActiveFilePath(file.path);
                      }}
                      className="hover:underline flex items-center gap-1.5"
                    >
                      <FileCode size={12} className="text-zinc-400" />
                      <span>{file.path}</span>
                    </span>

                    {/* Status Badge */}
                    {file.status === 'running' && (
                      <RefreshCw size={11} className="text-cyan-400 animate-spin" />
                    )}
                    {file.status === 'completed' && (
                      <CheckCircle2 size={11} className="text-emerald-400" />
                    )}
                    {file.status === 'blocked' && (
                      <AlertTriangle size={11} className="text-amber-400" />
                    )}
                    {file.status === 'failed' && (
                      <X size={11} className="text-rose-400" />
                    )}
                  </div>
                );
              })}
            </div>
          </div>

          {/* Cycle Limit & Auto-Push Control Bar */}
          <div className="bg-zinc-900/60 p-3.5 rounded-xl border border-zinc-800/80 flex flex-col md:flex-row items-center justify-between gap-3 text-xs">
            <div className="flex flex-wrap items-center gap-2.5 w-full md:w-auto">
              <span className="text-zinc-300 font-semibold flex items-center gap-1.5">
                <RefreshCw size={13} className="text-amber-400" />
                <span>Max Cycles Limit:</span>
              </span>
              <div className="flex items-center gap-1.5">
                {[15, 50, 100, 200].map(val => (
                  <button
                    key={val}
                    type="button"
                    onClick={() => {
                      playClickSound();
                      setMaxCyclesInput(val);
                      unifiedPipelineRunnerInstance.setMaxCycles(val);
                      setGovernorCycles(unifiedPipelineRunnerInstance.getGovernorCycles());
                    }}
                    className={`px-2.5 py-1 text-xs font-mono rounded-md border transition-all cursor-pointer ${
                      maxCyclesInput === val
                        ? 'bg-cyan-950 border-cyan-500 text-cyan-300 font-bold shadow-sm'
                        : 'bg-zinc-950 border-zinc-800 text-zinc-400 hover:text-zinc-200'
                    }`}
                  >
                    {val}
                  </button>
                ))}
                <div className="flex items-center gap-1 ml-1.5">
                  <span className="text-zinc-500 text-[11px] font-mono">Custom:</span>
                  <input
                    type="number"
                    min={1}
                    max={1000}
                    value={maxCyclesInput}
                    onChange={e => {
                      const num = parseInt(e.target.value, 10) || 100;
                      setMaxCyclesInput(num);
                      unifiedPipelineRunnerInstance.setMaxCycles(num);
                      setGovernorCycles(unifiedPipelineRunnerInstance.getGovernorCycles());
                    }}
                    className="w-16 px-2 py-0.5 bg-zinc-950 border border-zinc-800 rounded text-xs font-mono text-cyan-300 outline-none focus:border-cyan-500"
                  />
                </div>
              </div>
            </div>

            <div className="flex items-center gap-3 w-full md:w-auto justify-start md:justify-end">
              <label className="flex items-center gap-2 text-xs font-medium text-zinc-200 cursor-pointer select-none bg-zinc-950/80 px-3 py-1.5 rounded-lg border border-zinc-800/80 hover:border-zinc-700 transition-all">
                <input
                  type="checkbox"
                  checked={autoCommitOnComplete}
                  onChange={e => {
                    playClickSound();
                    setAutoCommitOnComplete(e.target.checked);
                  }}
                  className="w-4 h-4 rounded border-zinc-700 bg-zinc-900 text-cyan-500 focus:ring-cyan-500/20 cursor-pointer accent-cyan-500"
                />
                <span className="flex items-center gap-1.5 font-mono">
                  <GitCommit size={14} className={autoCommitOnComplete ? "text-emerald-400" : "text-zinc-500"} />
                  <span>Auto-Push to GitHub on Complete</span>
                </span>
              </label>
            </div>
          </div>

          {/* Primary Multi-File Mutation Action Bar */}
          <div className="pt-2 flex flex-col sm:flex-row gap-3">
            <button
              onClick={handleMutateAllInPipeline}
              disabled={isRunning || selectedCount === 0}
              className="flex-1 py-3.5 px-6 bg-gradient-to-r from-cyan-600 via-cyan-500 to-amber-500 hover:opacity-95 text-zinc-950 font-bold text-sm rounded-xl shadow-lg shadow-cyan-500/20 flex items-center justify-center gap-2.5 transition-all active:scale-[0.99] disabled:opacity-60 disabled:pointer-events-none cursor-pointer"
            >
              {isRunning ? (
                <>
                  <RefreshCw size={16} className="animate-spin text-zinc-950" />
                  <span>
                    MUTATING IN WHOLE PIPELINE ({batchProgress ? `${batchProgress.current}/${batchProgress.total}: ${batchProgress.currentFile}` : 'RUNNING...'})
                  </span>
                </>
              ) : (
                <>
                  <Play size={16} fill="currentColor" />
                  <span>
                    MUTATE ALL IN WHOLE PIPELINE ({selectedCount} FILES AUTO-SELECTED)
                  </span>
                </>
              )}
            </button>

            {isRunning ? (
              <button
                onClick={handleStopPipeline}
                className="py-3.5 px-5 bg-rose-950/80 hover:bg-rose-900 text-rose-300 border border-rose-800 font-semibold text-xs rounded-xl flex items-center justify-center gap-2 transition-all cursor-pointer shadow-lg"
                title="Stop active pipeline execution"
              >
                <X size={16} />
                <span>Stop Pipeline</span>
              </button>
            ) : (
              <button
                onClick={handleRunActiveFile}
                disabled={isRunning || !activeFile}
                className="py-3.5 px-5 bg-zinc-900 hover:bg-zinc-800 text-zinc-200 border border-zinc-700/80 font-semibold text-xs rounded-xl flex items-center justify-center gap-2 transition-all cursor-pointer disabled:opacity-50"
                title={`Mutate only active file: ${activeFilePath}`}
              >
                <Zap size={14} className="text-amber-400" />
                <span>Mutate Active File Only</span>
              </button>
            )}
          </div>
        </section>

        {/* Live Visual Pipeline Stepper */}
        <section className="w-full max-w-[1700px] bg-zinc-950/80 border border-zinc-800/80 p-5 rounded-2xl shadow-xl space-y-3">
          <div className="flex items-center justify-between border-b border-zinc-800/80 pb-2.5">
            <div className="flex items-center gap-2">
              <Layers size={14} className="text-cyan-400" />
              <h3 className="text-xs font-semibold uppercase tracking-wider text-zinc-400 font-mono">
                Single Pipeline Helper Stages
              </h3>
              {batchProgress && (
                <span className="text-xs font-mono text-cyan-300 font-bold bg-cyan-950 px-2 py-0.5 rounded border border-cyan-800/80">
                  File {batchProgress.current}/{batchProgress.total}: {batchProgress.currentFile}
                </span>
              )}
            </div>

            {pipelineReport && (
              <span className={`text-xs font-mono font-bold px-2.5 py-0.5 rounded-md ${
                pipelineReport.status === 'COMPLETED' ? 'text-emerald-400 bg-emerald-950/60 border border-emerald-900/50' :
                pipelineReport.status === 'SANITIZED_APPLIED' ? 'text-amber-400 bg-amber-950/60 border border-amber-900/50' :
                'text-rose-400 bg-rose-950/60 border border-rose-900/50'
              }`}>
                Report: {pipelineReport.status}
              </span>
            )}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-6 gap-3">
            {[
              { id: 'stage0_ingestion', num: '0', title: 'Pattern Ingestion', desc: 'Template & Context Analysis' },
              { id: 'stage1_sanitization', num: '1', title: 'Entropy Sanitizer', desc: 'Shannon Key Redaction' },
              { id: 'stage2_reasoning', num: '2', title: 'Refactoring Engine', desc: '5-Pillar Rule Transformations' },
              { id: 'stage3_ast_gate', num: '3', title: 'AST Verification', desc: 'Symbol & Drift Retention' },
              { id: 'stage4_review', num: '4', title: 'Dual Code Review', desc: 'Security vs Architecture' },
              { id: 'stage5_convergence', num: '5', title: 'Commit Dispatch', desc: 'Proof Hash & GitHub Sync' },
            ].map(stage => {
              const stageState = pipelineReport?.stages[stage.id as PipelineStageId];
              const isCurrent = currentStageId === stage.id;
              const isSucceeded = stageState?.status === 'succeeded';
              const isBlocked = stageState?.status === 'blocked';

              return (
                <div
                  key={stage.id}
                  className={`p-3.5 rounded-xl border transition-all flex flex-col justify-between min-h-[95px] ${
                    isCurrent
                      ? 'bg-cyan-950/30 border-cyan-500 shadow-md shadow-cyan-500/10'
                      : isSucceeded
                      ? 'bg-emerald-950/20 border-emerald-900/50'
                      : isBlocked
                      ? 'bg-rose-950/20 border-rose-900/50'
                      : 'bg-zinc-900/40 border-zinc-800/70'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="font-mono text-[11px] font-bold text-zinc-500">
                      STAGE {stage.num}
                    </span>
                    {isCurrent ? (
                      <RefreshCw size={13} className="text-cyan-400 animate-spin" />
                    ) : isSucceeded ? (
                      <CheckCircle2 size={13} className="text-emerald-400" />
                    ) : isBlocked ? (
                      <AlertTriangle size={13} className="text-rose-400" />
                    ) : (
                      <span className="w-2 h-2 rounded-full bg-zinc-800" />
                    )}
                  </div>

                  <div className="mt-2">
                    <div className="font-semibold text-xs text-zinc-200">{stage.title}</div>
                    <div className="text-[11px] text-zinc-500 truncate mt-0.5">{stageState?.summary || stage.desc}</div>
                  </div>

                  {stageState?.durationMs !== undefined && (
                    <div className="text-[10px] font-mono text-zinc-600 mt-1">
                      {stageState.durationMs}ms
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </section>

        {/* Workbench Tabs Navigation */}
        <div className="w-full max-w-[1700px] flex items-center justify-between border-b border-zinc-800 pb-2">
          <div className="flex gap-1.5 p-1 bg-zinc-950/80 border border-zinc-800/80 rounded-xl overflow-x-auto custom-scrollbar">
            <button
              onClick={() => { playClickSound(); setActiveTab('pipeline'); }}
              className={`px-3.5 py-1.5 text-xs font-medium rounded-lg transition-all flex items-center gap-2 cursor-pointer ${
                activeTab === 'pipeline'
                  ? 'bg-zinc-800 text-cyan-300 shadow-sm border border-zinc-700/60 font-semibold'
                  : 'text-zinc-400 hover:text-zinc-200 hover:bg-zinc-900/40'
              }`}
            >
              <Activity size={13} className="text-cyan-400" />
              <span>Pipeline Workbench</span>
            </button>

            <button
              onClick={() => { playClickSound(); setActiveTab('batch'); }}
              className={`px-3.5 py-1.5 text-xs font-medium rounded-lg transition-all flex items-center gap-2 cursor-pointer ${
                activeTab === 'batch'
                  ? 'bg-zinc-800 text-emerald-300 shadow-sm border border-zinc-700/60 font-semibold'
                  : 'text-zinc-400 hover:text-zinc-200 hover:bg-zinc-900/40'
              }`}
            >
              <FolderTree size={13} className="text-emerald-400" />
              <span>Batch Files ({repoFiles.filter(f => f.status === 'completed').length})</span>
            </button>

            <button
              onClick={() => { playClickSound(); setActiveTab('docs'); }}
              className={`px-3.5 py-1.5 text-xs font-medium rounded-lg transition-all flex items-center gap-2 cursor-pointer ${
                activeTab === 'docs'
                  ? 'bg-zinc-800 text-sky-300 shadow-sm border border-zinc-700/60 font-semibold'
                  : 'text-zinc-400 hover:text-zinc-200 hover:bg-zinc-900/40'
              }`}
            >
              <FileText size={13} className="text-sky-400" />
              <span>Architecture Documentation</span>
            </button>

            <button
              onClick={() => { playClickSound(); setActiveTab('review'); }}
              className={`px-3.5 py-1.5 text-xs font-medium rounded-lg transition-all flex items-center gap-2 cursor-pointer ${
                activeTab === 'review'
                  ? 'bg-zinc-800 text-rose-300 shadow-sm border border-zinc-700/60 font-semibold'
                  : 'text-zinc-400 hover:text-zinc-200 hover:bg-zinc-900/40'
              }`}
            >
              <Scale size={13} className="text-rose-400" />
              <span>Security &amp; AST Inspector</span>
            </button>

            <button
              onClick={() => { playClickSound(); setActiveTab('governance'); }}
              className={`px-3.5 py-1.5 text-xs font-medium rounded-lg transition-all flex items-center gap-2 cursor-pointer ${
                activeTab === 'governance'
                  ? 'bg-zinc-800 text-amber-300 shadow-sm border border-zinc-700/60 font-semibold'
                  : 'text-zinc-400 hover:text-zinc-200 hover:bg-zinc-900/40'
              }`}
            >
              <Zap size={13} className="text-amber-400" />
              <span>Execution Governance</span>
            </button>

            <button
              onClick={() => { playClickSound(); setActiveTab('engines'); }}
              className={`px-3.5 py-1.5 text-xs font-medium rounded-lg transition-all flex items-center gap-2 cursor-pointer ${
                activeTab === 'engines'
                  ? 'bg-zinc-800 text-cyan-300 shadow-sm border border-zinc-700/60 font-semibold'
                  : 'text-zinc-400 hover:text-zinc-200 hover:bg-zinc-900/40'
              }`}
            >
              <Box size={13} className="text-cyan-400" />
              <span>Refactoring Rules Catalog</span>
            </button>

            <button
              onClick={() => { playClickSound(); setActiveTab('logs'); }}
              className={`px-3.5 py-1.5 text-xs font-medium rounded-lg transition-all flex items-center gap-2 cursor-pointer ${
                activeTab === 'logs'
                  ? 'bg-zinc-800 text-zinc-100 shadow-sm border border-zinc-700/60 font-semibold'
                  : 'text-zinc-400 hover:text-zinc-200 hover:bg-zinc-900/40'
              }`}
            >
              <Terminal size={13} className="text-zinc-400" />
              <span>Execution Logs ({logs.length})</span>
            </button>
          </div>

          {/* Batch Commit Button */}
          <div className="flex items-center gap-2">
            <button
              onClick={handleBatchCommit}
              disabled={isCommitting || repoFiles.filter(f => f.status === 'completed').length === 0}
              className="py-1.5 px-3 bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 rounded-lg text-xs font-medium flex items-center gap-1.5 transition-all active:scale-[0.98] cursor-pointer disabled:opacity-50"
            >
              <GitCommit size={14} className={isCommitting ? "animate-spin" : ""} />
              <span>{isCommitting ? "Committing..." : `Batch Commit Mutated Files (${repoFiles.filter(f => f.status === 'completed').length})`}</span>
            </button>
          </div>
        </div>

        {/* Commit Success Banner */}
        {commitSuccessMessage && (
          <div className="w-full max-w-[1700px] bg-emerald-950/30 border border-emerald-900/50 p-3 rounded-xl text-xs text-emerald-300 flex items-center justify-between animate-in fade-in">
            <span className="flex items-center gap-2">
              <CheckCircle2 size={16} className="text-emerald-400" />
              {commitSuccessMessage}
            </span>
            <button
              onClick={() => setCommitSuccessMessage(null)}
              className="text-emerald-400 hover:text-emerald-200 text-xs cursor-pointer"
            >
              Dismiss
            </button>
          </div>
        )}

        {/* Main Content Areas */}
        <main className="w-full max-w-[1700px] flex-1">
          {/* TAB 1: SINGLE PIPELINE & CODE VIEWER */}
          {activeTab === 'pipeline' && (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
              {/* Left Side: Side-by-Side Code Viewer */}
              <div className="lg:col-span-8 space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {/* Baseline Source */}
                  <div className="panel-container">
                    <div className="panel-header">
                      <div className="flex items-center gap-2">
                        <FileCode size={14} className="text-zinc-400" />
                        <span className="truncate max-w-[200px]">{activeFilePath}</span>
                      </div>
                      <span className="font-mono text-zinc-500 text-[11px]">
                        {activeFile?.content?.length || 0} bytes
                      </span>
                    </div>
                    <textarea
                      value={activeFile?.content || ''}
                      onChange={e => {
                        const val = e.target.value;
                        setRepoFiles(prev =>
                          prev.map(f => (f.path === activeFilePath ? { ...f, content: val } : f))
                        );
                      }}
                      rows={18}
                      className="w-full p-4 font-mono text-xs text-zinc-300 leading-relaxed bg-zinc-950/90 border-none outline-none resize-none custom-scrollbar select-text"
                      placeholder="// Source code will appear here..."
                    />
                  </div>

                  {/* Refactored Mutated Output */}
                  <div className="panel-container">
                    <div className="panel-header">
                      <div className="flex items-center gap-2">
                        <Sparkles size={14} className="text-cyan-400" />
                        <span className="text-cyan-300">Refactored Mutation</span>
                      </div>
                      <div className="flex items-center gap-2">
                        {activeFile?.report?.proofCommitHash && (
                          <span className="font-mono text-emerald-400 text-[11px] font-bold">
                            Hash: {activeFile.report.proofCommitHash}
                          </span>
                        )}
                        <button
                          onClick={() => {
                            if (activeFile?.report?.evolvedCode) {
                              navigator.clipboard.writeText(activeFile.report.evolvedCode);
                              addLog(`Refactored code for ${activeFilePath} copied to clipboard.`, 'success');
                            }
                          }}
                          className="p-1 hover:text-cyan-300 transition-colors cursor-pointer"
                          title="Copy refactored code"
                        >
                          <Copy size={13} />
                        </button>
                      </div>
                    </div>
                    <textarea
                      value={activeFile?.report?.evolvedCode || "// Mutated output will appear here after pipeline execution"}
                      readOnly
                      rows={18}
                      className="w-full p-4 font-mono text-xs text-cyan-200/90 leading-relaxed bg-zinc-950/90 border-none outline-none resize-none custom-scrollbar select-text"
                    />
                  </div>
                </div>
              </div>

              {/* Right Side: Telemetry & Live Activity */}
              <div className="lg:col-span-4 space-y-4">
                <div className="bg-zinc-950/80 border border-zinc-800/80 p-5 rounded-xl shadow-lg space-y-4">
                  <h3 className="font-semibold text-xs uppercase tracking-wider text-zinc-400 font-mono flex items-center gap-2">
                    <ShieldCheck size={14} className="text-emerald-400" />
                    Verification Gate Telemetry
                  </h3>

                  <div className="grid grid-cols-2 gap-3 text-xs">
                    <div className="bg-zinc-900/60 p-3 rounded-lg border border-zinc-800/70">
                      <span className="text-zinc-500 block text-[11px]">AST Score</span>
                      <span className="text-base font-bold font-mono text-cyan-400 mt-0.5 block">
                        {activeFile?.report ? `${activeFile.report.astDiffResult.astScore}/100` : '--/100'}
                      </span>
                    </div>

                    <div className="bg-zinc-900/60 p-3 rounded-lg border border-zinc-800/70">
                      <span className="text-zinc-500 block text-[11px]">Symbol Retention</span>
                      <span className="text-base font-bold font-mono text-emerald-400 mt-0.5 block">
                        {activeFile?.report
                          ? `${activeFile.report.astDiffResult.symbolMap.retainedCount}/${activeFile.report.astDiffResult.symbolMap.originalCount}`
                          : '--/--'}
                      </span>
                    </div>

                    <div className="bg-zinc-900/60 p-3 rounded-lg border border-zinc-800/70">
                      <span className="text-zinc-500 block text-[11px]">Review Consensus</span>
                      <span className="text-base font-bold font-mono text-amber-400 mt-0.5 block">
                        {activeFile?.report
                          ? `${(activeFile.report.reviewVerdict.consensusCoefficient * 100).toFixed(0)}%`
                          : '--%'}
                      </span>
                    </div>

                    <div className="bg-zinc-900/60 p-3 rounded-lg border border-zinc-800/70">
                      <span className="text-zinc-500 block text-[11px]">Proof Commit</span>
                      <span className="text-sm font-bold font-mono text-emerald-400 mt-0.5 block truncate">
                        {activeFile?.report?.proofCommitHash || '--'}
                      </span>
                    </div>
                  </div>

                  {activeFile?.report && (
                    <div className="pt-2 border-t border-zinc-800/80 space-y-2">
                      <div className="text-xs">
                        <span className="text-zinc-500 block">Selected Pattern Helper:</span>
                        <span className="text-cyan-300 font-medium">
                          {activeFile.report.patternVote.source.label}
                        </span>
                      </div>
                      <div className="text-xs">
                        <span className="text-zinc-500 block">Review Summary:</span>
                        <span className="text-zinc-300 italic">
                          "{activeFile.report.reviewVerdict.leadSummary}"
                        </span>
                      </div>
                    </div>
                  )}
                </div>

                {/* Mini Activity Stream */}
                <div className="bg-zinc-950/80 border border-zinc-800/80 p-4 rounded-xl shadow-lg space-y-2">
                  <div className="flex items-center justify-between border-b border-zinc-800/80 pb-2">
                    <span className="text-xs font-semibold text-zinc-400 font-mono">Live Activity Stream</span>
                    <button
                      onClick={() => setActiveTab('logs')}
                      className="text-[11px] text-cyan-400 hover:underline cursor-pointer"
                    >
                      View All Logs
                    </button>
                  </div>
                  <div className="space-y-1 font-mono text-[11px] text-zinc-400 max-h-48 overflow-y-auto custom-scrollbar">
                    {logs.length === 0 ? (
                      <div className="text-zinc-600 italic py-2">Pipeline standing by...</div>
                    ) : (
                      logs.slice(-6).map((log, i) => (
                        <div key={i} className="leading-relaxed">
                          <span className="text-zinc-600 mr-2">[{log.timestamp}]</span>
                          <span className={
                            log.type === 'success' ? 'text-emerald-400' :
                            log.type === 'warn' ? 'text-amber-400' :
                            log.type === 'error' ? 'text-rose-400' : 'text-zinc-300'
                          }>
                            {log.message}
                          </span>
                        </div>
                      ))
                    )}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: BATCH MUTATED FILES MATRIX */}
          {activeTab === 'batch' && (
            <div className="panel-container p-5 space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-zinc-800 pb-3">
                <div>
                  <h3 className="font-semibold text-sm text-zinc-100 flex items-center gap-2">
                    <FolderTree size={16} className="text-emerald-400" />
                    Batch Mutated Files Matrix
                  </h3>
                  <p className="text-xs text-zinc-400 mt-0.5">
                    Overview of all mutated files across the whole pipeline with verification scores and proof hashes.
                  </p>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={handleBatchCommit}
                    disabled={isCommitting || repoFiles.filter(f => f.status === 'completed').length === 0}
                    className="py-1.5 px-3 bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 rounded-lg text-xs font-medium flex items-center gap-1.5 transition-all cursor-pointer disabled:opacity-50"
                  >
                    <GitCommit size={14} className={isCommitting ? "animate-spin" : ""} />
                    <span>Commit All Mutated Files</span>
                  </button>
                </div>
              </div>

              <div className="overflow-x-auto custom-scrollbar">
                <table className="w-full text-xs text-left">
                  <thead className="bg-zinc-900/80 text-zinc-400 font-mono text-[11px] uppercase border-b border-zinc-800">
                    <tr>
                      <th className="p-3">File Path</th>
                      <th className="p-3">Status</th>
                      <th className="p-3">AST Score</th>
                      <th className="p-3">Entropy Sanitizer</th>
                      <th className="p-3">Review Verdict</th>
                      <th className="p-3">Proof Hash</th>
                      <th className="p-3 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-zinc-800/60 font-mono">
                    {repoFiles.map(file => {
                      const rep = file.report;
                      return (
                        <tr key={file.path} className="hover:bg-zinc-900/40 transition-colors">
                          <td className="p-3 font-semibold text-zinc-200">
                            {file.path}
                          </td>
                          <td className="p-3">
                            <span className={`px-2 py-0.5 rounded text-[11px] font-bold ${
                              file.status === 'completed' ? 'bg-emerald-950/80 text-emerald-400 border border-emerald-900/60' :
                              file.status === 'running' ? 'bg-cyan-950/80 text-cyan-400 border border-cyan-900/60' :
                              file.status === 'blocked' ? 'bg-amber-950/80 text-amber-400 border border-amber-900/60' :
                              file.status === 'failed' ? 'bg-rose-950/80 text-rose-400 border border-rose-900/60' :
                              'bg-zinc-900 text-zinc-500'
                            }`}>
                              {file.status.toUpperCase()}
                            </span>
                          </td>
                          <td className="p-3 text-cyan-300">
                            {rep ? `${rep.astDiffResult.astScore}/100` : '--'}
                          </td>
                          <td className="p-3">
                            {rep ? (
                              <span className={rep.sanitizerResult.clean ? 'text-emerald-400' : 'text-amber-400'}>
                                {rep.sanitizerResult.clean ? 'Clean (0 Leaks)' : `Redacted (${rep.sanitizerResult.violations.length})`}
                              </span>
                            ) : '--'}
                          </td>
                          <td className="p-3">
                            {rep ? (
                              <span className={rep.reviewVerdict.consensus === 'APPROVED' ? 'text-emerald-400' : 'text-amber-400'}>
                                {rep.reviewVerdict.consensus}
                              </span>
                            ) : '--'}
                          </td>
                          <td className="p-3 text-emerald-400 font-bold">
                            {rep?.proofCommitHash || '--'}
                          </td>
                          <td className="p-3 text-right">
                            <button
                              onClick={() => {
                                playClickSound();
                                setActiveFilePath(file.path);
                                setActiveTab('pipeline');
                              }}
                              className="px-2 py-1 bg-zinc-800 hover:bg-zinc-700 text-cyan-300 rounded text-[11px] font-sans transition-all cursor-pointer"
                            >
                              Inspect Code
                            </button>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* TAB: SYSTEM ARCHITECTURE & AUDIT DOCUMENTATION */}
          {activeTab === 'docs' && (
            <div className="panel-container p-5">
              <ArchitectureDocsPanel />
            </div>
          )}

          {/* TAB 3: CODE REVIEW HELPER */}
          {activeTab === 'review' && (
            <div className="panel-container p-5">
              <DebateChamber
                onApplyVerdict={verdict => {
                  addLog(`Review consensus applied: ${verdict.consensus}`, 'success');
                }}
              />
            </div>
          )}

          {/* TAB 4: GOVERNANCE & VERIFICATION HELPER */}
          {activeTab === 'governance' && (
            <div className="panel-container p-5">
              <VerificationKernelPanel
                activeFile={activeFile ? { path: activeFile.path, content: activeFile.content } : undefined}
                onResetGovernor={handleResetGovernor}
                governorCycles={governorCycles}
              />
            </div>
          )}

          {/* TAB 5: MODULAR AGENT ENGINES HELPER */}
          {activeTab === 'engines' && (
            <div className="panel-container p-5">
              <AgentEnginesHub />
            </div>
          )}

          {/* TAB 6: EXECUTION LOGS HELPER */}
          {activeTab === 'logs' && (
            <div className="panel-container p-5 space-y-3">
              <div className="flex items-center justify-between border-b border-zinc-800 pb-3">
                <div className="flex items-center gap-2">
                  <Terminal size={16} className="text-cyan-400" />
                  <h3 className="font-semibold text-xs text-zinc-200">
                    Comprehensive Pipeline Execution Log
                  </h3>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => {
                      const text = logs.map(l => `[${l.timestamp}] [${l.type}] ${l.message}`).join('\n');
                      navigator.clipboard.writeText(text);
                      addLog("All logs copied to clipboard.", "success");
                    }}
                    className="px-3 py-1 bg-zinc-900 border border-zinc-700/80 text-zinc-300 rounded-lg text-xs hover:bg-zinc-800 transition-all cursor-pointer"
                  >
                    Copy Logs
                  </button>
                  <button
                    onClick={() => setLogs([])}
                    className="px-3 py-1 bg-zinc-900 border border-zinc-700/80 text-zinc-400 rounded-lg text-xs hover:text-rose-300 transition-all cursor-pointer"
                  >
                    Clear Logs
                  </button>
                </div>
              </div>

              <div className="h-[480px] overflow-y-auto font-mono text-xs text-zinc-300 space-y-1.5 p-4 bg-zinc-950/90 rounded-xl border border-zinc-800/80 custom-scrollbar leading-relaxed">
                {logs.length === 0 ? (
                  <div className="text-zinc-600 text-center py-10 italic">No execution logs recorded yet.</div>
                ) : (
                  logs.map((log, i) => (
                    <div key={i} className="flex gap-2.5">
                      <span className="text-zinc-600 select-none">[{log.timestamp}]</span>
                      <span className={`flex-1 ${
                        log.type === 'success' ? 'text-emerald-400' :
                        log.type === 'warn' ? 'text-amber-400' :
                        log.type === 'error' ? 'text-rose-400' : 'text-zinc-300'
                      }`}>
                        {log.message}
                      </span>
                    </div>
                  ))
                )}
                <div ref={logsEndRef} />
              </div>
            </div>
          )}
        </main>

        {/* GitHub Token Prompt Modal */}
        {showTokenModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-md p-4 animate-in fade-in duration-200">
            <div className="w-full max-w-lg bg-zinc-950 border border-zinc-800 shadow-2xl rounded-2xl overflow-hidden text-xs">
              <div className="bg-zinc-900/90 border-b border-zinc-800 px-5 py-4 flex items-center justify-between text-zinc-200">
                <div className="flex items-center gap-2">
                  <Key size={16} className="text-cyan-400" />
                  <span className="font-semibold text-sm">GitHub Personal Access Token Prompt Helper</span>
                </div>
                <button
                  onClick={() => setShowTokenModal(false)}
                  className="text-zinc-400 hover:text-zinc-100 p-1 rounded-md hover:bg-zinc-800 transition-colors cursor-pointer"
                >
                  <X size={16} />
                </button>
              </div>

              <div className="p-5 space-y-4 text-zinc-300">
                <p className="text-xs leading-relaxed text-zinc-400">
                  A GitHub Personal Access Token allows the Single Pipeline Helper to inspect remote repositories, auto-select all repository files, and dispatch verified refactoring commits back to your repository branch.
                </p>

                <div className="bg-zinc-900/60 p-3.5 rounded-xl border border-zinc-800/80 space-y-2">
                  <div className="font-semibold text-zinc-200 text-xs flex items-center gap-1.5">
                    <Info size={14} className="text-cyan-400" />
                    <span>How to generate your token:</span>
                  </div>
                  <ol className="list-decimal list-inside space-y-1 text-zinc-400 text-[11px] leading-relaxed">
                    <li>Go to GitHub → Settings → Developer Settings</li>
                    <li>Select <strong>Personal access tokens</strong> → <strong>Tokens (classic)</strong></li>
                    <li>Generate a new token with the <strong>repo</strong> scope</li>
                    <li>Paste your token below and click <strong>Save &amp; Verify</strong></li>
                  </ol>
                  <a
                    href="https://github.com/settings/tokens/new?scopes=repo&description=Architecture-Helper-Pipeline"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1 text-[11px] text-cyan-400 hover:underline pt-1"
                  >
                    <span>Create token on GitHub</span>
                    <ExternalLink size={11} />
                  </a>
                </div>

                <div className="space-y-1.5">
                  <label className="font-medium text-zinc-300 block">Personal Access Token</label>
                  <div className="relative">
                    <input
                      type={showToken ? "text" : "password"}
                      value={githubToken}
                      onChange={e => setGithubToken(e.target.value)}
                      placeholder="ghp_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"
                      className="helper-input pr-9 font-mono"
                    />
                    <button
                      type="button"
                      onClick={() => setShowToken(!showToken)}
                      className="absolute right-2.5 top-2.5 text-zinc-500 hover:text-zinc-300 transition-colors cursor-pointer"
                    >
                      {showToken ? <EyeOff size={14} /> : <Eye size={14} />}
                    </button>
                  </div>
                  {tokenStatus && !tokenStatus.valid && (
                    <p className="text-[11px] text-rose-400 mt-1">
                      {tokenStatus.error}
                    </p>
                  )}
                  {tokenStatus && tokenStatus.valid && (
                    <p className="text-[11px] text-emerald-400 mt-1 flex items-center gap-1">
                      <Check size={12} /> Verified as @{tokenStatus.username}
                    </p>
                  )}
                </div>

                <div className="flex gap-2 pt-2 border-t border-zinc-800">
                  <button
                    onClick={() => {
                      verifyGithubToken(true);
                      if (githubToken) {
                        setShowTokenModal(false);
                        scanRepositoryTree();
                      }
                    }}
                    disabled={isVerifyingToken}
                    className="flex-1 py-2.5 bg-cyan-500 hover:bg-cyan-400 text-zinc-950 font-semibold text-xs rounded-lg transition-all flex items-center justify-center gap-1.5 cursor-pointer disabled:opacity-50"
                  >
                    <RefreshCw size={12} className={isVerifyingToken ? "animate-spin" : ""} />
                    <span>Save, Verify &amp; Scan Files</span>
                  </button>
                  <button
                    onClick={() => setShowTokenModal(false)}
                    className="py-2.5 px-4 bg-zinc-900 hover:bg-zinc-800 text-zinc-300 font-medium text-xs rounded-lg border border-zinc-700/80 transition-all cursor-pointer"
                  >
                    Close
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Developer Terminal Helper Modal */}
        <DosConsoleModal
          isOpen={isDosOpen}
          onClose={() => setIsDosOpen(false)}
          targetRepo={targetRepo}
          files={repoFiles}
        />

        {/* AST Diff Gate Helper Modal */}
        <AstDiffModal
          isOpen={isAstDiffOpen}
          onClose={() => setIsAstDiffOpen(false)}
          originalCode={activeFile?.content || ''}
          proposedCode={activeFile?.report?.evolvedCode || activeFile?.content || ''}
        />
      </div>
    </Sentry.ErrorBoundary>
  );
}
