/**
 * Governance & Verification Helper - Tri-Loop Autonomous Orchestration
 * 
 * Orchestrates the three core loops of the verification pipeline:
 *   Loop 1: Harvest & Scan (Edge Governance Sanitizer & Pattern Memory query)
 *   Loop 2: Dual-Perspective Code Review (Security Reviewer Helper vs Architecture Reviewer Helper)
 *   Loop 3: Self-Stopping & Proof of Clean (Halt evaluation & zero-diff saturation check)
 */

import { sanitizeAndGovern, SecuritySanitizerResult } from './sanitizer';
import { conductDebate, DebateVerdict } from './debate';
import { SelfStoppingGovernor, HaltEvaluationState } from './halt';
import { emgRagInstance, EmgQueryResult } from './emg-rag';
import { evaluateAstDiff, AstDiffResult } from '../core/ast-diff-gate';
import { zeroLeakSandbox } from './zero-leak-sandbox';

export interface TriLoopCycleResult {
  readonly cycleNumber: number;
  readonly filePath: string;
  readonly originalCode: string;
  readonly proposedCode: string;
  readonly debateVerdict: DebateVerdict;
  readonly sanitizerResult: SecuritySanitizerResult;
  readonly astDiffResult: AstDiffResult;
  readonly haltState: HaltEvaluationState | null;
  readonly ragQuery: EmgQueryResult;
  readonly cleanCommitHash?: string;
  readonly executionLog: string[];
  readonly status: 'CONVERGED' | 'SANITIZED_APPLIED' | 'REJECTED' | 'HALTED';
}

let cycleCounter = 0;
const governor = new SelfStoppingGovernor({ maxCycles: 20, maxConsecutiveFailures: 3 });

export async function executeEmgTriLoopCycle(
  filePath: string,
  originalCode: string,
  proposedCode: string
): Promise<TriLoopCycleResult> {
  cycleCounter++;
  const executionLog: string[] = [];

  return zeroLeakSandbox.executeSafe('EmgTriLoopCycle', async () => {
    executionLog.push(`[CYCLE-${cycleCounter}] Initiating Tri-Loop verification on: ${filePath}`);

    // --- LOOP 1: Harvest, Edge Governance & Sanitizer ---
    executionLog.push('[LOOP 1: SCAN] Running Shannon entropy scan & Edge Governance...');
    const sanitizerResult = sanitizeAndGovern(proposedCode);
    if (!sanitizerResult.clean) {
      executionLog.push(`[LOOP 1: ALERT] Found ${sanitizerResult.violations.length} security breach(es). Auto-sanitization invoked.`);
    } else {
      executionLog.push('[LOOP 1: OK] Shannon entropy check passed. Zero credentials leaked.');
    }

    const codeToVerify = sanitizerResult.sanitizedCode;

    // Query RAG Memory
    const ragQuery = emgRagInstance.query(`${filePath} ${codeToVerify.slice(0, 100)}`);
    executionLog.push(`[LOOP 1: RAG] Epistemic verdict: ${ragQuery.epistemicRuling}`);

    // --- LOOP 2: Code Review Chamber ---
    executionLog.push('[LOOP 2: REVIEW] Convening Review: Security Auditor Helper vs Architecture Defender Helper...');
    const debateVerdict = conductDebate(
      `Mutation Validation for ${filePath}`,
      codeToVerify,
      filePath
    );
    executionLog.push(`[LOOP 2: VERDICT] Tribunal ruled: ${debateVerdict.consensus} (Consensus: ${(debateVerdict.consensusCoefficient * 100).toFixed(0)}%, Friction: ${(debateVerdict.cognitiveFriction * 100).toFixed(0)}%)`);

    // AST Diff Gate check
    const astDiffResult = evaluateAstDiff(originalCode, codeToVerify);
    executionLog.push(`[AST GATE] Score: ${astDiffResult.astScore}/100. Symbols retained: ${astDiffResult.symbolMap.retainedCount}/${astDiffResult.symbolMap.originalCount}`);

    // --- LOOP 3: Self-Stopping & Proof of Clean ---
    executionLog.push('[LOOP 3: CONVERGENCE] Evaluating self-stopping point conditions...');
    const zeroDiffCheck = governor.checkZeroDiffSaturation(originalCode, codeToVerify);
    let haltState = zeroDiffCheck;

    if (zeroDiffCheck) {
      executionLog.push(`[LOOP 3: HALT] ${zeroDiffCheck.detail}`);
    } else {
      const recordHalt = governor.recordResult(astDiffResult.passed, filePath);
      if (recordHalt) {
        haltState = recordHalt;
        executionLog.push(`[LOOP 3: HALT] ${recordHalt.detail}`);
      }
    }

    // Determine final status
    let status: TriLoopCycleResult['status'] = 'CONVERGED';
    if (haltState && haltState.shouldHalt) {
      status = 'HALTED';
    } else if (!astDiffResult.passed || debateVerdict.consensus === 'REJECTED') {
      status = 'REJECTED';
    } else if (!sanitizerResult.clean) {
      status = 'SANITIZED_APPLIED';
    }

    // Generate deterministic proof commit hash
    const cleanCommitHash = 'c_' + Math.abs(
      (codeToVerify.length * 31 + cycleCounter * 17) ^ 0x5f3759df
    ).toString(16).padStart(7, '0');

    if (status === 'CONVERGED' || status === 'SANITIZED_APPLIED') {
      emgRagInstance.addEntry({
        provenance: 'clean',
        trust: 'high',
        filePath,
        diagnosis: `Successfully passed Tri-Loop G-${cycleCounter}`,
        content: `Refactored ${filePath} with AST score ${astDiffResult.astScore}`,
        cleanSnippet: codeToVerify.slice(0, 120),
      });
      executionLog.push(`[LOOP 3: PROOF] Generated verified clean commit: ${cleanCommitHash}`);
    }

    return {
      cycleNumber: cycleCounter,
      filePath,
      originalCode,
      proposedCode: codeToVerify,
      debateVerdict,
      sanitizerResult,
      astDiffResult,
      haltState,
      ragQuery,
      cleanCommitHash,
      executionLog,
      status,
    };
  }).then(res => {
    if (res.result) return res.result;
    throw new Error(res.error || 'Tri-Loop execution failed');
  });
}
