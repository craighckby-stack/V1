/**
 * Self-Stopping & Convergence Helper
 * 
 * Enforces three primary self-stopping mechanisms that guarantee execution convergence
 * and prevent infinite loops:
 *   1. Tree Fingerprint Saturation Lockout (SHA-256 tree hash comparison)
 *   2. 0-Diff Code Saturation Detection (normalizeCode equality)
 *   3. 3-Failure Consecutive Skip-List Logic (consecutiveFailuresRef tracking)
 */

export interface HaltEvaluationState {
  shouldHalt: boolean;
  reason?: 'TREE_FINGERPRINT_SATURATED' | 'ZERO_DIFF_SATURATION' | 'CONSECUTIVE_FAILURE_LIMIT' | 'MAX_CYCLES_REACHED';
  detail: string;
}

export interface TreeFileDescriptor {
  path: string;
  sha?: string;
  size?: number;
}

/**
 * Normalizes code for 0-diff saturation comparison:
 * Strips whitespace variance, trailing semicolons, comment formatting changes,
 * and empty lines to detect semantic no-ops.
 */
export function normalizeCode(code: string): string {
  return code
    .replace(/\/\*[\s\S]*?\*\//g, '')       // Multi-line comments
    .replace(/\/\/[^\n\r]*/g, '')           // Single-line comments
    .replace(/\s+/g, ' ')                   // Compress whitespaces
    .replace(/\s*([{};:,=()])\s*/g, '$1')   // Compress tokens
    .trim();
}

export class SelfStoppingGovernor {
  private saturatedTreeHash: string | null = null;
  private consecutiveFailures = 0;
  private readonly maxConsecutiveFailures: number;
  private maxCycles: number;
  private currentCycle = 0;
  private skippedPaths = new Set<string>();

  constructor(options?: { maxConsecutiveFailures?: number; maxCycles?: number }) {
    this.maxConsecutiveFailures = options?.maxConsecutiveFailures ?? 3;
    this.maxCycles = options?.maxCycles ?? 100;
  }

  /**
   * Evaluates Tree Fingerprint Saturation:
   * Computes deterministic fingerprint from repository tree paths and SHAs.
   */
  public computeTreeFingerprint(files: TreeFileDescriptor[]): string {
    const sorted = [...files].sort((a, b) => a.path.localeCompare(b.path));
    const raw = sorted.map(f => `${f.path}:${f.sha ?? f.size ?? 0}`).join('|');
    let hash = 0;
    for (let i = 0; i < raw.length; i++) {
      hash = ((hash << 5) - hash + raw.charCodeAt(i)) | 0;
    }
    return 'tree_fp_' + Math.abs(hash).toString(16);
  }

  public checkTreeSaturation(currentTreeFingerprint: string): HaltEvaluationState | null {
    if (this.saturatedTreeHash && this.saturatedTreeHash === currentTreeFingerprint) {
      return {
        shouldHalt: true,
        reason: 'TREE_FINGERPRINT_SATURATED',
        detail: `Tree fingerprint identical to prior saturation state (${currentTreeFingerprint}). Evolution converged.`,
      };
    }
    return null;
  }

  public setSaturatedTreeHash(hash: string): void {
    this.saturatedTreeHash = hash;
  }

  /**
   * Checks for 0-diff code saturation:
   * If proposed code is identical to original code after AST/token normalization,
   * mutation has converged with 0 delta.
   */
  public checkZeroDiffSaturation(originalCode: string, proposedCode: string): HaltEvaluationState | null {
    const normOriginal = normalizeCode(originalCode);
    const normProposed = normalizeCode(proposedCode);

    if (normOriginal === normProposed) {
      return {
        shouldHalt: true,
        reason: 'ZERO_DIFF_SATURATION',
        detail: 'Normalized AST code difference is 0. System has reached maximum code saturation.',
      };
    }
    return null;
  }

  private lastFilePath?: string;

  /**
   * Checks consecutive failure skip-list logic:
   * If a file or operation fails 3 times consecutively, it is quarantined to the skip list.
   */
  public recordResult(success: boolean, filePath?: string): HaltEvaluationState | null {
    if (filePath && this.lastFilePath && this.lastFilePath !== filePath) {
      // Switched to a new file in a batch sequence: reset per-file cycle count
      this.currentCycle = 0;
    }
    if (filePath) {
      this.lastFilePath = filePath;
    }

    this.currentCycle++;

    if (this.currentCycle >= this.maxCycles) {
      return {
        shouldHalt: true,
        reason: 'MAX_CYCLES_REACHED',
        detail: `Cycle cap of ${this.maxCycles} reached. Terminating loop to conserve resources.`,
      };
    }

    if (!success) {
      this.consecutiveFailures++;
      if (filePath) {
        this.skippedPaths.add(filePath);
      }

      if (this.consecutiveFailures >= this.maxConsecutiveFailures) {
        return {
          shouldHalt: true,
          reason: 'CONSECUTIVE_FAILURE_LIMIT',
          detail: `Reached threshold of ${this.maxConsecutiveFailures} consecutive failure cycles. Quarantining mutations.`,
        };
      }
    } else {
      // Reset failure streak on success
      this.consecutiveFailures = 0;
    }

    return null;
  }

  public getConsecutiveFailures(): number {
    return this.consecutiveFailures;
  }

  public getSkippedPaths(): string[] {
    return Array.from(this.skippedPaths);
  }

  public getCurrentCycle(): number {
    return this.currentCycle;
  }

  public getMaxCycles(): number {
    return this.maxCycles;
  }

  public setMaxCycles(max: number): void {
    if (typeof max === 'number' && max > 0) {
      this.maxCycles = Math.min(1000, max);
    }
  }

  public reset(): void {
    this.consecutiveFailures = 0;
    this.currentCycle = 0;
    this.skippedPaths.clear();
    this.saturatedTreeHash = null;
    this.lastFilePath = undefined;
  }
}
