/**
 * Zero-Leak Sandbox with WeakMap-backed execution isolation
 * Origin: craighckby-stack/EMG-
 * Prevents memory leaks and state contamination during dynamic module loading
 * and mutation evaluation.
 */

export type SandboxStatus = 'active' | 'completed' | 'failed';

export interface SandboxContext {
  readonly createdAt: number;
  readonly status: SandboxStatus;
  readonly taskName?: string;
  readonly error?: string;
  readonly durationMs?: number;
  readonly metadata?: Record<string, unknown>;
}

export interface SandboxExecutionResult<T> {
  readonly result?: T;
  readonly error?: string;
  readonly durationMs: number;
  readonly status: SandboxStatus;
}

export class ZeroLeakSandbox {
  private readonly activeContexts = new WeakMap<object, SandboxContext>();

  public createContext(owner: object, taskName?: string, metadata: Record<string, unknown> = {}): void {
    const context: SandboxContext = {
      createdAt: Date.now(),
      status: 'active',
      taskName,
      metadata: Object.freeze({ ...metadata }),
    };
    this.activeContexts.set(owner, context);
  }

  public getContext(owner: object): SandboxContext | undefined {
    return this.activeContexts.get(owner);
  }

  public updateContext(owner: object, updates: Partial<SandboxContext>): void {
    const current = this.activeContexts.get(owner);
    if (current) {
      this.activeContexts.set(owner, {
        ...current,
        ...updates,
      });
    }
  }

  public async executeSafe<T>(
    taskName: string,
    operation: () => Promise<T> | T,
    timeoutMs = 10000
  ): Promise<SandboxExecutionResult<T>> {
    const ownerToken = {};
    this.createContext(ownerToken, taskName);
    const start = performance.now();

    try {
      const timeoutPromise = new Promise<never>((_, reject) => {
        setTimeout(() => reject(new Error(`Sandbox execution timed out after ${timeoutMs}ms`)), timeoutMs);
      });

      const result = await Promise.race([
        Promise.resolve(operation()),
        timeoutPromise
      ]);

      const durationMs = Math.round(performance.now() - start);
      this.updateContext(ownerToken, { status: 'completed', durationMs });

      return {
        result,
        durationMs,
        status: 'completed',
      };
    } catch (err) {
      const durationMs = Math.round(performance.now() - start);
      const errorMessage = err instanceof Error ? err.message : String(err);
      this.updateContext(ownerToken, { status: 'failed', durationMs, error: errorMessage });

      return {
        error: errorMessage,
        durationMs,
        status: 'failed',
      };
    }
  }
}

export const zeroLeakSandbox = new ZeroLeakSandbox();
