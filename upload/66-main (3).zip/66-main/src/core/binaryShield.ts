/**
 * BinaryShield Cryptographic Helper Engine
 * Enhanced cryptography pipeline featuring AES-GCM encryption, deterministic IV handling,
 * tamper detection, and secure vault protection.
 */

export interface EncryptionPacket {
  readonly data: string; // Base64 ciphertext
  readonly iv: string;   // Base64 IV
  readonly timestamp: number;
  readonly algorithm: string;
}

export interface DecryptionPacket {
  readonly data: string;
  readonly iv: string;
}

const TEXT_ENCODER = new TextEncoder();
const TEXT_DECODER = new TextDecoder();

function bufferToBase64(buffer: ArrayBuffer | Uint8Array): string {
  const bytes = buffer instanceof Uint8Array ? buffer : new Uint8Array(buffer);
  let binary = '';
  for (let i = 0; i < bytes.byteLength; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary);
}

function base64ToBuffer(base64: string): Uint8Array {
  const binary = atob(base64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) {
    bytes[i] = binary.charCodeAt(i);
  }
  return bytes;
}

export class BinaryShield {
  private key: CryptoKey | null = null;
  private secretSeed: string;

  constructor(secretSeed = 'HELPER_SECURITY_KEY_2026') {
    this.secretSeed = secretSeed;
  }

  private async getCryptoKey(): Promise<CryptoKey> {
    if (this.key) return this.key;

    if (typeof window !== 'undefined' && window.crypto && window.crypto.subtle) {
      const rawKey = TEXT_ENCODER.encode(this.secretSeed.padEnd(32, '0').slice(0, 32));
      this.key = await window.crypto.subtle.importKey(
        'raw',
        rawKey,
        { name: 'AES-GCM' },
        false,
        ['encrypt', 'decrypt']
      );
      return this.key;
    }

    throw new Error('Web Cryptography API unavailable');
  }

  public async encrypt(plainText: string): Promise<EncryptionPacket> {
    const key = await this.getCryptoKey();
    const iv = window.crypto.getRandomValues(new Uint8Array(12));
    const encoded = TEXT_ENCODER.encode(plainText);

    const ciphertext = await window.crypto.subtle.encrypt(
      {
        name: 'AES-GCM',
        iv,
      },
      key,
      encoded
    );

    return {
      data: bufferToBase64(ciphertext),
      iv: bufferToBase64(iv),
      timestamp: Date.now(),
      algorithm: 'AES-GCM-256',
    };
  }

  public async decrypt(packet: DecryptionPacket): Promise<string> {
    const key = await this.getCryptoKey();
    const iv = base64ToBuffer(packet.iv);
    const ciphertext = base64ToBuffer(packet.data);

    const decrypted = await window.crypto.subtle.decrypt(
      {
        name: 'AES-GCM',
        iv: iv as BufferSource,
      },
      key,
      ciphertext as BufferSource
    );

    return TEXT_DECODER.decode(decrypted);
  }

  public async computeHash(data: string): Promise<string> {
    if (typeof window !== 'undefined' && window.crypto && window.crypto.subtle) {
      const buffer = TEXT_ENCODER.encode(data);
      const digest = await window.crypto.subtle.digest('SHA-256', buffer);
      return Array.from(new Uint8Array(digest))
        .map(b => b.toString(16).padStart(2, '0'))
        .join('');
    }
    return 'fallback_hash_' + Math.abs(data.split('').reduce((a, b) => ((a << 5) - a + b.charCodeAt(0)) | 0, 0));
  }
}

export const binaryShieldInstance = new BinaryShield();
