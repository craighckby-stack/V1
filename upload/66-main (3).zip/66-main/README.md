# Architecture Helper Pipeline

An automated code refactoring and multi-file mutation workbench that ingests repository files, validates AST structural preservation, scrubs sensitive credentials, performs static code analysis, and dispatches batch commits to GitHub.

---

## Key Features

- **Multi-File Repository Scanning**: Fetch tree structures from public or private GitHub repositories with auto-detection of source code files (`.ts`, `.tsx`, `.js`, `.py`, `.go`, `.rs`, `.css`, etc.).
- **Automated 6-Stage Refactoring Pipeline**:
  1. **Pattern Ingestion**: Evaluates file type, code structure, and language-specific header comments.
  2. **Credential Sanitizer**: Calculates Shannon entropy and redacts sensitive API keys (`AIzaSy...`, `ghp_...`, `sk-...`, `AKIA...`).
  3. **Refactoring Simulation**: Applies rule-based code modularization and type-safe refactoring.
  4. **AST Structural Drift Gate**: Measures length delta and AST symbol retention to prevent broken syntax or loss of key functions/interfaces.
  5. **Dual Review Tribunal**: Performs concurrent security and architectural checks before final approval.
  6. **Proof & Cycle Governor**: Computes deterministic hash signatures and manages execution cycle limits.
- **Batch GitHub Dispatch**: Directly commits all approved file mutations to the specified target branch via GitHub REST API.
- **Interactive Security & AST Inspector**: Side-by-side AST structural diffing and live regex evaluation.
- **REST API Endpoints**: Programmatic endpoints for external script integration.

---

## API Documentation

### 1. Repository Tree Scanning
`POST /api/github/repo-tree`
- **Body**: `{ "repo": "owner/repo", "branch": "main", "token": "optional_github_token" }`
- **Returns**: List of repository files with code file flags and size metadata.

### 2. File Ingestion
`POST /api/github/fetch-file`
- **Body**: `{ "repo": "owner/repo", "path": "src/index.ts", "branch": "main" }`
- **Returns**: Decoded UTF-8 source content, SHA, and file path.

### 3. Single File Commit
`POST /api/github/commit-file`
- **Body**: `{ "repo": "owner/repo", "path": "src/index.ts", "branch": "main", "content": "...", "message": "Refactor src/index.ts", "sha": "..." }`
- **Returns**: GitHub REST API commit response.

### 4. Batch Commit Dispatch
`POST /api/github/batch-commit-files`
- **Body**: `{ "repo": "owner/repo", "branch": "main", "files": [{ "path": "...", "content": "...", "sha": "..." }], "message": "Batch refactor" }`
- **Returns**: Detailed per-file commit success/failure status.

### 5. Credential Sanitizer
`POST /api/emg/sanitize`
- **Body**: `{ "code": "const key = 'sk-12345...'" }`
- **Returns**: `{ "clean": false, "sanitizedCode": "...", "violations": [...] }`

### 6. Dual Code Review
`POST /api/evolution/debate`
- **Body**: `{ "filePath": "src/main.ts", "candidateCode": "..." }`
- **Returns**: Review status (`APPROVED` / `REQUIRES_REWRITE`), risk scores, and findings.

---

## System Requirements & Run Instructions

- **Runtime**: Node.js 22+
- **Port**: 3000 (`0.0.0.0`)
- **Development**: `npm run dev` (starts `tsx server.ts` with Vite dev middleware)
- **Production Build**: `npm run build` (outputs SPA assets to `dist/`)
- **Lint & Type Check**: `npm run lint` (`tsc --noEmit`)
