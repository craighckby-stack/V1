const TOKEN = process.env.GITHUB_TOKEN || "";
const REPO = "craighckby-stack/Test-1";
const FILE = "GACR/verification/HETM_Verifier.py";

async function viewCorrupted() {
  const res = await fetch(`https://api.github.com/repos/${REPO}/contents/${FILE}`, {
    headers: { Authorization: `token ${TOKEN}` }
  });
  if (res.ok) {
    const data = await res.json();
    const content = Buffer.from(data.content, 'base64').toString('utf-8');
    console.log("--- FULL CONTENT OF CORRUPTED FILE ---");
    console.log(content);
  }
}

viewCorrupted();
